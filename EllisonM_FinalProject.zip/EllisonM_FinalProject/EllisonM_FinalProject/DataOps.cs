﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Data.OleDb;
using System.Windows.Forms;

namespace EllisonM_FinalProject
{
    class DataOps
    {

        private static string query = "";

        private static string SQLClientConnectionString = @"Data Source=gaming.tstc.edu;Initial Catalog=MEllison_Final;User ID=mellison;Password=1598365";
        private static SqlConnection SQLCon = new SqlConnection(SQLClientConnectionString);

        private static SqlDataAdapter SQLdaEndProducts = new SqlDataAdapter();
        private static SqlDataAdapter SQLdaCustomers = new SqlDataAdapter();
        private static SqlDataAdapter SQLdaMaterials = new SqlDataAdapter();
        private static SqlDataAdapter SQLdaSupplies = new SqlDataAdapter();
        private static SqlDataAdapter SQLdaSoldProduct = new SqlDataAdapter();

        private static string OleDbConnectionString = @"Provider=Microsoft.Jet.OLEDB.4.0;Data Source=..\..\Data\EllisonMFinal.mdb;Mode=Share Deny None";
        private static OleDbConnection OleDbCon = new OleDbConnection(OleDbConnectionString);

        private static OleDbDataAdapter OleDbdaEndProducts = new OleDbDataAdapter();
        private static OleDbDataAdapter OleDbdaCustomers = new OleDbDataAdapter();
        private static OleDbDataAdapter OleDbdaMaterials = new OleDbDataAdapter();
        private static OleDbDataAdapter OleDbdaSupplies = new OleDbDataAdapter();
        private static OleDbDataAdapter OleDbdaSoldProduct = new OleDbDataAdapter();

        private static DataSet _dsEndProducts = new DataSet();
        private static DataSet _dsCustomers = new DataSet();
        private static DataSet _dsMaterials = new DataSet();
        private static DataSet _dsSupplies = new DataSet();
        private static DataSet _dsSoldProduct = new DataSet();

        private static DataSet _dsEndProducts2 = new DataSet();
        private static DataSet _dsCustomers2 = new DataSet();
        private static DataSet _dsMaterials2 = new DataSet();
        private static DataSet _dsSupplies2 = new DataSet();
        private static DataSet _dsSoldProduct2 = new DataSet();

        private static string _dtEndProducts = "EndProduct";
        private static string _dtCustomers = "Customers";
        private static string _dtMaterials = "Materials";
        private static string _dtSupplies = "Supplies";
        private static string _dtSoldProduct = "SoldProduct";

        private static string _EndProductID = "";
        private static string _CustomerID = "";
        private static string _MaterialID = "";
        private static string _SupplyID = "";
        private static string _SoldProductID = "";

        #region properties

        public static DataSet dsEndProducts
        {
            get { return _dsEndProducts; }
            set { _dsEndProducts = value; }
        }

        public static DataSet dsCustomers
        {
            get { return _dsCustomers; }
            set { _dsCustomers = value; }
        }

        public static DataSet dsMaterials
        {
            get { return _dsMaterials; }
            set { _dsMaterials = value; }
        }

        public static DataSet dsSupplies
        {
            get { return _dsSupplies; }
            set { _dsSupplies = value; }
        }

        public static DataSet dsSoldProduct
        {
            get { return _dsSoldProduct2; }
            set { _dsSoldProduct2 = value; }
        }

        public static DataSet dsEndProducts2
        {
            get { return _dsEndProducts2; }
            set { _dsEndProducts2 = value; }
        }

        public static DataSet dsCustomers2
        {
            get { return _dsCustomers2; }
            set { _dsCustomers2 = value; }
        }

        public static DataSet dsMaterials2
        {
            get { return _dsMaterials2; }
            set { _dsMaterials2 = value; }
        }

        public static DataSet dsSupplies2
        {
            get { return _dsSupplies2; }
            set { _dsSupplies2 = value; }
        }

        public static DataSet dsSoldProduct2
        {
            get { return _dsSoldProduct2; }
            set { _dsSoldProduct2 = value; }
        }

        public static string dtEndProducts
        {
            get { return _dtEndProducts; }
            set { _dtEndProducts = value; }
        }
        public static string dtCustomers
        {
            get { return _dtCustomers; }
            set { _dtCustomers = value; }
        }
        public static string dtMaterials
        {
            get { return _dtMaterials; }
            set { _dtMaterials = value; }
        }
        public static string dtSupplies
        {
            get { return _dtSupplies; }
            set { _dtSupplies = value; }
        }
        public static string dtSoldProduct
        {
            get { return _dtSoldProduct; }
            set { _dtSoldProduct = value; }
        }

        public static string EndProductID
        {
            get { return _EndProductID; }
            set { _EndProductID = value; }
        }

        public static string CustomerID
        {
            get { return _CustomerID; }
            set { _CustomerID = value; }
        }

        public static string MaterialID
        {
            get { return _MaterialID; }
            set { _MaterialID = value; }
        }

        public static string SupplyID
        {
            get { return _SupplyID; }
            set { _SupplyID = value; }
        }

        public static string SoldProductID
        {
            get { return _SoldProductID; }
            set { _SoldProductID = value; }
        }

        #endregion

        #region SQLClient      

        //***************************  inserts  ***************************


        public static void SQLInsertEndProduct(string endProductID, string name, string description, string color, string type, string costToMake, string onHand, string dimentions, string sellPrice, string custom, string active, string runningTotal, string materialsUsed, string notes, string markup, string materialID)
        {
            try
            {
                query = "INSERT INTO EndProduct(EndProductID, Name, Description, Color, Type, CostToMake, OnHand, Dimentions, SellPrice, Custom, Active, RunningTotal, MaterialsUsed, Notes, Markup, MaterialID) VALUES(@endProductID, @name, @description, @color, @type, @costToMake, @onHand, @dimentions, @sellPrice, @custom, @active, @runningTotal, @materialsUsed, @notes, @markup, @materialID)";
                SQLCon.Open();
                SqlCommand cmdInsertEndProduct = new SqlCommand(query, SQLCon);
                cmdInsertEndProduct.Parameters.AddWithValue("@endProductID", endProductID);
                cmdInsertEndProduct.Parameters.AddWithValue("@name", name);
                cmdInsertEndProduct.Parameters.AddWithValue("@description", description);
                cmdInsertEndProduct.Parameters.AddWithValue("@color", color);
                cmdInsertEndProduct.Parameters.AddWithValue("@type", type);
                cmdInsertEndProduct.Parameters.AddWithValue("@costToMake", costToMake);
                cmdInsertEndProduct.Parameters.AddWithValue("@onHand", onHand);
                cmdInsertEndProduct.Parameters.AddWithValue("@dimentions", dimentions);
                cmdInsertEndProduct.Parameters.AddWithValue("@sellPrice", sellPrice);
                cmdInsertEndProduct.Parameters.AddWithValue("@custom", custom);
                cmdInsertEndProduct.Parameters.AddWithValue("@active", active);
                cmdInsertEndProduct.Parameters.AddWithValue("@runningTotal", runningTotal);
                cmdInsertEndProduct.Parameters.AddWithValue("@materialsUsed", materialsUsed);
                cmdInsertEndProduct.Parameters.AddWithValue("@notes", notes);
                cmdInsertEndProduct.Parameters.AddWithValue("@markup", markup);
                cmdInsertEndProduct.Parameters.AddWithValue("@materialID", materialID);
                cmdInsertEndProduct.ExecuteNonQuery();
                SQLCon.Close();
            }
            catch (Exception)
            {
                SQLCon.Close();
                return;
            }
        }

        public static void SQLInsertCustomer(string customerID, string name, string email, string address, string phone, string birthday, string totalItemsPurchased)
        {
            try
            {
                query = "INSERT INTO Customers(CustomerID, Name, Email, Address, Phone, Birthday, TotalItemsPurchased) VALUES(@customerID, @name, @email, @address, @phone, @birthday, @totalItemsPurchased)";
                SQLCon.Open();
                SqlCommand cmdInsertCustomer = new SqlCommand(query, SQLCon);
                cmdInsertCustomer.Parameters.AddWithValue("@customerID", customerID);
                cmdInsertCustomer.Parameters.AddWithValue("@name", name);
                cmdInsertCustomer.Parameters.AddWithValue("@email", email);
                cmdInsertCustomer.Parameters.AddWithValue("@address", address);
                cmdInsertCustomer.Parameters.AddWithValue("@phone", phone);
                cmdInsertCustomer.Parameters.AddWithValue("@birthday", birthday);
                cmdInsertCustomer.Parameters.AddWithValue("@totalItemsPurchased", totalItemsPurchased);
                cmdInsertCustomer.ExecuteNonQuery();
                SQLCon.Close();
            }
            catch (Exception)
            {
                SQLCon.Close();
                return;
            }
        }

        public static void SQLInsertMaterial(string materialID, string name, string description, string color, string type, string buyPrice, string onHand, string size, string dimentions, string Condition)
        {
            try
            {
                query = "INSERT INTO Materials(MaterialID, Name, Description, Color, Type, BuyPrice, OnHand, Size, Dimentions, Condition) VALUES(@materialID, @name, @description, @color, @type, @buyPrice, @onHand, @size, @dimentions, @Condition)";
                SQLCon.Open();
                SqlCommand cmdInsertMaterial = new SqlCommand(query, SQLCon);
                cmdInsertMaterial.Parameters.AddWithValue("@materialID", materialID);
                cmdInsertMaterial.Parameters.AddWithValue("@name", name); 
                cmdInsertMaterial.Parameters.AddWithValue("@description", description);
                cmdInsertMaterial.Parameters.AddWithValue("@color", color);
                cmdInsertMaterial.Parameters.AddWithValue("@type", type);
                cmdInsertMaterial.Parameters.AddWithValue("@buyPrice", buyPrice);
                cmdInsertMaterial.Parameters.AddWithValue("@onHand", onHand);
                cmdInsertMaterial.Parameters.AddWithValue("@size", size);
                cmdInsertMaterial.Parameters.AddWithValue("@dimentions", dimentions);
                cmdInsertMaterial.Parameters.AddWithValue("@Condition", Condition);
                cmdInsertMaterial.ExecuteNonQuery();
                SQLCon.Close();
            }
            catch (Exception)
            {
                SQLCon.Close();
                return;
            }
        }

        public static void SQLInsertSupply(string supplyID, string name, string description, string buyPrice, string onHand, string Condition)
        {
            try
            {
                query = "INSERT INTO Supplies(SupplyID, Name, Description, BuyPrice, OnHand, Condition) VALUES(@supplyID, @name, @description, @buyPrice, @onHand, @Condition)";
                SQLCon.Open();
                SqlCommand cmdInsertSupply = new SqlCommand(query, SQLCon);
                cmdInsertSupply.Parameters.AddWithValue("@supplyID", supplyID);
                cmdInsertSupply.Parameters.AddWithValue("@name", name);
                cmdInsertSupply.Parameters.AddWithValue("@description", description);
                cmdInsertSupply.Parameters.AddWithValue("@buyPrice", buyPrice);
                cmdInsertSupply.Parameters.AddWithValue("@onHand", onHand);
                cmdInsertSupply.Parameters.AddWithValue("@Condition", Condition);
                cmdInsertSupply.ExecuteNonQuery();
                SQLCon.Close();
            }
            catch (Exception)
            {
                SQLCon.Close();
                return;
            }
        }

        public static void SQLInsertSoldProduct(string soldProductID, string dateSold, string amountSold, string store, string endProductID, string customerID)//this doesn't need the ready column, because thats just used for the active database
        {
            try
            {
                query = "INSERT INTO SoldProduct(SoldProductID, DateSold, AmountSold, Store, EndProductID, CustomerID) VALUES(@soldProductID, @dateSold, @amountSold, @store, @endProductID, @customerID)";
                SQLCon.Open();
                SqlCommand cmdInsertSoldProduct = new SqlCommand(query, SQLCon);
                cmdInsertSoldProduct.Parameters.AddWithValue("@soldProductID", soldProductID);
                cmdInsertSoldProduct.Parameters.AddWithValue("@dateSold", dateSold);
                cmdInsertSoldProduct.Parameters.AddWithValue("@amountSold", amountSold);
                cmdInsertSoldProduct.Parameters.AddWithValue("@store", store);
                cmdInsertSoldProduct.Parameters.AddWithValue("@endProductID", endProductID);
                cmdInsertSoldProduct.Parameters.AddWithValue("@customerID", customerID);
                cmdInsertSoldProduct.ExecuteNonQuery();
                SQLCon.Close();
            }
            catch (Exception)
            {
                SQLCon.Close();
                return;
            }
        }

        #endregion

        #region OleDb

        //***************************  get the next id from all the tables  ***************************
        #region get ids
        public static void OleDbGetNextEndProductID()
        {
            try
            {
                query = "SELECT MAX(EndProductID) FROM EndProduct";
                OleDbCon.Open();
                using (OleDbCommand cmdNextEndProductID = new OleDbCommand(query, OleDbCon))
                    EndProductID = (int.Parse(cmdNextEndProductID.ExecuteScalar().ToString()) + 1).ToString();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbGetNextCustomerID()
        {
            try
            {
                query = "SELECT MAX(CustomerID) FROM Customers";
                OleDbCon.Open();
                using (OleDbCommand cmdNextCustomerID = new OleDbCommand(query, OleDbCon))
                    CustomerID = (int.Parse(cmdNextCustomerID.ExecuteScalar().ToString()) + 1).ToString();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbGetNextMaterialID()
        {
            try
            {
                query = "SELECT MAX(MaterialID) FROM Materials";
                OleDbCon.Open();
                using (OleDbCommand cmdNextMaterialID = new OleDbCommand(query, OleDbCon))
                    MaterialID = (int.Parse(cmdNextMaterialID.ExecuteScalar().ToString()) + 1).ToString();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbGetNextSupplyID()
        {
            try
            {
                query = "SELECT MAX(SupplyID) FROM Supplies";
                OleDbCon.Open();
                using (OleDbCommand cmdNextSupplyID = new OleDbCommand(query, OleDbCon))
                    SupplyID = (int.Parse(cmdNextSupplyID.ExecuteScalar().ToString()) + 1).ToString();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbGetNextSoldProductID()
        {
            try
            {
                query = "SELECT MAX(SoldProductID) FROM SoldProduct";
                OleDbCon.Open();
                using (OleDbCommand cmdNextSoldProductID = new OleDbCommand(query, OleDbCon))
                    SoldProductID = (int.Parse(cmdNextSoldProductID.ExecuteScalar().ToString()) + 1).ToString();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }
        #endregion

        //***************************  inserts  ***************************
        #region inserts

        public static void OleDbInsertEndProduct(string endProductID, string name, string description, string color, string type, string costToMake, string onHand, string dimentions, string sellPrice, bool custom, bool active, string runningTotal, string materialsUsed, string materialID, string notes, string markup)
        {
            try
            {
                query = "INSERT INTO EndProduct([EndProductID], [Name], [Description], [Color], [Type], [CostToMake], [OnHand], [Dimentions], [SellPrice], [Custom], [Active], [RunningTotal], [MaterialsUsed], [MaterialID], [Notes], [Markup]) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                OleDbCon.Open();
                OleDbCommand cmdInsertEndProduct = new OleDbCommand(query, OleDbCon);
                cmdInsertEndProduct.Parameters.AddWithValue("?", endProductID);
                cmdInsertEndProduct.Parameters.AddWithValue("?", name);
                cmdInsertEndProduct.Parameters.AddWithValue("?", description);
                cmdInsertEndProduct.Parameters.AddWithValue("?", color);
                cmdInsertEndProduct.Parameters.AddWithValue("?", type);
                cmdInsertEndProduct.Parameters.AddWithValue("?", costToMake);
                cmdInsertEndProduct.Parameters.AddWithValue("?", onHand);
                cmdInsertEndProduct.Parameters.AddWithValue("?", dimentions);
                cmdInsertEndProduct.Parameters.AddWithValue("?", sellPrice);
                cmdInsertEndProduct.Parameters.AddWithValue("?", custom);
                cmdInsertEndProduct.Parameters.AddWithValue("?", active);
                cmdInsertEndProduct.Parameters.AddWithValue("?", runningTotal);
                cmdInsertEndProduct.Parameters.AddWithValue("?", materialsUsed);
                cmdInsertEndProduct.Parameters.AddWithValue("?", materialID);
                cmdInsertEndProduct.Parameters.AddWithValue("?", notes);
                cmdInsertEndProduct.Parameters.AddWithValue("?", markup);
                cmdInsertEndProduct.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbInsertCustomer(string customerID, string name, string email, string address, string phone, string birthday, string totalItemsPurchased)
        {
            try
            {
                query = "INSERT INTO Customers([CustomerID], [Name], [Email], [Address], [Phone], [Birthday], [TotalItemsPurchased]) VALUES(?, ?, ?, ?, ?, ?, ?)";
                OleDbCon.Open();
                OleDbCommand cmdInsertCustomer = new OleDbCommand(query, OleDbCon);
                cmdInsertCustomer.Parameters.AddWithValue("?", customerID);
                cmdInsertCustomer.Parameters.AddWithValue("?", name);
                cmdInsertCustomer.Parameters.AddWithValue("?", email);
                cmdInsertCustomer.Parameters.AddWithValue("?", address);
                cmdInsertCustomer.Parameters.AddWithValue("?", phone);
                cmdInsertCustomer.Parameters.AddWithValue("?", birthday);
                cmdInsertCustomer.Parameters.AddWithValue("?", totalItemsPurchased);
                cmdInsertCustomer.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbInsertMaterial(string materialID, string name, string description, string color, string type, string buyPrice, string onHand, string size, string dimentions, string condition)
        {
            try
            {
                query = "INSERT INTO Materials([MaterialID], [Name], [Description], [Color], [Type], [BuyPrice], [OnHand], [Size], [Dimentions], [Condition]) VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                OleDbCon.Open();
                OleDbCommand cmdInsertMaterial = new OleDbCommand(query, OleDbCon);
                cmdInsertMaterial.Parameters.AddWithValue("?", MaterialID);
                cmdInsertMaterial.Parameters.AddWithValue("?", name);
                cmdInsertMaterial.Parameters.AddWithValue("?", description);
                cmdInsertMaterial.Parameters.AddWithValue("?", color);
                cmdInsertMaterial.Parameters.AddWithValue("?", type);
                cmdInsertMaterial.Parameters.AddWithValue("?", buyPrice);
                cmdInsertMaterial.Parameters.AddWithValue("?", onHand);
                cmdInsertMaterial.Parameters.AddWithValue("?", size);
                cmdInsertMaterial.Parameters.AddWithValue("?", dimentions);
                cmdInsertMaterial.Parameters.AddWithValue("?", condition);
                cmdInsertMaterial.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbInsertSupply(string supplyID, string name, string description, string buyPrice, string onHand, string condition)
        {
            try
            {
                query = "INSERT INTO Supplies([SupplyID], [Name], [Description], [BuyPrice], [OnHand], [Condition]) VALUES(?, ?, ?, ?, ?, ?)";
                OleDbCon.Open();
                OleDbCommand cmdInsertSupply = new OleDbCommand(query, OleDbCon);
                cmdInsertSupply.Parameters.AddWithValue("?", supplyID);
                cmdInsertSupply.Parameters.AddWithValue("?", name);
                cmdInsertSupply.Parameters.AddWithValue("?", description);
                cmdInsertSupply.Parameters.AddWithValue("?", buyPrice);
                cmdInsertSupply.Parameters.AddWithValue("?", onHand);
                cmdInsertSupply.Parameters.AddWithValue("?", condition);
                cmdInsertSupply.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbInsertSoldProduct(string soldProductID, string dateSold, string amountSold, string store, string productID, string customerID, bool ready)
        {
            try
            {
                query = "INSERT INTO SoldProduct([SoldProductID], [DateSold], [AmountSold], [Store], [EndProductID], [CustomerID], [Ready]) VALUES(?, ?, ?, ?, ?, ?, ?)";
                OleDbCon.Open();
                OleDbCommand cmdInsertSoldProduct = new OleDbCommand(query, OleDbCon);
                cmdInsertSoldProduct.Parameters.AddWithValue("?", soldProductID);
                cmdInsertSoldProduct.Parameters.AddWithValue("?", dateSold);
                cmdInsertSoldProduct.Parameters.AddWithValue("?", amountSold);
                cmdInsertSoldProduct.Parameters.AddWithValue("?", store);
                cmdInsertSoldProduct.Parameters.AddWithValue("?", productID);
                cmdInsertSoldProduct.Parameters.AddWithValue("?", customerID);
                cmdInsertSoldProduct.Parameters.AddWithValue("?", ready);
                cmdInsertSoldProduct.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }
        #endregion

        //***************************  updates  ***************************
        #region updates
        public static void OleDbUpdateEndProduct(string endProductID, string name, string description, string color, string type, string costToMake, string onHand, string dimentions, string sellPrice, bool custom, bool active, string runningTotal, string materialsUsed, string materialID, string notes, string markup)
        {
            try
            {
                query = "UPDATE EndProduct SET [Name] = ?, [Description] = ?, [Color] = ?, [Type] = ?, [CostToMake] = ?, [OnHand] = ?, [Dimentions] = ?, [SellPrice] = ?, [Custom] = ?, [Active] = ?, [RunningTotal] = ?, [MaterialsUsed] = ?, [MaterialID] = ?, [Notes] = ?, [Markup] = ? WHERE [EndProductID] = ?";
                OleDbCon.Open();
                OleDbCommand cmdupdateEndProduct = new OleDbCommand(query, OleDbCon);                
                cmdupdateEndProduct.Parameters.AddWithValue("?", name);
                cmdupdateEndProduct.Parameters.AddWithValue("?", description);
                cmdupdateEndProduct.Parameters.AddWithValue("?", color);
                cmdupdateEndProduct.Parameters.AddWithValue("?", type);
                cmdupdateEndProduct.Parameters.AddWithValue("?", costToMake);
                cmdupdateEndProduct.Parameters.AddWithValue("?", onHand);
                cmdupdateEndProduct.Parameters.AddWithValue("?", dimentions);
                cmdupdateEndProduct.Parameters.AddWithValue("?", sellPrice);
                cmdupdateEndProduct.Parameters.AddWithValue("?", custom);
                cmdupdateEndProduct.Parameters.AddWithValue("?", active);
                cmdupdateEndProduct.Parameters.AddWithValue("?", runningTotal);
                cmdupdateEndProduct.Parameters.AddWithValue("?", materialsUsed);
                cmdupdateEndProduct.Parameters.AddWithValue("?", materialID);
                cmdupdateEndProduct.Parameters.AddWithValue("?", notes);
                cmdupdateEndProduct.Parameters.AddWithValue("?", markup);
                cmdupdateEndProduct.Parameters.AddWithValue("?", endProductID);
                cmdupdateEndProduct.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbUpdateCustomer(string customerID, string name, string email, string address, string phone, string birthday, string totalItemsPurchased)
        {
            try
            {
                query = "UPDATE Customers SET [Name] = ?, [Email] = ?, [Address] = ?, [Phone] = ?, [Birthday] = ?, [TotalItemsPurchased] = ? WHERE [CustomerID] = ?";
                OleDbCon.Open();
                OleDbCommand cmdupdateCustomer = new OleDbCommand(query, OleDbCon);
                cmdupdateCustomer.Parameters.AddWithValue("?", name);
                cmdupdateCustomer.Parameters.AddWithValue("?", email);
                cmdupdateCustomer.Parameters.AddWithValue("?", address);
                cmdupdateCustomer.Parameters.AddWithValue("?", phone);
                cmdupdateCustomer.Parameters.AddWithValue("?", birthday);
                cmdupdateCustomer.Parameters.AddWithValue("?", totalItemsPurchased);
                cmdupdateCustomer.Parameters.AddWithValue("?", customerID);
                cmdupdateCustomer.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbUpdateMaterial(string materialID, string name, string description, string color, string type, string buyPrice, string onHand, string size, string dimentions, string condition)
        {
            try
            {
                query = "UPDATE Materials SET [Name] = ?, [Description] = ?, [Color] = ?, [Type] = ?, [BuyPrice] = ?, [OnHand] = ?, [Size] = ?, [Dimentions] = ?, [Condition] = ? WHERE [MaterialID] = ?";
                OleDbCon.Open();
                OleDbCommand cmdUpdateMaterial = new OleDbCommand(query, OleDbCon);
                cmdUpdateMaterial.Parameters.AddWithValue("?", name);
                cmdUpdateMaterial.Parameters.AddWithValue("?", description);
                cmdUpdateMaterial.Parameters.AddWithValue("?", color);
                cmdUpdateMaterial.Parameters.AddWithValue("?", type);
                cmdUpdateMaterial.Parameters.AddWithValue("?", buyPrice);
                cmdUpdateMaterial.Parameters.AddWithValue("?", onHand);
                cmdUpdateMaterial.Parameters.AddWithValue("?", size);
                cmdUpdateMaterial.Parameters.AddWithValue("?", dimentions);
                cmdUpdateMaterial.Parameters.AddWithValue("?", condition);
                cmdUpdateMaterial.Parameters.AddWithValue("?", materialID);
                cmdUpdateMaterial.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbUpdateSupply(string supplyID, string name, string description, string buyPrice, string onHand, string condition)
        {
            try
            {
                query = "UPDATE Supplies SET [Name] = ?, [Description] = ?, [BuyPrice] = ?, [OnHand] = ?, [Condition] = ? WHERE[ SupplyID] = ?";
                OleDbCon.Open();
                OleDbCommand cmdUpdateSupply = new OleDbCommand(query, OleDbCon);
                cmdUpdateSupply.Parameters.AddWithValue("?", name);
                cmdUpdateSupply.Parameters.AddWithValue("?", description);
                cmdUpdateSupply.Parameters.AddWithValue("?", buyPrice);
                cmdUpdateSupply.Parameters.AddWithValue("?", onHand);
                cmdUpdateSupply.Parameters.AddWithValue("?", condition);
                cmdUpdateSupply.Parameters.AddWithValue("?", supplyID);                
                cmdUpdateSupply.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbUpdateSoldProduct(string soldProductID, string dateSold, string amountSold, string store, string productID, string customerID, bool ready)
        {
            try
            {
                query = "UPDATE SoldProduct SET [DateSold] = ?, [AmountSold] = ?, [Store] = ?, [EndProductID] = ?, [CustomerID] = ?, [Ready] = ? WHERE [SoldProductID] = ?";
                OleDbCon.Open();
                OleDbCommand cmdUpdateSoldProduct = new OleDbCommand(query, OleDbCon);
                cmdUpdateSoldProduct.Parameters.AddWithValue("?", dateSold);
                cmdUpdateSoldProduct.Parameters.AddWithValue("?", amountSold);
                cmdUpdateSoldProduct.Parameters.AddWithValue("?", store);
                cmdUpdateSoldProduct.Parameters.AddWithValue("?", productID);
                cmdUpdateSoldProduct.Parameters.AddWithValue("?", customerID);
                cmdUpdateSoldProduct.Parameters.AddWithValue("?", ready);
                cmdUpdateSoldProduct.Parameters.AddWithValue("?", soldProductID);
                cmdUpdateSoldProduct.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbUpdateEndProductMarkup(string markup, string sellPrice, string id)
        {
            try
            {
                query = "UPDATE EndProduct SET [Markup] = ?, [SellPrice] = ? WHERE [EndProductID] = ?";
                OleDbCon.Open();
                OleDbCommand cmdupdateEndProduct = new OleDbCommand(query, OleDbCon);
                cmdupdateEndProduct.Parameters.AddWithValue("?", markup);
                cmdupdateEndProduct.Parameters.AddWithValue("?", sellPrice);
                cmdupdateEndProduct.Parameters.AddWithValue("?", id);
                cmdupdateEndProduct.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbUpdateSoldProductAmountSold(string amountSold, string id)
        {
            try
            {
                query = "UPDATE SoldProduct SET [AmountSold] = ? WHERE [SoldProductID] = ?";
                OleDbCon.Open();
                OleDbCommand cmdupdateEndProduct = new OleDbCommand(query, OleDbCon);
                cmdupdateEndProduct.Parameters.AddWithValue("?", amountSold);
                cmdupdateEndProduct.Parameters.AddWithValue("?", id);
                cmdupdateEndProduct.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbUpdateSoldProductEndProductID(string endproductid, string id)
        {
            try
            {
                query = "UPDATE SoldProduct SET [EndProductID] = ? WHERE [SoldProductID] = ?";
                OleDbCon.Open();
                OleDbCommand cmdupdateEndProduct = new OleDbCommand(query, OleDbCon);
                cmdupdateEndProduct.Parameters.AddWithValue("?", endproductid);
                cmdupdateEndProduct.Parameters.AddWithValue("?", id);
                cmdupdateEndProduct.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbUpdateCustomerTotalItemsPurchasedSubtract(string amountSold, string id)
        {
            double totalItemsPurchased = 0;
            try
            {
                query = "SELECT [TotalItemsPurchased] FROM Customers WHERE [CustomerID] = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectTotalItemsPurchased = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectTotalItemsPurchased.Parameters.AddWithValue("?", id);
                    totalItemsPurchased = double.Parse(cmdSelectTotalItemsPurchased.ExecuteScalar().ToString());
                }
                OleDbCon.Close();
                totalItemsPurchased = totalItemsPurchased - double.Parse(amountSold);
                query = "UPDATE Customers SET [TotalItemsPurchased] = ? WHERE [CustomerID] = ?";
                OleDbCon.Open();
                OleDbCommand cmdupdateTotalItemsPurchased = new OleDbCommand(query, OleDbCon);
                cmdupdateTotalItemsPurchased.Parameters.AddWithValue("?", totalItemsPurchased);
                cmdupdateTotalItemsPurchased.Parameters.AddWithValue("?", id);
                cmdupdateTotalItemsPurchased.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch(Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbUpdateCustomerTotalItemsPurchasedAdd(string amountSold, string id)
        {
            double totalItemsPurchased = 0;
            try
            {
                query = "SELECT [TotalItemsPurchased] FROM Customers WHERE [CustomerID] = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectTotalItemsPurchased = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectTotalItemsPurchased.Parameters.AddWithValue("?", id);
                    totalItemsPurchased = double.Parse(cmdSelectTotalItemsPurchased.ExecuteScalar().ToString());
                }
                OleDbCon.Close();
                totalItemsPurchased = totalItemsPurchased + double.Parse(amountSold);
                query = "UPDATE Customers SET [TotalItemsPurchased] = ? WHERE [CustomerID] = ?";
                OleDbCon.Open();
                OleDbCommand cmdupdateTotalItemsPurchased = new OleDbCommand(query, OleDbCon);
                cmdupdateTotalItemsPurchased.Parameters.AddWithValue("?", totalItemsPurchased);
                cmdupdateTotalItemsPurchased.Parameters.AddWithValue("?", id);
                cmdupdateTotalItemsPurchased.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbUpdateEndProductRunningTotalSubtract(string profit, string id)
        {
            double runningTotal = 0;
            try
            {
                query = "SELECT [RunningTotal] FROM EndProduct WHERE [EndProductID] = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectRunningTotal = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectRunningTotal.Parameters.AddWithValue("?", id);
                    runningTotal = double.Parse(cmdSelectRunningTotal.ExecuteScalar().ToString());
                }
                OleDbCon.Close();
                runningTotal = runningTotal - double.Parse(profit);
                query = "Update EndProduct SET [RunningTotal] = ? WHERE [EndProductID] = ?";
                OleDbCon.Open();
                OleDbCommand cmdUpdateRunningTotal = new OleDbCommand(query, OleDbCon);
                cmdUpdateRunningTotal.Parameters.AddWithValue("?", runningTotal);
                cmdUpdateRunningTotal.Parameters.AddWithValue("?", id);
                cmdUpdateRunningTotal.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbUpdateEndProductRunningTotalAdd(string profit, string id)
        {
            double runningTotal = 0;
            try
            {
                query = "SELECT [RunningTotal] FROM EndProduct WHERE [EndProductID] = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectRunningTotal = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectRunningTotal.Parameters.AddWithValue("?", id);
                    runningTotal = double.Parse(cmdSelectRunningTotal.ExecuteScalar().ToString());
                }
                OleDbCon.Close();
                runningTotal = runningTotal + double.Parse(profit);
                query = "Update EndProduct SET [RunningTotal] = ? WHERE [EndProductID] = ?";
                OleDbCon.Open();
                OleDbCommand cmdUpdateRunningTotal = new OleDbCommand(query, OleDbCon);
                cmdUpdateRunningTotal.Parameters.AddWithValue("?", runningTotal);
                cmdUpdateRunningTotal.Parameters.AddWithValue("?", id);
                cmdUpdateRunningTotal.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbUpdateEndProductOnHandSubtract(string newonhand, string id)
        {
            double onHand = 0;
            try
            {
                query = "SELECT [OnHand] FROM EndProduct WHERE [EndProductID] = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectOnHand = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectOnHand.Parameters.AddWithValue("?", id);
                    onHand = double.Parse(cmdSelectOnHand.ExecuteScalar().ToString());
                }
                OleDbCon.Close();
                onHand = onHand - double.Parse(newonhand);
                query = "UPDATE EndProduct SET [OnHand] = ? WHERE [EndProductID] = ?";
                OleDbCon.Open();
                OleDbCommand cmdUpdateOnHand = new OleDbCommand(query, OleDbCon);
                cmdUpdateOnHand.Parameters.AddWithValue("?", onHand);
                cmdUpdateOnHand.Parameters.AddWithValue("?", id);
                cmdUpdateOnHand.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch(Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbUpdateEndProductOnHandAdd(string newonhand, string id)
        {
            double onHand = 0;
            try
            {
                query = "SELECT [OnHand] FROM EndProduct WHERE [EndProductID] = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectOnHand = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectOnHand.Parameters.AddWithValue("?", id);
                    onHand = double.Parse(cmdSelectOnHand.ExecuteScalar().ToString());
                }
                OleDbCon.Close();
                onHand = onHand + double.Parse(newonhand);
                query = "UPDATE EndProduct SET [OnHand] = ? WHERE [EndProductID] = ?";
                OleDbCon.Open();
                OleDbCommand cmdUpdateOnHand = new OleDbCommand(query, OleDbCon);
                cmdUpdateOnHand.Parameters.AddWithValue("?", onHand);
                cmdUpdateOnHand.Parameters.AddWithValue("?", id);
                cmdUpdateOnHand.ExecuteNonQuery();
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbUpdateCustomerIDWhereSoldProductID(string customerID, string soldProductID)
        {
            try
            {
                query = "UPDATE SoldProduct SET [CustomerID] = ? WHERE [SoldProductID] = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdUpdateCustomerID = new OleDbCommand(query, OleDbCon))
                {
                    cmdUpdateCustomerID.Parameters.AddWithValue("?", customerID);
                    cmdUpdateCustomerID.Parameters.AddWithValue("?", soldProductID);
                    cmdUpdateCustomerID.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbDecrementMaterialOnHand(string id)
        {
            try
            {
                string newOnHand = "";
                query = "SELECT OnHand FROM Materials WHERE MaterialID = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdDecrementMaterialOnHandSelect = new OleDbCommand(query, OleDbCon))
                {
                    cmdDecrementMaterialOnHandSelect.Parameters.AddWithValue("?", id);
                    newOnHand = (double.Parse(cmdDecrementMaterialOnHandSelect.ExecuteScalar().ToString()) + -1).ToString();
                }
                OleDbCon.Close();

                query = "UPDATE Materials SET [OnHand] = ? WHERE [MaterialID] = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdDecrementMaterialOnHand = new OleDbCommand(query, OleDbCon))
                {
                    cmdDecrementMaterialOnHand.Parameters.AddWithValue("?", newOnHand);
                    cmdDecrementMaterialOnHand.Parameters.AddWithValue("?", id);
                    cmdDecrementMaterialOnHand.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch(Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        #endregion

        //***************************  Data Retrieval  ***************************
        #region data retrieval
        public static void OleDbSelectEndProduct()
        {
            try
            {
                query = "SELECT * FROM EndProduct";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectEndProduct = new OleDbCommand(query, OleDbCon))
                {
                    dsEndProducts.Clear();
                    dsEndProducts.Tables.Clear();
                    OleDbdaEndProducts.SelectCommand = cmdSelectEndProduct;
                    OleDbdaEndProducts.Fill(dsEndProducts, dtEndProducts);
                    cmdSelectEndProduct.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectCustomer()
        {
            try
            {
                query = "SELECT * FROM Customers";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectCustomer = new OleDbCommand(query, OleDbCon))
                {
                    dsCustomers.Clear();
                    dsCustomers.Tables.Clear();
                    OleDbdaCustomers.SelectCommand = cmdSelectCustomer;
                    OleDbdaCustomers.Fill(dsCustomers, dtCustomers);
                    cmdSelectCustomer.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectMaterial()
        {
            try
            {
                query = "SELECT * FROM Materials";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectMaterials = new OleDbCommand(query, OleDbCon))
                {
                    dsMaterials.Clear();
                    dsMaterials.Tables.Clear();
                    OleDbdaMaterials.SelectCommand = cmdSelectMaterials;
                    OleDbdaMaterials.Fill(dsMaterials, dtMaterials);
                    cmdSelectMaterials.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectSupply()
        {
            try
            {
                query = "SELECT * FROM Supplies";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectSupplies = new OleDbCommand(query, OleDbCon))
                {
                    dsSupplies.Clear();
                    dsSupplies.Tables.Clear();
                    OleDbdaSupplies.SelectCommand = cmdSelectSupplies;
                    OleDbdaSupplies.Fill(dsSupplies, dtSupplies);
                    cmdSelectSupplies.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectSoldProduct()
        {
            try
            {
                query = "SELECT * FROM SoldProduct";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectSoldProduct = new OleDbCommand(query, OleDbCon))
                {
                    dsSoldProduct.Clear();
                    dsSoldProduct.Tables.Clear();
                    OleDbdaSoldProduct.SelectCommand = cmdSelectSoldProduct;
                    OleDbdaSoldProduct.Fill(dsSoldProduct, dtSoldProduct);
                    cmdSelectSoldProduct.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        //sold product queries
        #region sold product queries

        public static void OleDbSelectSoldProductByCustomer()
        {
            try
            {
                query = "SELECT Name FROM Customers";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectSoldproductbyCustomer = new OleDbCommand(query, OleDbCon))
                {
                    dsCustomers.Clear();
                    dsCustomers.Tables.Clear();
                    OleDbdaCustomers.SelectCommand = cmdSelectSoldproductbyCustomer;
                    OleDbdaCustomers.Fill(dsCustomers, dtCustomers);
                    cmdSelectSoldproductbyCustomer.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch(Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectCustomerIDFromCustomersWhereName(string name)
        {
            try
            {
                query = "SELECT CustomerID FROM Customers WHERE Name = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectSoldproductbyCustomer2 = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectSoldproductbyCustomer2.Parameters.AddWithValue("?", name);
                    dsCustomers2.Clear();
                    dsCustomers2.Tables.Clear();
                    OleDbdaCustomers.SelectCommand = cmdSelectSoldproductbyCustomer2;
                    OleDbdaCustomers.Fill(dsCustomers2, dtCustomers);
                    cmdSelectSoldproductbyCustomer2.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectAllFromSoldProductWhereCustomerID(string id)
        {
            try
            {
                query = "SELECT * FROM SoldProduct WHERE CustomerID = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectSoldProductbyCustomer3 = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectSoldProductbyCustomer3.Parameters.AddWithValue("?", id);
                    dsSoldProduct.Clear();
                    dsSoldProduct.Tables.Clear();
                    OleDbdaSoldProduct.SelectCommand = cmdSelectSoldProductbyCustomer3;
                    OleDbdaSoldProduct.Fill(dsSoldProduct, dtSoldProduct);
                    cmdSelectSoldProductbyCustomer3.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectAllFromSoldProductWhereCustomerIDAndSoldProductID(string cid, string sid)
        {
            try
            {
                query = "SELECT * FROM SoldProduct WHERE CustomerID = ? AND SoldProductID = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectSoldProductbyCustomer3Backup = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectSoldProductbyCustomer3Backup.Parameters.AddWithValue("?", cid);
                    cmdSelectSoldProductbyCustomer3Backup.Parameters.AddWithValue("?", sid);
                    dsSoldProduct.Clear();
                    dsSoldProduct.Tables.Clear();
                    OleDbdaSoldProduct.SelectCommand = cmdSelectSoldProductbyCustomer3Backup;
                    OleDbdaSoldProduct.Fill(dsSoldProduct, dtSoldProduct);
                    cmdSelectSoldProductbyCustomer3Backup.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectSoldProductIDFromSoldProductWhereCustomerID(string id)
        {
            try
            {
                query = "SELECT SoldProductID FROM SoldProduct WHERE CustomerID = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectSoldProductbyCustomer3Backup = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectSoldProductbyCustomer3Backup.Parameters.AddWithValue("?", id);
                    dsSoldProduct2.Clear();
                    dsSoldProduct2.Tables.Clear();
                    OleDbdaSoldProduct.SelectCommand = cmdSelectSoldProductbyCustomer3Backup;
                    OleDbdaSoldProduct.Fill(dsSoldProduct2, dtSoldProduct);
                    cmdSelectSoldProductbyCustomer3Backup.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectAllFromCustomersWhereCustomerID(string id)
        {
            try
            {
                query = "SELECT * FROM Customers WHERE CustomerID = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSoldProductByCustomer4 = new OleDbCommand(query, OleDbCon))
                {
                    cmdSoldProductByCustomer4.Parameters.AddWithValue("?", id);
                    dsCustomers.Clear();
                    dsCustomers.Tables.Clear();
                    OleDbdaCustomers.SelectCommand = cmdSoldProductByCustomer4;
                    OleDbdaCustomers.Fill(dsCustomers, dtCustomers);
                    cmdSoldProductByCustomer4.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch(Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectSoldProductByDateSold()
        {
            try
            {
                query = "SELECT DateSold FROM SoldProduct";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectSoldproductByDateSold = new OleDbCommand(query, OleDbCon))
                {
                    dsSoldProduct.Clear();
                    dsSoldProduct.Tables.Clear();
                    OleDbdaSoldProduct.SelectCommand = cmdSelectSoldproductByDateSold;
                    OleDbdaSoldProduct.Fill(dsSoldProduct, dtSoldProduct);
                    cmdSelectSoldproductByDateSold.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectSoldProductIDFromSoldProductWhereDateSold(string date)
        {
            try
            {
                query = "SELECT SoldProductID FROM SoldProduct WHERE DateSold = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectSoldproductByDateSold2 = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectSoldproductByDateSold2.Parameters.AddWithValue("?", date);
                    dsSoldProduct2.Clear();
                    dsSoldProduct2.Tables.Clear();
                    OleDbdaSoldProduct.SelectCommand = cmdSelectSoldproductByDateSold2;
                    OleDbdaSoldProduct.Fill(dsSoldProduct2, dtSoldProduct);
                    cmdSelectSoldproductByDateSold2.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectAllFromSoldProductWhereSoldProductID(string id)
        {
            try
            {
                query = "SELECT * FROM SoldProduct WHERE SoldProductID = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectSoldproductByDateSold3 = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectSoldproductByDateSold3.Parameters.AddWithValue("?", id);
                    dsSoldProduct.Clear();
                    dsSoldProduct.Tables.Clear();
                    OleDbdaSoldProduct.SelectCommand = cmdSelectSoldproductByDateSold3;
                    OleDbdaSoldProduct.Fill(dsSoldProduct, dtSoldProduct);
                    cmdSelectSoldproductByDateSold3.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectProductName(string id)
        {
            try
            {
                query = "SELECT Name FROM EndProduct WHERE EndProductID = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectProductName = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectProductName.Parameters.AddWithValue("?", id);
                    dsEndProducts.Clear();
                    dsEndProducts.Tables.Clear();
                    OleDbdaEndProducts.SelectCommand = cmdSelectProductName;
                    OleDbdaEndProducts.Fill(dsEndProducts, dtEndProducts);
                    cmdSelectProductName.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectProductIDs(string name)
        {
            try
            {
                query = "SELECT EndProductID FROM EndProduct WHERE Name = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectProductIDs = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectProductIDs.Parameters.AddWithValue("?", name);
                    dsEndProducts.Clear();
                    dsEndProducts.Tables.Clear();
                    OleDbdaEndProducts.SelectCommand = cmdSelectProductIDs;
                    OleDbdaEndProducts.Fill(dsEndProducts, dtEndProducts);
                    cmdSelectProductIDs.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectProduct(string id, string name)
        {
            try
            {
                query = "SELECT * FROM EndProduct WHERE EndProductID = ? AND Name = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectProduct = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectProduct.Parameters.AddWithValue("?", id);
                    cmdSelectProduct.Parameters.AddWithValue("?", name);
                    dsEndProducts.Clear();
                    dsEndProducts.Tables.Clear();
                    OleDbdaEndProducts.SelectCommand = cmdSelectProduct;
                    OleDbdaEndProducts.Fill(dsEndProducts, dtEndProducts);
                    cmdSelectProduct.ExecuteNonQuery();
                    string thing = dsEndProducts.Tables[dtEndProducts].Rows[0][0].ToString();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectProductCostAndSellPrice(string id)
        {
            try
            {
                query = "SELECT CostToMake, SellPrice FROM EndProduct WHERE EndProductID = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectProduct = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectProduct.Parameters.AddWithValue("?", id);
                    dsEndProducts.Clear();
                    dsEndProducts.Tables.Clear();
                    OleDbdaEndProducts.SelectCommand = cmdSelectProduct;
                    OleDbdaEndProducts.Fill(dsEndProducts, dtEndProducts);
                    cmdSelectProduct.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectProductMarkupAndCostToMakeAndSellPrice(string id)
        {
            try
            {
                query = "SELECT Markup, CostToMake, SellPrice FROM EndProduct WHERE EndProductID = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectProduct = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectProduct.Parameters.AddWithValue("?", id);
                    dsEndProducts.Clear();
                    dsEndProducts.Tables.Clear();
                    OleDbdaEndProducts.SelectCommand = cmdSelectProduct;
                    OleDbdaEndProducts.Fill(dsEndProducts, dtEndProducts);
                    cmdSelectProduct.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectOnHandFromEndProductsWhereEndProductID(string id)
        {
            try
            {
                query = "SELECT [OnHand] FROM EndProduct WHERE [EndProductID] = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectOnHand = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectOnHand.Parameters.AddWithValue("?", id);
                    dsEndProducts.Clear();
                    dsEndProducts.Tables.Clear();
                    OleDbdaEndProducts.SelectCommand = cmdSelectOnHand;
                    OleDbdaEndProducts.Fill(dsEndProducts, dtEndProducts);
                    cmdSelectOnHand.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectTotalItemsPurchasedFromCustomersWhereCustomerID(string id)
        {
            try
            {
                query = "SELECT [TotalItemsPurchased] FROM Customers WHERE [CustomerID] = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectTotalItemsPurchased = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectTotalItemsPurchased.Parameters.AddWithValue("?", id);
                    dsCustomers.Clear();
                    dsCustomers.Tables.Clear();
                    OleDbdaCustomers.SelectCommand = cmdSelectTotalItemsPurchased;
                    OleDbdaCustomers.Fill(dsCustomers, dtCustomers);
                    cmdSelectTotalItemsPurchased.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch(Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        #endregion

        //inventory queries
        #region inventory queries

        public static void OleDbSelectMaterialNames()
        {
            try
            {
                query = "SELECT Name FROM Materials";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectMaterialNames = new OleDbCommand(query, OleDbCon))
                {
                    dsMaterials2.Clear();
                    dsMaterials2.Tables.Clear();
                    OleDbdaMaterials.SelectCommand = cmdSelectMaterialNames;
                    OleDbdaMaterials.Fill(dsMaterials2, dtMaterials);
                    cmdSelectMaterialNames.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectMaterialIDs(string name)
        {
            try
            {
                query = "SELECT MaterialID FROM Materials WHERE Name = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectMaterialIDs = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectMaterialIDs.Parameters.AddWithValue("?", name);
                    dsMaterials.Clear();
                    dsMaterials.Tables.Clear();
                    OleDbdaMaterials.SelectCommand = cmdSelectMaterialIDs;
                    OleDbdaMaterials.Fill(dsMaterials, dtMaterials);
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectSuppliesNames()
        {
            try
            {
                query = "SELECT Name FROM Supplies";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectSupplieslNames = new OleDbCommand(query, OleDbCon))
                {
                    dsSupplies2.Clear();
                    dsSupplies2.Tables.Clear();
                    OleDbdaSupplies.SelectCommand = cmdSelectSupplieslNames;
                    OleDbdaSupplies.Fill(dsSupplies2, dtSupplies);
                    cmdSelectSupplieslNames.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectSuppliesIDs(string name)
        {
            try
            {
                query = "SELECT SupplyID FROM Supplies WHERE Name = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectSupplieslIDs = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectSupplieslIDs.Parameters.AddWithValue("?", name);
                    dsSupplies.Clear();
                    dsSupplies.Clear();
                    OleDbdaSupplies.SelectCommand = cmdSelectSupplieslIDs;
                    OleDbdaSupplies.Fill(dsSupplies, dtSupplies);
                    cmdSelectSupplieslIDs.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectEndProductNames()
        {
            try
            {
                query = "SELECT Name FROM EndProduct";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectEndProductName = new OleDbCommand(query, OleDbCon))
                {
                    dsEndProducts2.Clear();
                    dsEndProducts2.Tables.Clear();
                    OleDbdaEndProducts.SelectCommand = cmdSelectEndProductName;
                    OleDbdaEndProducts.Fill(dsEndProducts2, dtEndProducts);
                    cmdSelectEndProductName.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectEndProductIDs(string name)
        {
            try
            {
                query = "SELECT EndProductID FROM EndProduct WHERE Name = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectEndProductIDs = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectEndProductIDs.Parameters.AddWithValue("?", name);
                    dsEndProducts.Clear();
                    dsEndProducts.Tables.Clear();
                    OleDbdaEndProducts.SelectCommand = cmdSelectEndProductIDs;
                    OleDbdaEndProducts.Fill(dsEndProducts, dtEndProducts);
                    cmdSelectEndProductIDs.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }


        public static void OleDbSelectMaterialInfo(string name, string id)
        {
            try
            {
                query = "SELECT * FROM Materials WHERE Name = ? AND MaterialID = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectMaterialInfo = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectMaterialInfo.Parameters.AddWithValue("?", name);
                    cmdSelectMaterialInfo.Parameters.AddWithValue("?", id);
                    dsMaterials2.Clear();
                    dsMaterials2.Tables.Clear();
                    OleDbdaMaterials.SelectCommand = cmdSelectMaterialInfo;
                    OleDbdaMaterials.Fill(dsMaterials2, dtMaterials);
                    cmdSelectMaterialInfo.ExecuteNonQuery();                   
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectSuppliesInfo(string name, string id)
        {
            try
            {
                query = "SELECT * FROM Supplies WHERE Name = ? AND SupplyID = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectSupplieslInfo = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectSupplieslInfo.Parameters.AddWithValue("?", name);
                    cmdSelectSupplieslInfo.Parameters.AddWithValue("?", id);
                    dsSupplies2.Clear();
                    dsSupplies2.Tables.Clear();
                    OleDbdaSupplies.SelectCommand = cmdSelectSupplieslInfo;
                    OleDbdaSupplies.Fill(dsSupplies2, dtSupplies);
                    cmdSelectSupplieslInfo.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectEndProductInfo(string name, string id)
        {
            try
            {
                query = "SELECT * FROM EndProduct WHERE Name = ? AND EndProductID = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectEndProductInfo = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectEndProductInfo.Parameters.AddWithValue("?", name);
                    cmdSelectEndProductInfo.Parameters.AddWithValue("?", id);
                    dsEndProducts2.Clear();
                    dsEndProducts2.Tables.Clear();
                    OleDbdaEndProducts.SelectCommand = cmdSelectEndProductInfo;
                    OleDbdaEndProducts.Fill(dsEndProducts2, dtEndProducts);
                    cmdSelectEndProductInfo.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectCostToMakeForItem(string name, string id)
        {
            try
            {
                query = "SELECT BuyPrice FROM Materials WHERE [Name] = ? AND [MaterialID] = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSlectCostToMakeForItem = new OleDbCommand(query, OleDbCon))
                {
                    cmdSlectCostToMakeForItem.Parameters.AddWithValue("?", name);
                    cmdSlectCostToMakeForItem.Parameters.AddWithValue("?" , id);
                    dsMaterials.Clear();
                    dsMaterials.Tables.Clear();
                    OleDbdaMaterials.SelectCommand = cmdSlectCostToMakeForItem;
                    OleDbdaMaterials.Fill(dsMaterials, dtMaterials);
                    cmdSlectCostToMakeForItem.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch(Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectMaterialOnHand(string id)
        {
            try
            {
                query = "SELECT OnHand FROM Materials WHERE [MaterialID] = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectMaterialOnHand = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectMaterialOnHand.Parameters.AddWithValue("?", id);
                    dsMaterials.Clear();
                    dsMaterials.Tables.Clear();
                    OleDbdaMaterials.SelectCommand = cmdSelectMaterialOnHand;
                    OleDbdaMaterials.Fill(dsMaterials, dtMaterials);
                    cmdSelectMaterialOnHand.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch(Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        #endregion

        //customer queries
        #region customer queries
        public static void OleDbSelectCustomerInfo(string name, string id)
        {
            try
            {
                query = "SELECT * FROM Customers WHERE Name = ? AND CustomerID = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectCustomerInfo = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectCustomerInfo.Parameters.AddWithValue("?", name);
                    cmdSelectCustomerInfo.Parameters.AddWithValue("?", id);
                    dsCustomers2.Clear();
                    OleDbdaCustomers.SelectCommand = cmdSelectCustomerInfo;
                    OleDbdaCustomers.Fill(dsCustomers2, dtCustomers);
                    cmdSelectCustomerInfo.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectCustomerNames()
        {
            try
            {
                query = "SELECT Name FROM Customers";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectCustomerNames = new OleDbCommand(query, OleDbCon))
                {
                    dsCustomers2.Clear();
                    dsCustomers2.Tables.Clear();
                    OleDbdaCustomers.SelectCommand = cmdSelectCustomerNames;
                    OleDbdaCustomers.Fill(dsCustomers2, dtCustomers);
                    cmdSelectCustomerNames.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }

        public static void OleDbSelectCustomerIDs(string name)
        {
            try
            {
                query = "SELECT CustomerID FROM Customers WHERE Name = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdSelectCustomerIDs = new OleDbCommand(query, OleDbCon))
                {
                    cmdSelectCustomerIDs.Parameters.AddWithValue("?", name);
                    dsCustomers.Clear();
                    dsCustomers.Tables.Clear();
                    OleDbdaCustomers.SelectCommand = cmdSelectCustomerIDs;
                    OleDbdaCustomers.Fill(dsCustomers, dtCustomers);
                    cmdSelectCustomerIDs.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch (Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }
        #endregion

        #endregion

        //***************************  stuff I added later because i needed something relatively specific  ***************************
        #region other stuff

        public static void OleDbDeleteUnfinishedTransaction(string soldProductID)
        {
            try
            {
                query = "DELETE * FROM SoldProduct WHERE SoldProductID = ?";
                OleDbCon.Open();
                using (OleDbCommand cmdDeleteUnfinishedTransaction = new OleDbCommand(query, OleDbCon))
                {
                    cmdDeleteUnfinishedTransaction.Parameters.AddWithValue("?", soldProductID);
                    cmdDeleteUnfinishedTransaction.ExecuteNonQuery();
                }
                OleDbCon.Close();
            }
            catch(Exception ex)
            {
                OleDbCon.Close();
                MessageBox.Show("Error: " + ex);
                return;
            }
        }
        #endregion

        #endregion

        #region backupOnExit
        public static void backupOnExit()//backup all the stuff to sql Database in the closing event of the last open form
        {
            //shove all the data into datasets
            OleDbSelectEndProduct();
            OleDbSelectCustomer();
            OleDbSelectMaterial();
            OleDbSelectSupply();
            OleDbSelectSoldProduct();

            try//just in case the database is down there will be no error on the user's side
            {
                //drop all the rows in the sql database to prepare for inserts
                query = "DELETE FROM SoldProduct";
                SQLCon.Open();
                using (SqlCommand cmdDeleteSoldProduct = new SqlCommand(query, SQLCon))
                    cmdDeleteSoldProduct.ExecuteNonQuery();
                SQLCon.Close();

                query = "DELETE FROM Customers";
                SQLCon.Open();
                using (SqlCommand cmdDeleteCustomers = new SqlCommand(query, SQLCon))
                    cmdDeleteCustomers.ExecuteNonQuery();
                SQLCon.Close();

                query = "DELETE FROM EndProduct";
                SQLCon.Open();
                using (SqlCommand cmdDeleteEndProduct = new SqlCommand(query, SQLCon))
                    cmdDeleteEndProduct.ExecuteNonQuery();
                SQLCon.Close();

                query = "DELETE FROM Supplies";
                SQLCon.Open();
                using (SqlCommand cmdDeleteSupplies = new SqlCommand(query, SQLCon))
                    cmdDeleteSupplies.ExecuteNonQuery();
                SQLCon.Close();

                query = "DELETE FROM Materials";
                SQLCon.Open();
                using (SqlCommand cmdDeleteMaterials = new SqlCommand(query, SQLCon))
                    cmdDeleteMaterials.ExecuteNonQuery();
                SQLCon.Close();

                //take the stuff stored in the datasets and put it all into the sql database using for loops

                for (int i = 0; i < dsEndProducts.Tables[dtEndProducts].Rows.Count; i++) {
                    SQLInsertEndProduct(dsEndProducts.Tables[dtEndProducts].Rows[i][0].ToString(), 
                                        dsEndProducts.Tables[dtEndProducts].Rows[i][1].ToString(),
                                        dsEndProducts.Tables[dtEndProducts].Rows[i][2].ToString(),
                                        dsEndProducts.Tables[dtEndProducts].Rows[i][3].ToString(),
                                        dsEndProducts.Tables[dtEndProducts].Rows[i][4].ToString(),
                                        dsEndProducts.Tables[dtEndProducts].Rows[i][5].ToString(),
                                        dsEndProducts.Tables[dtEndProducts].Rows[i][6].ToString(),
                                        dsEndProducts.Tables[dtEndProducts].Rows[i][7].ToString(),
                                        dsEndProducts.Tables[dtEndProducts].Rows[i][8].ToString(),
                                        dsEndProducts.Tables[dtEndProducts].Rows[i][9].ToString(),
                                        dsEndProducts.Tables[dtEndProducts].Rows[i][10].ToString(),
                                        dsEndProducts.Tables[dtEndProducts].Rows[i][11].ToString(),
                                        dsEndProducts.Tables[dtEndProducts].Rows[i][12].ToString(),
                                        dsEndProducts.Tables[dtEndProducts].Rows[i][13].ToString(),
                                        dsEndProducts.Tables[dtEndProducts].Rows[i][14].ToString(),
                                        dsEndProducts.Tables[dtEndProducts].Rows[i][15].ToString());
                }

                for (int i = 0; i < dsCustomers.Tables[dtCustomers].Rows.Count; i++)
                {
                    SQLInsertCustomer(dsCustomers.Tables[dtCustomers].Rows[i][0].ToString(),
                                      dsCustomers.Tables[dtCustomers].Rows[i][1].ToString(),
                                      dsCustomers.Tables[dtCustomers].Rows[i][2].ToString(),
                                      dsCustomers.Tables[dtCustomers].Rows[i][3].ToString(),
                                      dsCustomers.Tables[dtCustomers].Rows[i][4].ToString(),
                                      dsCustomers.Tables[dtCustomers].Rows[i][5].ToString(),
                                      dsCustomers.Tables[dtCustomers].Rows[i][6].ToString());
                }

                for (int i = 0; i < dsMaterials.Tables[dtMaterials].Rows.Count; i++)
                {
                    SQLInsertMaterial(dsMaterials.Tables[dtMaterials].Rows[i][0].ToString(),
                                      dsMaterials.Tables[dtMaterials].Rows[i][1].ToString(),
                                      dsMaterials.Tables[dtMaterials].Rows[i][2].ToString(),
                                      dsMaterials.Tables[dtMaterials].Rows[i][3].ToString(),
                                      dsMaterials.Tables[dtMaterials].Rows[i][4].ToString(),
                                      dsMaterials.Tables[dtMaterials].Rows[i][5].ToString(),
                                      dsMaterials.Tables[dtMaterials].Rows[i][6].ToString(),
                                      dsMaterials.Tables[dtMaterials].Rows[i][7].ToString(),
                                      dsMaterials.Tables[dtMaterials].Rows[i][8].ToString(),
                                      dsMaterials.Tables[dtMaterials].Rows[i][9].ToString());
                }

                for (int i = 0; i < dsSupplies.Tables[dtSupplies].Rows.Count; i++)
                {
                    SQLInsertSupply(dsSupplies.Tables[dtSupplies].Rows[i][0].ToString(),
                                    dsSupplies.Tables[dtSupplies].Rows[i][1].ToString(),
                                    dsSupplies.Tables[dtSupplies].Rows[i][2].ToString(),
                                    dsSupplies.Tables[dtSupplies].Rows[i][3].ToString(),
                                    dsSupplies.Tables[dtSupplies].Rows[i][4].ToString(),
                                    dsSupplies.Tables[dtSupplies].Rows[i][5].ToString());
                }

                for (int i = 0; i < dsSoldProduct.Tables[dtSoldProduct].Rows.Count; i++)
                {
                    SQLInsertSoldProduct(dsSoldProduct.Tables[dtSoldProduct].Rows[i][0].ToString(),
                                         dsSoldProduct.Tables[dtSoldProduct].Rows[i][1].ToString(),
                                         dsSoldProduct.Tables[dtSoldProduct].Rows[i][2].ToString(),
                                         dsSoldProduct.Tables[dtSoldProduct].Rows[i][3].ToString(),
                                         dsSoldProduct.Tables[dtSoldProduct].Rows[i][4].ToString(),
                                         dsSoldProduct.Tables[dtSoldProduct].Rows[i][5].ToString());
                }

            }
            catch (SqlException)//catch any problem with the server (eg, when there is no internet) and do nothing because you can't backup without being connected to the database.
            {
                SQLCon.Close();
                return;
            }
        }

        #endregion

    }
}
