﻿namespace EllisonM_FinalProject
{
    partial class frmEditInventory
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmEditInventory));
            this.btnSaveAdd = new System.Windows.Forms.Button();
            this.btnBack = new System.Windows.Forms.Button();
            this.pnlEditMaterials = new System.Windows.Forms.Panel();
            this.txtMaterialOnHand = new System.Windows.Forms.NumericUpDown();
            this.lblSelectMaterialID = new System.Windows.Forms.Label();
            this.cbxMaterialID = new System.Windows.Forms.ComboBox();
            this.txtMaterialName = new System.Windows.Forms.TextBox();
            this.lblPleaseSelectAMaterial = new System.Windows.Forms.Label();
            this.cbxMaterials = new System.Windows.Forms.ComboBox();
            this.txtMaterialCondition = new System.Windows.Forms.TextBox();
            this.txtMaterialDimentions = new System.Windows.Forms.TextBox();
            this.txtMaterialSize = new System.Windows.Forms.TextBox();
            this.txtMaterialBuyPrice = new System.Windows.Forms.TextBox();
            this.txtMaterialType = new System.Windows.Forms.TextBox();
            this.txtMaterialColor = new System.Windows.Forms.TextBox();
            this.txtMaterialDescription = new System.Windows.Forms.TextBox();
            this.txtMaterialID = new System.Windows.Forms.TextBox();
            this.lblMaterialCondition = new System.Windows.Forms.Label();
            this.lblMaterialDimentions = new System.Windows.Forms.Label();
            this.lblMaterialSize = new System.Windows.Forms.Label();
            this.lblMaterialOnHand = new System.Windows.Forms.Label();
            this.lblMaterialBuyPrice = new System.Windows.Forms.Label();
            this.lblMaterialType = new System.Windows.Forms.Label();
            this.lblMaterialColor = new System.Windows.Forms.Label();
            this.lblMaterialDescription = new System.Windows.Forms.Label();
            this.lblMaterialID = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnAddMaterial = new System.Windows.Forms.Button();
            this.btnUpdateMaterial = new System.Windows.Forms.Button();
            this.btnAddSupply = new System.Windows.Forms.Button();
            this.btnUpdateSupply = new System.Windows.Forms.Button();
            this.btnUpdateProduct = new System.Windows.Forms.Button();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.pnlEditSuppies = new System.Windows.Forms.Panel();
            this.txtSupplyOnHand = new System.Windows.Forms.NumericUpDown();
            this.lblSelectSupplyID = new System.Windows.Forms.Label();
            this.cbxSupplyID = new System.Windows.Forms.ComboBox();
            this.txtSupplyName = new System.Windows.Forms.TextBox();
            this.txtSupplyCondition = new System.Windows.Forms.TextBox();
            this.txtSupplyBuyPrice = new System.Windows.Forms.TextBox();
            this.txtSupplyDescription = new System.Windows.Forms.TextBox();
            this.txtSupplyID = new System.Windows.Forms.TextBox();
            this.lblSupplyCondition = new System.Windows.Forms.Label();
            this.lblSupplyOnHand = new System.Windows.Forms.Label();
            this.lblSupplyBuyPrice = new System.Windows.Forms.Label();
            this.lblSupplyDescription = new System.Windows.Forms.Label();
            this.lblSupplyID = new System.Windows.Forms.Label();
            this.cbxSupplies = new System.Windows.Forms.ComboBox();
            this.lblPleaseSelectASupply = new System.Windows.Forms.Label();
            this.pnlEditProducts = new System.Windows.Forms.Panel();
            this.txtProductMaterialsUsedID = new System.Windows.Forms.TextBox();
            this.lblProductMaterialUsedID = new System.Windows.Forms.Label();
            this.lblProductMaterialID = new System.Windows.Forms.Label();
            this.lbxProductMaterialsID = new System.Windows.Forms.ListBox();
            this.txtMarkup = new System.Windows.Forms.TextBox();
            this.lblMarkup = new System.Windows.Forms.Label();
            this.txtProductOnHand = new System.Windows.Forms.NumericUpDown();
            this.lblSelectProductID = new System.Windows.Forms.Label();
            this.cbxProductID = new System.Windows.Forms.ComboBox();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.txtProductNotes = new System.Windows.Forms.TextBox();
            this.btnProductSubtractMaterial = new System.Windows.Forms.Button();
            this.btnProductAddMaterial = new System.Windows.Forms.Button();
            this.lblProductMaterials = new System.Windows.Forms.Label();
            this.lbxProductMaterials = new System.Windows.Forms.ListBox();
            this.lblProductMaterialsUsed = new System.Windows.Forms.Label();
            this.lbxProductMaterialsUsed = new System.Windows.Forms.ListBox();
            this.txtProductRunningTotal = new System.Windows.Forms.TextBox();
            this.txtProductCostToMake = new System.Windows.Forms.TextBox();
            this.txtProductSellPrice = new System.Windows.Forms.TextBox();
            this.txtProductDimentions = new System.Windows.Forms.TextBox();
            this.txtProductType = new System.Windows.Forms.TextBox();
            this.txtProductColor = new System.Windows.Forms.TextBox();
            this.txtProductDescription = new System.Windows.Forms.TextBox();
            this.txtProductID = new System.Windows.Forms.TextBox();
            this.lblProductNotes = new System.Windows.Forms.Label();
            this.lblProductRunningTotal = new System.Windows.Forms.Label();
            this.chkProductActive = new System.Windows.Forms.CheckBox();
            this.chkProductCustom = new System.Windows.Forms.CheckBox();
            this.lblProductCostToMake = new System.Windows.Forms.Label();
            this.lblProductType = new System.Windows.Forms.Label();
            this.lblProductColor = new System.Windows.Forms.Label();
            this.lblProductSellPrice = new System.Windows.Forms.Label();
            this.lblProductDimentions = new System.Windows.Forms.Label();
            this.lblProductOnHand = new System.Windows.Forms.Label();
            this.lblProductDescription = new System.Windows.Forms.Label();
            this.lblProductID = new System.Windows.Forms.Label();
            this.cbxProducts = new System.Windows.Forms.ComboBox();
            this.lblPleaseSelectAProduct = new System.Windows.Forms.Label();
            this.pnlEditMaterials.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaterialOnHand)).BeginInit();
            this.pnlEditSuppies.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSupplyOnHand)).BeginInit();
            this.pnlEditProducts.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtProductOnHand)).BeginInit();
            this.SuspendLayout();
            // 
            // btnSaveAdd
            // 
            this.btnSaveAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSaveAdd.BackgroundImage")));
            this.btnSaveAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSaveAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSaveAdd.Font = new System.Drawing.Font("Arial", 12F);
            this.btnSaveAdd.Location = new System.Drawing.Point(558, 470);
            this.btnSaveAdd.Name = "btnSaveAdd";
            this.btnSaveAdd.Size = new System.Drawing.Size(75, 31);
            this.btnSaveAdd.TabIndex = 21;
            this.btnSaveAdd.Text = "Save";
            this.btnSaveAdd.UseVisualStyleBackColor = true;
            this.btnSaveAdd.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnBack
            // 
            this.btnBack.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBack.BackgroundImage")));
            this.btnBack.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnBack.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBack.Font = new System.Drawing.Font("Arial", 12F);
            this.btnBack.Location = new System.Drawing.Point(639, 470);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(75, 31);
            this.btnBack.TabIndex = 22;
            this.btnBack.Text = "Back";
            this.btnBack.UseVisualStyleBackColor = true;
            this.btnBack.Click += new System.EventHandler(this.btnBack_Click);
            // 
            // pnlEditMaterials
            // 
            this.pnlEditMaterials.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlEditMaterials.Controls.Add(this.txtMaterialOnHand);
            this.pnlEditMaterials.Controls.Add(this.lblSelectMaterialID);
            this.pnlEditMaterials.Controls.Add(this.cbxMaterialID);
            this.pnlEditMaterials.Controls.Add(this.txtMaterialName);
            this.pnlEditMaterials.Controls.Add(this.lblPleaseSelectAMaterial);
            this.pnlEditMaterials.Controls.Add(this.cbxMaterials);
            this.pnlEditMaterials.Controls.Add(this.txtMaterialCondition);
            this.pnlEditMaterials.Controls.Add(this.txtMaterialDimentions);
            this.pnlEditMaterials.Controls.Add(this.txtMaterialSize);
            this.pnlEditMaterials.Controls.Add(this.txtMaterialBuyPrice);
            this.pnlEditMaterials.Controls.Add(this.txtMaterialType);
            this.pnlEditMaterials.Controls.Add(this.txtMaterialColor);
            this.pnlEditMaterials.Controls.Add(this.txtMaterialDescription);
            this.pnlEditMaterials.Controls.Add(this.txtMaterialID);
            this.pnlEditMaterials.Controls.Add(this.lblMaterialCondition);
            this.pnlEditMaterials.Controls.Add(this.lblMaterialDimentions);
            this.pnlEditMaterials.Controls.Add(this.lblMaterialSize);
            this.pnlEditMaterials.Controls.Add(this.lblMaterialOnHand);
            this.pnlEditMaterials.Controls.Add(this.lblMaterialBuyPrice);
            this.pnlEditMaterials.Controls.Add(this.lblMaterialType);
            this.pnlEditMaterials.Controls.Add(this.lblMaterialColor);
            this.pnlEditMaterials.Controls.Add(this.lblMaterialDescription);
            this.pnlEditMaterials.Controls.Add(this.lblMaterialID);
            this.pnlEditMaterials.Location = new System.Drawing.Point(12, 34);
            this.pnlEditMaterials.Name = "pnlEditMaterials";
            this.pnlEditMaterials.Size = new System.Drawing.Size(702, 430);
            this.pnlEditMaterials.TabIndex = 3;
            // 
            // txtMaterialOnHand
            // 
            this.txtMaterialOnHand.Font = new System.Drawing.Font("Arial", 12F);
            this.txtMaterialOnHand.Location = new System.Drawing.Point(303, 234);
            this.txtMaterialOnHand.Name = "txtMaterialOnHand";
            this.txtMaterialOnHand.Size = new System.Drawing.Size(116, 26);
            this.txtMaterialOnHand.TabIndex = 10;
            // 
            // lblSelectMaterialID
            // 
            this.lblSelectMaterialID.AutoSize = true;
            this.lblSelectMaterialID.Font = new System.Drawing.Font("Arial", 12F);
            this.lblSelectMaterialID.Location = new System.Drawing.Point(323, 43);
            this.lblSelectMaterialID.Name = "lblSelectMaterialID";
            this.lblSelectMaterialID.Size = new System.Drawing.Size(27, 18);
            this.lblSelectMaterialID.TabIndex = 22;
            this.lblSelectMaterialID.Text = "ID:";
            // 
            // cbxMaterialID
            // 
            this.cbxMaterialID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxMaterialID.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxMaterialID.FormattingEnabled = true;
            this.cbxMaterialID.Location = new System.Drawing.Point(375, 40);
            this.cbxMaterialID.MaxDropDownItems = 100;
            this.cbxMaterialID.Name = "cbxMaterialID";
            this.cbxMaterialID.Size = new System.Drawing.Size(244, 26);
            this.cbxMaterialID.TabIndex = 2;
            this.cbxMaterialID.SelectedIndexChanged += new System.EventHandler(this.cbxMaterialID_SelectedIndexChanged);
            // 
            // txtMaterialName
            // 
            this.txtMaterialName.Font = new System.Drawing.Font("Arial", 12F);
            this.txtMaterialName.Location = new System.Drawing.Point(375, 4);
            this.txtMaterialName.MaxLength = 75;
            this.txtMaterialName.Name = "txtMaterialName";
            this.txtMaterialName.Size = new System.Drawing.Size(192, 26);
            this.txtMaterialName.TabIndex = 1;
            // 
            // lblPleaseSelectAMaterial
            // 
            this.lblPleaseSelectAMaterial.Font = new System.Drawing.Font("Arial", 12F);
            this.lblPleaseSelectAMaterial.Location = new System.Drawing.Point(3, 11);
            this.lblPleaseSelectAMaterial.Name = "lblPleaseSelectAMaterial";
            this.lblPleaseSelectAMaterial.Size = new System.Drawing.Size(350, 20);
            this.lblPleaseSelectAMaterial.TabIndex = 21;
            this.lblPleaseSelectAMaterial.Text = "Please select a material to edit:";
            this.lblPleaseSelectAMaterial.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // cbxMaterials
            // 
            this.cbxMaterials.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxMaterials.FormattingEnabled = true;
            this.cbxMaterials.Location = new System.Drawing.Point(375, 3);
            this.cbxMaterials.MaxDropDownItems = 100;
            this.cbxMaterials.Name = "cbxMaterials";
            this.cbxMaterials.Size = new System.Drawing.Size(244, 26);
            this.cbxMaterials.TabIndex = 1;
            this.cbxMaterials.SelectedIndexChanged += new System.EventHandler(this.cbxMaterials_SelectedIndexChanged);
            // 
            // txtMaterialCondition
            // 
            this.txtMaterialCondition.Font = new System.Drawing.Font("Arial", 12F);
            this.txtMaterialCondition.Location = new System.Drawing.Point(545, 231);
            this.txtMaterialCondition.MaxLength = 20;
            this.txtMaterialCondition.Name = "txtMaterialCondition";
            this.txtMaterialCondition.Size = new System.Drawing.Size(100, 26);
            this.txtMaterialCondition.TabIndex = 11;
            // 
            // txtMaterialDimentions
            // 
            this.txtMaterialDimentions.Font = new System.Drawing.Font("Arial", 12F);
            this.txtMaterialDimentions.Location = new System.Drawing.Point(319, 183);
            this.txtMaterialDimentions.MaxLength = 20;
            this.txtMaterialDimentions.Name = "txtMaterialDimentions";
            this.txtMaterialDimentions.Size = new System.Drawing.Size(100, 26);
            this.txtMaterialDimentions.TabIndex = 7;
            // 
            // txtMaterialSize
            // 
            this.txtMaterialSize.Font = new System.Drawing.Font("Arial", 12F);
            this.txtMaterialSize.Location = new System.Drawing.Point(509, 183);
            this.txtMaterialSize.Name = "txtMaterialSize";
            this.txtMaterialSize.Size = new System.Drawing.Size(136, 26);
            this.txtMaterialSize.TabIndex = 8;
            // 
            // txtMaterialBuyPrice
            // 
            this.txtMaterialBuyPrice.Font = new System.Drawing.Font("Arial", 12F);
            this.txtMaterialBuyPrice.Location = new System.Drawing.Point(90, 234);
            this.txtMaterialBuyPrice.Name = "txtMaterialBuyPrice";
            this.txtMaterialBuyPrice.Size = new System.Drawing.Size(100, 26);
            this.txtMaterialBuyPrice.TabIndex = 9;
            this.txtMaterialBuyPrice.Leave += new System.EventHandler(this.txtMaterialBuyPrice_Leave);
            // 
            // txtMaterialType
            // 
            this.txtMaterialType.Font = new System.Drawing.Font("Arial", 12F);
            this.txtMaterialType.Location = new System.Drawing.Point(279, 81);
            this.txtMaterialType.MaxLength = 50;
            this.txtMaterialType.Name = "txtMaterialType";
            this.txtMaterialType.Size = new System.Drawing.Size(162, 26);
            this.txtMaterialType.TabIndex = 4;
            // 
            // txtMaterialColor
            // 
            this.txtMaterialColor.Font = new System.Drawing.Font("Arial", 12F);
            this.txtMaterialColor.Location = new System.Drawing.Point(61, 183);
            this.txtMaterialColor.MaxLength = 50;
            this.txtMaterialColor.Name = "txtMaterialColor";
            this.txtMaterialColor.Size = new System.Drawing.Size(129, 26);
            this.txtMaterialColor.TabIndex = 6;
            // 
            // txtMaterialDescription
            // 
            this.txtMaterialDescription.Font = new System.Drawing.Font("Arial", 12F);
            this.txtMaterialDescription.Location = new System.Drawing.Point(103, 125);
            this.txtMaterialDescription.MaxLength = 100;
            this.txtMaterialDescription.Multiline = true;
            this.txtMaterialDescription.Name = "txtMaterialDescription";
            this.txtMaterialDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtMaterialDescription.Size = new System.Drawing.Size(569, 52);
            this.txtMaterialDescription.TabIndex = 5;
            // 
            // txtMaterialID
            // 
            this.txtMaterialID.Enabled = false;
            this.txtMaterialID.Font = new System.Drawing.Font("Arial", 12F);
            this.txtMaterialID.Location = new System.Drawing.Point(100, 81);
            this.txtMaterialID.Name = "txtMaterialID";
            this.txtMaterialID.Size = new System.Drawing.Size(70, 26);
            this.txtMaterialID.TabIndex = 3;
            // 
            // lblMaterialCondition
            // 
            this.lblMaterialCondition.AutoSize = true;
            this.lblMaterialCondition.Font = new System.Drawing.Font("Arial", 12F);
            this.lblMaterialCondition.Location = new System.Drawing.Point(459, 237);
            this.lblMaterialCondition.Name = "lblMaterialCondition";
            this.lblMaterialCondition.Size = new System.Drawing.Size(79, 18);
            this.lblMaterialCondition.TabIndex = 9;
            this.lblMaterialCondition.Text = "Condition:";
            // 
            // lblMaterialDimentions
            // 
            this.lblMaterialDimentions.AutoSize = true;
            this.lblMaterialDimentions.Font = new System.Drawing.Font("Arial", 12F);
            this.lblMaterialDimentions.Location = new System.Drawing.Point(220, 189);
            this.lblMaterialDimentions.Name = "lblMaterialDimentions";
            this.lblMaterialDimentions.Size = new System.Drawing.Size(91, 18);
            this.lblMaterialDimentions.TabIndex = 8;
            this.lblMaterialDimentions.Text = "Dimentions:";
            // 
            // lblMaterialSize
            // 
            this.lblMaterialSize.AutoSize = true;
            this.lblMaterialSize.Font = new System.Drawing.Font("Arial", 12F);
            this.lblMaterialSize.Location = new System.Drawing.Point(459, 189);
            this.lblMaterialSize.Name = "lblMaterialSize";
            this.lblMaterialSize.Size = new System.Drawing.Size(43, 18);
            this.lblMaterialSize.TabIndex = 7;
            this.lblMaterialSize.Text = "Size:";
            // 
            // lblMaterialOnHand
            // 
            this.lblMaterialOnHand.AutoSize = true;
            this.lblMaterialOnHand.Font = new System.Drawing.Font("Arial", 12F);
            this.lblMaterialOnHand.Location = new System.Drawing.Point(220, 240);
            this.lblMaterialOnHand.Name = "lblMaterialOnHand";
            this.lblMaterialOnHand.Size = new System.Drawing.Size(73, 18);
            this.lblMaterialOnHand.TabIndex = 6;
            this.lblMaterialOnHand.Text = "On Hand:";
            // 
            // lblMaterialBuyPrice
            // 
            this.lblMaterialBuyPrice.AutoSize = true;
            this.lblMaterialBuyPrice.Font = new System.Drawing.Font("Arial", 12F);
            this.lblMaterialBuyPrice.Location = new System.Drawing.Point(5, 237);
            this.lblMaterialBuyPrice.Name = "lblMaterialBuyPrice";
            this.lblMaterialBuyPrice.Size = new System.Drawing.Size(79, 18);
            this.lblMaterialBuyPrice.TabIndex = 5;
            this.lblMaterialBuyPrice.Text = "Buy Price:";
            // 
            // lblMaterialType
            // 
            this.lblMaterialType.AutoSize = true;
            this.lblMaterialType.Font = new System.Drawing.Font("Arial", 12F);
            this.lblMaterialType.Location = new System.Drawing.Point(222, 87);
            this.lblMaterialType.Name = "lblMaterialType";
            this.lblMaterialType.Size = new System.Drawing.Size(45, 18);
            this.lblMaterialType.TabIndex = 4;
            this.lblMaterialType.Text = "Type:";
            // 
            // lblMaterialColor
            // 
            this.lblMaterialColor.AutoSize = true;
            this.lblMaterialColor.Font = new System.Drawing.Font("Arial", 12F);
            this.lblMaterialColor.Location = new System.Drawing.Point(5, 189);
            this.lblMaterialColor.Name = "lblMaterialColor";
            this.lblMaterialColor.Size = new System.Drawing.Size(50, 18);
            this.lblMaterialColor.TabIndex = 3;
            this.lblMaterialColor.Text = "Color:";
            // 
            // lblMaterialDescription
            // 
            this.lblMaterialDescription.AutoSize = true;
            this.lblMaterialDescription.Font = new System.Drawing.Font("Arial", 12F);
            this.lblMaterialDescription.Location = new System.Drawing.Point(4, 125);
            this.lblMaterialDescription.Name = "lblMaterialDescription";
            this.lblMaterialDescription.Size = new System.Drawing.Size(92, 18);
            this.lblMaterialDescription.TabIndex = 2;
            this.lblMaterialDescription.Text = "Description:";
            // 
            // lblMaterialID
            // 
            this.lblMaterialID.AutoSize = true;
            this.lblMaterialID.Font = new System.Drawing.Font("Arial", 12F);
            this.lblMaterialID.Location = new System.Drawing.Point(4, 87);
            this.lblMaterialID.Name = "lblMaterialID";
            this.lblMaterialID.Size = new System.Drawing.Size(87, 18);
            this.lblMaterialID.TabIndex = 0;
            this.lblMaterialID.Text = "Material ID:";
            // 
            // lblTitle
            // 
            this.lblTitle.BackColor = System.Drawing.Color.Teal;
            this.lblTitle.Font = new System.Drawing.Font("Arial", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(12, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(702, 22);
            this.lblTitle.TabIndex = 3;
            this.lblTitle.Text = "This is a title";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnAddMaterial
            // 
            this.btnAddMaterial.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddMaterial.BackgroundImage")));
            this.btnAddMaterial.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAddMaterial.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddMaterial.Font = new System.Drawing.Font("Arial", 12F);
            this.btnAddMaterial.Location = new System.Drawing.Point(12, 470);
            this.btnAddMaterial.Name = "btnAddMaterial";
            this.btnAddMaterial.Size = new System.Drawing.Size(193, 30);
            this.btnAddMaterial.TabIndex = 20;
            this.btnAddMaterial.Text = "Add New Material";
            this.btnAddMaterial.UseVisualStyleBackColor = true;
            this.btnAddMaterial.Click += new System.EventHandler(this.btnAddMaterial_Click);
            // 
            // btnUpdateMaterial
            // 
            this.btnUpdateMaterial.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpdateMaterial.BackgroundImage")));
            this.btnUpdateMaterial.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnUpdateMaterial.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUpdateMaterial.Font = new System.Drawing.Font("Arial", 12F);
            this.btnUpdateMaterial.Location = new System.Drawing.Point(282, 470);
            this.btnUpdateMaterial.Name = "btnUpdateMaterial";
            this.btnUpdateMaterial.Size = new System.Drawing.Size(193, 30);
            this.btnUpdateMaterial.TabIndex = 21;
            this.btnUpdateMaterial.Text = "Update Existing Material";
            this.btnUpdateMaterial.UseVisualStyleBackColor = true;
            this.btnUpdateMaterial.Click += new System.EventHandler(this.btnUpdateMaterial_Click);
            // 
            // btnAddSupply
            // 
            this.btnAddSupply.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddSupply.BackgroundImage")));
            this.btnAddSupply.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAddSupply.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddSupply.Font = new System.Drawing.Font("Arial", 12F);
            this.btnAddSupply.Location = new System.Drawing.Point(12, 470);
            this.btnAddSupply.Name = "btnAddSupply";
            this.btnAddSupply.Size = new System.Drawing.Size(193, 30);
            this.btnAddSupply.TabIndex = 20;
            this.btnAddSupply.Text = "Add New Supply";
            this.btnAddSupply.UseVisualStyleBackColor = true;
            this.btnAddSupply.Click += new System.EventHandler(this.btnAddSupply_Click);
            // 
            // btnUpdateSupply
            // 
            this.btnUpdateSupply.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpdateSupply.BackgroundImage")));
            this.btnUpdateSupply.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnUpdateSupply.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUpdateSupply.Font = new System.Drawing.Font("Arial", 12F);
            this.btnUpdateSupply.Location = new System.Drawing.Point(282, 470);
            this.btnUpdateSupply.Name = "btnUpdateSupply";
            this.btnUpdateSupply.Size = new System.Drawing.Size(193, 30);
            this.btnUpdateSupply.TabIndex = 21;
            this.btnUpdateSupply.Text = "Update Existing Supply";
            this.btnUpdateSupply.UseVisualStyleBackColor = true;
            this.btnUpdateSupply.Click += new System.EventHandler(this.btnUpdateSupply_Click);
            // 
            // btnUpdateProduct
            // 
            this.btnUpdateProduct.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpdateProduct.BackgroundImage")));
            this.btnUpdateProduct.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnUpdateProduct.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUpdateProduct.Font = new System.Drawing.Font("Arial", 12F);
            this.btnUpdateProduct.Location = new System.Drawing.Point(282, 471);
            this.btnUpdateProduct.Name = "btnUpdateProduct";
            this.btnUpdateProduct.Size = new System.Drawing.Size(193, 30);
            this.btnUpdateProduct.TabIndex = 24;
            this.btnUpdateProduct.Text = "Update Existing Product";
            this.btnUpdateProduct.UseVisualStyleBackColor = true;
            this.btnUpdateProduct.Click += new System.EventHandler(this.btnUpdateProduct_Click);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddProduct.BackgroundImage")));
            this.btnAddProduct.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAddProduct.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddProduct.Font = new System.Drawing.Font("Arial", 12F);
            this.btnAddProduct.Location = new System.Drawing.Point(12, 471);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(193, 30);
            this.btnAddProduct.TabIndex = 23;
            this.btnAddProduct.Text = "Add New Product";
            this.btnAddProduct.UseVisualStyleBackColor = true;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // pnlEditSuppies
            // 
            this.pnlEditSuppies.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlEditSuppies.Controls.Add(this.txtSupplyOnHand);
            this.pnlEditSuppies.Controls.Add(this.lblSelectSupplyID);
            this.pnlEditSuppies.Controls.Add(this.cbxSupplyID);
            this.pnlEditSuppies.Controls.Add(this.txtSupplyName);
            this.pnlEditSuppies.Controls.Add(this.txtSupplyCondition);
            this.pnlEditSuppies.Controls.Add(this.txtSupplyBuyPrice);
            this.pnlEditSuppies.Controls.Add(this.txtSupplyDescription);
            this.pnlEditSuppies.Controls.Add(this.txtSupplyID);
            this.pnlEditSuppies.Controls.Add(this.lblSupplyCondition);
            this.pnlEditSuppies.Controls.Add(this.lblSupplyOnHand);
            this.pnlEditSuppies.Controls.Add(this.lblSupplyBuyPrice);
            this.pnlEditSuppies.Controls.Add(this.lblSupplyDescription);
            this.pnlEditSuppies.Controls.Add(this.lblSupplyID);
            this.pnlEditSuppies.Controls.Add(this.cbxSupplies);
            this.pnlEditSuppies.Controls.Add(this.lblPleaseSelectASupply);
            this.pnlEditSuppies.Location = new System.Drawing.Point(12, 34);
            this.pnlEditSuppies.Name = "pnlEditSuppies";
            this.pnlEditSuppies.Size = new System.Drawing.Size(702, 430);
            this.pnlEditSuppies.TabIndex = 6;
            // 
            // txtSupplyOnHand
            // 
            this.txtSupplyOnHand.Font = new System.Drawing.Font("Arial", 12F);
            this.txtSupplyOnHand.Location = new System.Drawing.Point(92, 134);
            this.txtSupplyOnHand.Name = "txtSupplyOnHand";
            this.txtSupplyOnHand.Size = new System.Drawing.Size(120, 26);
            this.txtSupplyOnHand.TabIndex = 5;
            // 
            // lblSelectSupplyID
            // 
            this.lblSelectSupplyID.AutoSize = true;
            this.lblSelectSupplyID.Font = new System.Drawing.Font("Arial", 12F);
            this.lblSelectSupplyID.Location = new System.Drawing.Point(302, 55);
            this.lblSelectSupplyID.Name = "lblSelectSupplyID";
            this.lblSelectSupplyID.Size = new System.Drawing.Size(27, 18);
            this.lblSelectSupplyID.TabIndex = 24;
            this.lblSelectSupplyID.Text = "ID:";
            // 
            // cbxSupplyID
            // 
            this.cbxSupplyID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSupplyID.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxSupplyID.FormattingEnabled = true;
            this.cbxSupplyID.Location = new System.Drawing.Point(360, 47);
            this.cbxSupplyID.MaxDropDownItems = 100;
            this.cbxSupplyID.Name = "cbxSupplyID";
            this.cbxSupplyID.Size = new System.Drawing.Size(145, 26);
            this.cbxSupplyID.TabIndex = 2;
            this.cbxSupplyID.SelectedIndexChanged += new System.EventHandler(this.cbxSupplyID_SelectedIndexChanged);
            // 
            // txtSupplyName
            // 
            this.txtSupplyName.Font = new System.Drawing.Font("Arial", 12F);
            this.txtSupplyName.Location = new System.Drawing.Point(360, 4);
            this.txtSupplyName.MaxLength = 75;
            this.txtSupplyName.Name = "txtSupplyName";
            this.txtSupplyName.Size = new System.Drawing.Size(218, 26);
            this.txtSupplyName.TabIndex = 1;
            // 
            // txtSupplyCondition
            // 
            this.txtSupplyCondition.Font = new System.Drawing.Font("Arial", 12F);
            this.txtSupplyCondition.Location = new System.Drawing.Point(360, 131);
            this.txtSupplyCondition.MaxLength = 20;
            this.txtSupplyCondition.Name = "txtSupplyCondition";
            this.txtSupplyCondition.Size = new System.Drawing.Size(145, 26);
            this.txtSupplyCondition.TabIndex = 6;
            // 
            // txtSupplyBuyPrice
            // 
            this.txtSupplyBuyPrice.Font = new System.Drawing.Font("Arial", 12F);
            this.txtSupplyBuyPrice.Location = new System.Drawing.Point(359, 93);
            this.txtSupplyBuyPrice.Name = "txtSupplyBuyPrice";
            this.txtSupplyBuyPrice.Size = new System.Drawing.Size(146, 26);
            this.txtSupplyBuyPrice.TabIndex = 4;
            this.txtSupplyBuyPrice.Leave += new System.EventHandler(this.txtSupplyBuyPrice_Leave);
            // 
            // txtSupplyDescription
            // 
            this.txtSupplyDescription.Font = new System.Drawing.Font("Arial", 12F);
            this.txtSupplyDescription.Location = new System.Drawing.Point(103, 185);
            this.txtSupplyDescription.MaxLength = 100;
            this.txtSupplyDescription.Multiline = true;
            this.txtSupplyDescription.Name = "txtSupplyDescription";
            this.txtSupplyDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtSupplyDescription.Size = new System.Drawing.Size(569, 52);
            this.txtSupplyDescription.TabIndex = 7;
            // 
            // txtSupplyID
            // 
            this.txtSupplyID.Enabled = false;
            this.txtSupplyID.Font = new System.Drawing.Font("Arial", 12F);
            this.txtSupplyID.Location = new System.Drawing.Point(92, 93);
            this.txtSupplyID.Name = "txtSupplyID";
            this.txtSupplyID.Size = new System.Drawing.Size(120, 26);
            this.txtSupplyID.TabIndex = 3;
            // 
            // lblSupplyCondition
            // 
            this.lblSupplyCondition.AutoSize = true;
            this.lblSupplyCondition.Font = new System.Drawing.Font("Arial", 12F);
            this.lblSupplyCondition.Location = new System.Drawing.Point(274, 137);
            this.lblSupplyCondition.Name = "lblSupplyCondition";
            this.lblSupplyCondition.Size = new System.Drawing.Size(79, 18);
            this.lblSupplyCondition.TabIndex = 7;
            this.lblSupplyCondition.Text = "Condition:";
            // 
            // lblSupplyOnHand
            // 
            this.lblSupplyOnHand.AutoSize = true;
            this.lblSupplyOnHand.Font = new System.Drawing.Font("Arial", 12F);
            this.lblSupplyOnHand.Location = new System.Drawing.Point(8, 140);
            this.lblSupplyOnHand.Name = "lblSupplyOnHand";
            this.lblSupplyOnHand.Size = new System.Drawing.Size(73, 18);
            this.lblSupplyOnHand.TabIndex = 6;
            this.lblSupplyOnHand.Text = "On Hand:";
            // 
            // lblSupplyBuyPrice
            // 
            this.lblSupplyBuyPrice.AutoSize = true;
            this.lblSupplyBuyPrice.Font = new System.Drawing.Font("Arial", 12F);
            this.lblSupplyBuyPrice.Location = new System.Drawing.Point(274, 100);
            this.lblSupplyBuyPrice.Name = "lblSupplyBuyPrice";
            this.lblSupplyBuyPrice.Size = new System.Drawing.Size(79, 18);
            this.lblSupplyBuyPrice.TabIndex = 5;
            this.lblSupplyBuyPrice.Text = "Buy Price:";
            // 
            // lblSupplyDescription
            // 
            this.lblSupplyDescription.AutoSize = true;
            this.lblSupplyDescription.Font = new System.Drawing.Font("Arial", 12F);
            this.lblSupplyDescription.Location = new System.Drawing.Point(4, 181);
            this.lblSupplyDescription.Name = "lblSupplyDescription";
            this.lblSupplyDescription.Size = new System.Drawing.Size(92, 18);
            this.lblSupplyDescription.TabIndex = 4;
            this.lblSupplyDescription.Text = "Description:";
            // 
            // lblSupplyID
            // 
            this.lblSupplyID.AutoSize = true;
            this.lblSupplyID.Font = new System.Drawing.Font("Arial", 12F);
            this.lblSupplyID.Location = new System.Drawing.Point(4, 99);
            this.lblSupplyID.Name = "lblSupplyID";
            this.lblSupplyID.Size = new System.Drawing.Size(78, 18);
            this.lblSupplyID.TabIndex = 2;
            this.lblSupplyID.Text = "Supply ID:";
            // 
            // cbxSupplies
            // 
            this.cbxSupplies.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxSupplies.FormattingEnabled = true;
            this.cbxSupplies.Location = new System.Drawing.Point(359, 3);
            this.cbxSupplies.Name = "cbxSupplies";
            this.cbxSupplies.Size = new System.Drawing.Size(260, 26);
            this.cbxSupplies.TabIndex = 1;
            this.cbxSupplies.SelectedIndexChanged += new System.EventHandler(this.cbxSupplies_SelectedIndexChanged);
            // 
            // lblPleaseSelectASupply
            // 
            this.lblPleaseSelectASupply.Font = new System.Drawing.Font("Arial", 12F);
            this.lblPleaseSelectASupply.Location = new System.Drawing.Point(4, 11);
            this.lblPleaseSelectASupply.Name = "lblPleaseSelectASupply";
            this.lblPleaseSelectASupply.Size = new System.Drawing.Size(349, 20);
            this.lblPleaseSelectASupply.TabIndex = 0;
            this.lblPleaseSelectASupply.Text = "Please select a supply to edit:";
            this.lblPleaseSelectASupply.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // pnlEditProducts
            // 
            this.pnlEditProducts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlEditProducts.Controls.Add(this.txtProductMaterialsUsedID);
            this.pnlEditProducts.Controls.Add(this.lblProductMaterialUsedID);
            this.pnlEditProducts.Controls.Add(this.lblProductMaterialID);
            this.pnlEditProducts.Controls.Add(this.lbxProductMaterialsID);
            this.pnlEditProducts.Controls.Add(this.txtMarkup);
            this.pnlEditProducts.Controls.Add(this.lblMarkup);
            this.pnlEditProducts.Controls.Add(this.txtProductOnHand);
            this.pnlEditProducts.Controls.Add(this.lblSelectProductID);
            this.pnlEditProducts.Controls.Add(this.cbxProductID);
            this.pnlEditProducts.Controls.Add(this.txtProductName);
            this.pnlEditProducts.Controls.Add(this.txtProductNotes);
            this.pnlEditProducts.Controls.Add(this.btnProductSubtractMaterial);
            this.pnlEditProducts.Controls.Add(this.btnProductAddMaterial);
            this.pnlEditProducts.Controls.Add(this.lblProductMaterials);
            this.pnlEditProducts.Controls.Add(this.lbxProductMaterials);
            this.pnlEditProducts.Controls.Add(this.lblProductMaterialsUsed);
            this.pnlEditProducts.Controls.Add(this.lbxProductMaterialsUsed);
            this.pnlEditProducts.Controls.Add(this.txtProductRunningTotal);
            this.pnlEditProducts.Controls.Add(this.txtProductCostToMake);
            this.pnlEditProducts.Controls.Add(this.txtProductSellPrice);
            this.pnlEditProducts.Controls.Add(this.txtProductDimentions);
            this.pnlEditProducts.Controls.Add(this.txtProductType);
            this.pnlEditProducts.Controls.Add(this.txtProductColor);
            this.pnlEditProducts.Controls.Add(this.txtProductDescription);
            this.pnlEditProducts.Controls.Add(this.txtProductID);
            this.pnlEditProducts.Controls.Add(this.lblProductNotes);
            this.pnlEditProducts.Controls.Add(this.lblProductRunningTotal);
            this.pnlEditProducts.Controls.Add(this.chkProductActive);
            this.pnlEditProducts.Controls.Add(this.chkProductCustom);
            this.pnlEditProducts.Controls.Add(this.lblProductCostToMake);
            this.pnlEditProducts.Controls.Add(this.lblProductType);
            this.pnlEditProducts.Controls.Add(this.lblProductColor);
            this.pnlEditProducts.Controls.Add(this.lblProductSellPrice);
            this.pnlEditProducts.Controls.Add(this.lblProductDimentions);
            this.pnlEditProducts.Controls.Add(this.lblProductOnHand);
            this.pnlEditProducts.Controls.Add(this.lblProductDescription);
            this.pnlEditProducts.Controls.Add(this.lblProductID);
            this.pnlEditProducts.Controls.Add(this.cbxProducts);
            this.pnlEditProducts.Controls.Add(this.lblPleaseSelectAProduct);
            this.pnlEditProducts.Location = new System.Drawing.Point(12, 34);
            this.pnlEditProducts.Name = "pnlEditProducts";
            this.pnlEditProducts.Size = new System.Drawing.Size(702, 430);
            this.pnlEditProducts.TabIndex = 7;
            // 
            // txtProductMaterialsUsedID
            // 
            this.txtProductMaterialsUsedID.Enabled = false;
            this.txtProductMaterialsUsedID.Location = new System.Drawing.Point(248, 353);
            this.txtProductMaterialsUsedID.Multiline = true;
            this.txtProductMaterialsUsedID.Name = "txtProductMaterialsUsedID";
            this.txtProductMaterialsUsedID.Size = new System.Drawing.Size(168, 40);
            this.txtProductMaterialsUsedID.TabIndex = 35;
            // 
            // lblProductMaterialUsedID
            // 
            this.lblProductMaterialUsedID.AutoSize = true;
            this.lblProductMaterialUsedID.Location = new System.Drawing.Point(214, 353);
            this.lblProductMaterialUsedID.Name = "lblProductMaterialUsedID";
            this.lblProductMaterialUsedID.Size = new System.Drawing.Size(30, 20);
            this.lblProductMaterialUsedID.TabIndex = 34;
            this.lblProductMaterialUsedID.Text = "ID:";
            // 
            // lblProductMaterialID
            // 
            this.lblProductMaterialID.AutoSize = true;
            this.lblProductMaterialID.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductMaterialID.Location = new System.Drawing.Point(10, 353);
            this.lblProductMaterialID.Name = "lblProductMaterialID";
            this.lblProductMaterialID.Size = new System.Drawing.Size(27, 18);
            this.lblProductMaterialID.TabIndex = 32;
            this.lblProductMaterialID.Text = "ID:";
            // 
            // lbxProductMaterialsID
            // 
            this.lbxProductMaterialsID.Font = new System.Drawing.Font("Arial", 12F);
            this.lbxProductMaterialsID.FormattingEnabled = true;
            this.lbxProductMaterialsID.ItemHeight = 18;
            this.lbxProductMaterialsID.Location = new System.Drawing.Point(40, 353);
            this.lbxProductMaterialsID.Name = "lbxProductMaterialsID";
            this.lbxProductMaterialsID.Size = new System.Drawing.Size(168, 40);
            this.lbxProductMaterialsID.TabIndex = 16;
            // 
            // txtMarkup
            // 
            this.txtMarkup.Font = new System.Drawing.Font("Arial", 12F);
            this.txtMarkup.Location = new System.Drawing.Point(617, 69);
            this.txtMarkup.Name = "txtMarkup";
            this.txtMarkup.Size = new System.Drawing.Size(78, 26);
            this.txtMarkup.TabIndex = 7;
            this.txtMarkup.Leave += new System.EventHandler(this.txtMarkup_Leave);
            // 
            // lblMarkup
            // 
            this.lblMarkup.AutoSize = true;
            this.lblMarkup.Font = new System.Drawing.Font("Arial", 12F);
            this.lblMarkup.Location = new System.Drawing.Point(545, 71);
            this.lblMarkup.Name = "lblMarkup";
            this.lblMarkup.Size = new System.Drawing.Size(64, 18);
            this.lblMarkup.TabIndex = 29;
            this.lblMarkup.Text = "Markup:";
            // 
            // txtProductOnHand
            // 
            this.txtProductOnHand.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductOnHand.Location = new System.Drawing.Point(100, 202);
            this.txtProductOnHand.Name = "txtProductOnHand";
            this.txtProductOnHand.Size = new System.Drawing.Size(113, 26);
            this.txtProductOnHand.TabIndex = 12;
            // 
            // lblSelectProductID
            // 
            this.lblSelectProductID.AutoSize = true;
            this.lblSelectProductID.Font = new System.Drawing.Font("Arial", 12F);
            this.lblSelectProductID.Location = new System.Drawing.Point(323, 38);
            this.lblSelectProductID.Name = "lblSelectProductID";
            this.lblSelectProductID.Size = new System.Drawing.Size(27, 18);
            this.lblSelectProductID.TabIndex = 28;
            this.lblSelectProductID.Text = "ID:";
            // 
            // cbxProductID
            // 
            this.cbxProductID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxProductID.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxProductID.FormattingEnabled = true;
            this.cbxProductID.Location = new System.Drawing.Point(360, 35);
            this.cbxProductID.MaxDropDownItems = 100;
            this.cbxProductID.Name = "cbxProductID";
            this.cbxProductID.Size = new System.Drawing.Size(260, 26);
            this.cbxProductID.TabIndex = 2;
            this.cbxProductID.SelectedIndexChanged += new System.EventHandler(this.cbxProductID_SelectedIndexChanged);
            // 
            // txtProductName
            // 
            this.txtProductName.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductName.Location = new System.Drawing.Point(360, 4);
            this.txtProductName.MaxLength = 75;
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(207, 26);
            this.txtProductName.TabIndex = 1;
            // 
            // txtProductNotes
            // 
            this.txtProductNotes.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductNotes.Location = new System.Drawing.Point(422, 253);
            this.txtProductNotes.Multiline = true;
            this.txtProductNotes.Name = "txtProductNotes";
            this.txtProductNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtProductNotes.Size = new System.Drawing.Size(273, 158);
            this.txtProductNotes.TabIndex = 20;
            // 
            // btnProductSubtractMaterial
            // 
            this.btnProductSubtractMaterial.Font = new System.Drawing.Font("Arial", 12F);
            this.btnProductSubtractMaterial.Location = new System.Drawing.Point(214, 315);
            this.btnProductSubtractMaterial.Name = "btnProductSubtractMaterial";
            this.btnProductSubtractMaterial.Size = new System.Drawing.Size(28, 28);
            this.btnProductSubtractMaterial.TabIndex = 18;
            this.btnProductSubtractMaterial.Text = "<";
            this.btnProductSubtractMaterial.UseVisualStyleBackColor = true;
            this.btnProductSubtractMaterial.Click += new System.EventHandler(this.btnProductSubtractMaterial_Click);
            // 
            // btnProductAddMaterial
            // 
            this.btnProductAddMaterial.Font = new System.Drawing.Font("Arial", 12F);
            this.btnProductAddMaterial.Location = new System.Drawing.Point(214, 281);
            this.btnProductAddMaterial.Name = "btnProductAddMaterial";
            this.btnProductAddMaterial.Size = new System.Drawing.Size(28, 28);
            this.btnProductAddMaterial.TabIndex = 17;
            this.btnProductAddMaterial.Text = ">";
            this.btnProductAddMaterial.UseVisualStyleBackColor = true;
            this.btnProductAddMaterial.Click += new System.EventHandler(this.btnProductAddMaterial_Click);
            // 
            // lblProductMaterials
            // 
            this.lblProductMaterials.AutoSize = true;
            this.lblProductMaterials.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductMaterials.Location = new System.Drawing.Point(36, 230);
            this.lblProductMaterials.Name = "lblProductMaterials";
            this.lblProductMaterials.Size = new System.Drawing.Size(76, 18);
            this.lblProductMaterials.TabIndex = 26;
            this.lblProductMaterials.Text = "Materials:";
            // 
            // lbxProductMaterials
            // 
            this.lbxProductMaterials.Font = new System.Drawing.Font("Arial", 12F);
            this.lbxProductMaterials.FormattingEnabled = true;
            this.lbxProductMaterials.ItemHeight = 18;
            this.lbxProductMaterials.Location = new System.Drawing.Point(40, 253);
            this.lbxProductMaterials.Name = "lbxProductMaterials";
            this.lbxProductMaterials.Size = new System.Drawing.Size(168, 94);
            this.lbxProductMaterials.TabIndex = 15;
            this.lbxProductMaterials.SelectedIndexChanged += new System.EventHandler(this.lbxProductMaterials_SelectedIndexChanged);
            // 
            // lblProductMaterialsUsed
            // 
            this.lblProductMaterialsUsed.AutoSize = true;
            this.lblProductMaterialsUsed.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductMaterialsUsed.Location = new System.Drawing.Point(246, 230);
            this.lblProductMaterialsUsed.Name = "lblProductMaterialsUsed";
            this.lblProductMaterialsUsed.Size = new System.Drawing.Size(117, 18);
            this.lblProductMaterialsUsed.TabIndex = 24;
            this.lblProductMaterialsUsed.Text = "Materials Used:";
            // 
            // lbxProductMaterialsUsed
            // 
            this.lbxProductMaterialsUsed.Font = new System.Drawing.Font("Arial", 12F);
            this.lbxProductMaterialsUsed.FormattingEnabled = true;
            this.lbxProductMaterialsUsed.ItemHeight = 18;
            this.lbxProductMaterialsUsed.Location = new System.Drawing.Point(248, 253);
            this.lbxProductMaterialsUsed.Name = "lbxProductMaterialsUsed";
            this.lbxProductMaterialsUsed.Size = new System.Drawing.Size(168, 94);
            this.lbxProductMaterialsUsed.TabIndex = 19;
            this.lbxProductMaterialsUsed.SelectedIndexChanged += new System.EventHandler(this.lbxProductMaterialsUsed_SelectedIndexChanged);
            // 
            // txtProductRunningTotal
            // 
            this.txtProductRunningTotal.Enabled = false;
            this.txtProductRunningTotal.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductRunningTotal.Location = new System.Drawing.Point(545, 200);
            this.txtProductRunningTotal.Name = "txtProductRunningTotal";
            this.txtProductRunningTotal.Size = new System.Drawing.Size(123, 26);
            this.txtProductRunningTotal.TabIndex = 14;
            // 
            // txtProductCostToMake
            // 
            this.txtProductCostToMake.Enabled = false;
            this.txtProductCostToMake.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductCostToMake.Location = new System.Drawing.Point(543, 160);
            this.txtProductCostToMake.Name = "txtProductCostToMake";
            this.txtProductCostToMake.Size = new System.Drawing.Size(125, 26);
            this.txtProductCostToMake.TabIndex = 11;
            this.txtProductCostToMake.Leave += new System.EventHandler(this.txtProductCostToMake_Leave);
            // 
            // txtProductSellPrice
            // 
            this.txtProductSellPrice.Enabled = false;
            this.txtProductSellPrice.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductSellPrice.Location = new System.Drawing.Point(446, 69);
            this.txtProductSellPrice.Name = "txtProductSellPrice";
            this.txtProductSellPrice.Size = new System.Drawing.Size(93, 26);
            this.txtProductSellPrice.TabIndex = 6;
            this.txtProductSellPrice.Leave += new System.EventHandler(this.txtProductSellPrice_Leave);
            // 
            // txtProductDimentions
            // 
            this.txtProductDimentions.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductDimentions.Location = new System.Drawing.Point(318, 201);
            this.txtProductDimentions.Name = "txtProductDimentions";
            this.txtProductDimentions.Size = new System.Drawing.Size(85, 26);
            this.txtProductDimentions.TabIndex = 13;
            // 
            // txtProductType
            // 
            this.txtProductType.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductType.Location = new System.Drawing.Point(272, 160);
            this.txtProductType.MaxLength = 50;
            this.txtProductType.Name = "txtProductType";
            this.txtProductType.Size = new System.Drawing.Size(131, 26);
            this.txtProductType.TabIndex = 10;
            // 
            // txtProductColor
            // 
            this.txtProductColor.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductColor.Location = new System.Drawing.Point(100, 160);
            this.txtProductColor.MaxLength = 50;
            this.txtProductColor.Name = "txtProductColor";
            this.txtProductColor.Size = new System.Drawing.Size(113, 26);
            this.txtProductColor.TabIndex = 9;
            // 
            // txtProductDescription
            // 
            this.txtProductDescription.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductDescription.Location = new System.Drawing.Point(100, 101);
            this.txtProductDescription.MaxLength = 100;
            this.txtProductDescription.Multiline = true;
            this.txtProductDescription.Name = "txtProductDescription";
            this.txtProductDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtProductDescription.Size = new System.Drawing.Size(568, 52);
            this.txtProductDescription.TabIndex = 8;
            // 
            // txtProductID
            // 
            this.txtProductID.Enabled = false;
            this.txtProductID.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductID.Location = new System.Drawing.Point(100, 69);
            this.txtProductID.Name = "txtProductID";
            this.txtProductID.Size = new System.Drawing.Size(82, 26);
            this.txtProductID.TabIndex = 3;
            // 
            // lblProductNotes
            // 
            this.lblProductNotes.AutoSize = true;
            this.lblProductNotes.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductNotes.Location = new System.Drawing.Point(419, 232);
            this.lblProductNotes.Name = "lblProductNotes";
            this.lblProductNotes.Size = new System.Drawing.Size(53, 18);
            this.lblProductNotes.TabIndex = 13;
            this.lblProductNotes.Text = "Notes:";
            // 
            // lblProductRunningTotal
            // 
            this.lblProductRunningTotal.AutoSize = true;
            this.lblProductRunningTotal.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductRunningTotal.Location = new System.Drawing.Point(427, 203);
            this.lblProductRunningTotal.Name = "lblProductRunningTotal";
            this.lblProductRunningTotal.Size = new System.Drawing.Size(104, 18);
            this.lblProductRunningTotal.TabIndex = 12;
            this.lblProductRunningTotal.Text = "Running Total:";
            // 
            // chkProductActive
            // 
            this.chkProductActive.AutoSize = true;
            this.chkProductActive.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkProductActive.Font = new System.Drawing.Font("Arial", 12F);
            this.chkProductActive.Location = new System.Drawing.Point(188, 71);
            this.chkProductActive.Name = "chkProductActive";
            this.chkProductActive.Size = new System.Drawing.Size(74, 22);
            this.chkProductActive.TabIndex = 4;
            this.chkProductActive.Text = "Active:";
            this.chkProductActive.UseVisualStyleBackColor = true;
            // 
            // chkProductCustom
            // 
            this.chkProductCustom.AutoSize = true;
            this.chkProductCustom.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkProductCustom.Font = new System.Drawing.Font("Arial", 12F);
            this.chkProductCustom.Location = new System.Drawing.Point(269, 71);
            this.chkProductCustom.Name = "chkProductCustom";
            this.chkProductCustom.Size = new System.Drawing.Size(85, 22);
            this.chkProductCustom.TabIndex = 5;
            this.chkProductCustom.Text = "Custom:";
            this.chkProductCustom.UseVisualStyleBackColor = true;
            // 
            // lblProductCostToMake
            // 
            this.lblProductCostToMake.AutoSize = true;
            this.lblProductCostToMake.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductCostToMake.Location = new System.Drawing.Point(426, 166);
            this.lblProductCostToMake.Name = "lblProductCostToMake";
            this.lblProductCostToMake.Size = new System.Drawing.Size(108, 18);
            this.lblProductCostToMake.TabIndex = 9;
            this.lblProductCostToMake.Text = "Cost To Make:";
            // 
            // lblProductType
            // 
            this.lblProductType.AutoSize = true;
            this.lblProductType.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductType.Location = new System.Drawing.Point(219, 166);
            this.lblProductType.Name = "lblProductType";
            this.lblProductType.Size = new System.Drawing.Size(45, 18);
            this.lblProductType.TabIndex = 8;
            this.lblProductType.Text = "Type:";
            // 
            // lblProductColor
            // 
            this.lblProductColor.AutoSize = true;
            this.lblProductColor.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductColor.Location = new System.Drawing.Point(10, 166);
            this.lblProductColor.Name = "lblProductColor";
            this.lblProductColor.Size = new System.Drawing.Size(88, 18);
            this.lblProductColor.TabIndex = 7;
            this.lblProductColor.Text = "Main Color:";
            // 
            // lblProductSellPrice
            // 
            this.lblProductSellPrice.AutoSize = true;
            this.lblProductSellPrice.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductSellPrice.Location = new System.Drawing.Point(362, 72);
            this.lblProductSellPrice.Name = "lblProductSellPrice";
            this.lblProductSellPrice.Size = new System.Drawing.Size(79, 18);
            this.lblProductSellPrice.TabIndex = 6;
            this.lblProductSellPrice.Text = "Sell Price:";
            // 
            // lblProductDimentions
            // 
            this.lblProductDimentions.AutoSize = true;
            this.lblProductDimentions.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductDimentions.Location = new System.Drawing.Point(223, 202);
            this.lblProductDimentions.Name = "lblProductDimentions";
            this.lblProductDimentions.Size = new System.Drawing.Size(91, 18);
            this.lblProductDimentions.TabIndex = 5;
            this.lblProductDimentions.Text = "Dimentions:";
            // 
            // lblProductOnHand
            // 
            this.lblProductOnHand.AutoSize = true;
            this.lblProductOnHand.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductOnHand.Location = new System.Drawing.Point(10, 205);
            this.lblProductOnHand.Name = "lblProductOnHand";
            this.lblProductOnHand.Size = new System.Drawing.Size(73, 18);
            this.lblProductOnHand.TabIndex = 4;
            this.lblProductOnHand.Text = "On Hand:";
            // 
            // lblProductDescription
            // 
            this.lblProductDescription.AutoSize = true;
            this.lblProductDescription.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductDescription.Location = new System.Drawing.Point(5, 107);
            this.lblProductDescription.Name = "lblProductDescription";
            this.lblProductDescription.Size = new System.Drawing.Size(92, 18);
            this.lblProductDescription.TabIndex = 3;
            this.lblProductDescription.Text = "Description:";
            // 
            // lblProductID
            // 
            this.lblProductID.AutoSize = true;
            this.lblProductID.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductID.Location = new System.Drawing.Point(9, 75);
            this.lblProductID.Name = "lblProductID";
            this.lblProductID.Size = new System.Drawing.Size(85, 18);
            this.lblProductID.TabIndex = 2;
            this.lblProductID.Text = "Product ID:";
            // 
            // cbxProducts
            // 
            this.cbxProducts.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxProducts.FormattingEnabled = true;
            this.cbxProducts.Location = new System.Drawing.Point(359, 3);
            this.cbxProducts.MaxDropDownItems = 100;
            this.cbxProducts.Name = "cbxProducts";
            this.cbxProducts.Size = new System.Drawing.Size(260, 26);
            this.cbxProducts.TabIndex = 1;
            this.cbxProducts.SelectedIndexChanged += new System.EventHandler(this.cbxProducts_SelectedIndexChanged);
            // 
            // lblPleaseSelectAProduct
            // 
            this.lblPleaseSelectAProduct.Font = new System.Drawing.Font("Arial", 12F);
            this.lblPleaseSelectAProduct.Location = new System.Drawing.Point(4, 11);
            this.lblPleaseSelectAProduct.Name = "lblPleaseSelectAProduct";
            this.lblPleaseSelectAProduct.Size = new System.Drawing.Size(349, 20);
            this.lblPleaseSelectAProduct.TabIndex = 0;
            this.lblPleaseSelectAProduct.Text = "Please select a product to edit:";
            this.lblPleaseSelectAProduct.TextAlign = System.Drawing.ContentAlignment.TopRight;
            // 
            // frmEditInventory
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(726, 513);
            this.ControlBox = false;
            this.Controls.Add(this.pnlEditProducts);
            this.Controls.Add(this.pnlEditSuppies);
            this.Controls.Add(this.pnlEditMaterials);
            this.Controls.Add(this.btnUpdateProduct);
            this.Controls.Add(this.btnAddProduct);
            this.Controls.Add(this.btnUpdateSupply);
            this.Controls.Add(this.btnAddSupply);
            this.Controls.Add(this.btnUpdateMaterial);
            this.Controls.Add(this.btnAddMaterial);
            this.Controls.Add(this.btnSaveAdd);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.btnBack);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "frmEditInventory";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Edit Inventory";
            this.Load += new System.EventHandler(this.frmEditInventory_Load);
            this.pnlEditMaterials.ResumeLayout(false);
            this.pnlEditMaterials.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtMaterialOnHand)).EndInit();
            this.pnlEditSuppies.ResumeLayout(false);
            this.pnlEditSuppies.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtSupplyOnHand)).EndInit();
            this.pnlEditProducts.ResumeLayout(false);
            this.pnlEditProducts.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtProductOnHand)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnSaveAdd;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Panel pnlEditMaterials;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnAddMaterial;
        private System.Windows.Forms.Button btnUpdateMaterial;
        private System.Windows.Forms.Button btnAddSupply;
        private System.Windows.Forms.Button btnUpdateSupply;
        private System.Windows.Forms.Button btnUpdateProduct;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.Label lblPleaseSelectAMaterial;
        private System.Windows.Forms.ComboBox cbxMaterials;
        private System.Windows.Forms.TextBox txtMaterialCondition;
        private System.Windows.Forms.TextBox txtMaterialDimentions;
        private System.Windows.Forms.TextBox txtMaterialSize;
        private System.Windows.Forms.TextBox txtMaterialBuyPrice;
        private System.Windows.Forms.TextBox txtMaterialType;
        private System.Windows.Forms.TextBox txtMaterialColor;
        private System.Windows.Forms.TextBox txtMaterialDescription;
        private System.Windows.Forms.TextBox txtMaterialID;
        private System.Windows.Forms.Label lblMaterialCondition;
        private System.Windows.Forms.Label lblMaterialDimentions;
        private System.Windows.Forms.Label lblMaterialSize;
        private System.Windows.Forms.Label lblMaterialOnHand;
        private System.Windows.Forms.Label lblMaterialBuyPrice;
        private System.Windows.Forms.Label lblMaterialType;
        private System.Windows.Forms.Label lblMaterialColor;
        private System.Windows.Forms.Label lblMaterialDescription;
        private System.Windows.Forms.Label lblMaterialID;
        private System.Windows.Forms.Panel pnlEditSuppies;
        private System.Windows.Forms.TextBox txtSupplyCondition;
        private System.Windows.Forms.TextBox txtSupplyBuyPrice;
        private System.Windows.Forms.TextBox txtSupplyDescription;
        private System.Windows.Forms.TextBox txtSupplyID;
        private System.Windows.Forms.Label lblSupplyCondition;
        private System.Windows.Forms.Label lblSupplyOnHand;
        private System.Windows.Forms.Label lblSupplyBuyPrice;
        private System.Windows.Forms.Label lblSupplyDescription;
        private System.Windows.Forms.Label lblSupplyID;
        private System.Windows.Forms.ComboBox cbxSupplies;
        private System.Windows.Forms.Label lblPleaseSelectASupply;
        private System.Windows.Forms.Panel pnlEditProducts;
        private System.Windows.Forms.Label lblPleaseSelectAProduct;
        private System.Windows.Forms.ComboBox cbxProducts;
        private System.Windows.Forms.Label lblProductMaterials;
        private System.Windows.Forms.ListBox lbxProductMaterials;
        private System.Windows.Forms.Label lblProductMaterialsUsed;
        private System.Windows.Forms.ListBox lbxProductMaterialsUsed;
        private System.Windows.Forms.TextBox txtProductRunningTotal;
        private System.Windows.Forms.TextBox txtProductCostToMake;
        private System.Windows.Forms.TextBox txtProductSellPrice;
        private System.Windows.Forms.TextBox txtProductDimentions;
        private System.Windows.Forms.TextBox txtProductType;
        private System.Windows.Forms.TextBox txtProductColor;
        private System.Windows.Forms.TextBox txtProductDescription;
        private System.Windows.Forms.TextBox txtProductID;
        private System.Windows.Forms.Label lblProductNotes;
        private System.Windows.Forms.Label lblProductRunningTotal;
        private System.Windows.Forms.CheckBox chkProductActive;
        private System.Windows.Forms.CheckBox chkProductCustom;
        private System.Windows.Forms.Label lblProductCostToMake;
        private System.Windows.Forms.Label lblProductType;
        private System.Windows.Forms.Label lblProductColor;
        private System.Windows.Forms.Label lblProductSellPrice;
        private System.Windows.Forms.Label lblProductDimentions;
        private System.Windows.Forms.Label lblProductOnHand;
        private System.Windows.Forms.Label lblProductDescription;
        private System.Windows.Forms.Label lblProductID;
        private System.Windows.Forms.TextBox txtProductNotes;
        private System.Windows.Forms.Button btnProductSubtractMaterial;
        private System.Windows.Forms.Button btnProductAddMaterial;
        private System.Windows.Forms.TextBox txtMaterialName;
        private System.Windows.Forms.TextBox txtSupplyName;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Label lblSelectMaterialID;
        private System.Windows.Forms.ComboBox cbxMaterialID;
        private System.Windows.Forms.Label lblSelectSupplyID;
        private System.Windows.Forms.ComboBox cbxSupplyID;
        private System.Windows.Forms.Label lblSelectProductID;
        private System.Windows.Forms.ComboBox cbxProductID;
        private System.Windows.Forms.NumericUpDown txtProductOnHand;
        private System.Windows.Forms.NumericUpDown txtSupplyOnHand;
        private System.Windows.Forms.NumericUpDown txtMaterialOnHand;
        private System.Windows.Forms.TextBox txtMarkup;
        private System.Windows.Forms.Label lblMarkup;
        private System.Windows.Forms.Label lblProductMaterialID;
        private System.Windows.Forms.ListBox lbxProductMaterialsID;
        private System.Windows.Forms.Label lblProductMaterialUsedID;
        private System.Windows.Forms.TextBox txtProductMaterialsUsedID;
    }
}