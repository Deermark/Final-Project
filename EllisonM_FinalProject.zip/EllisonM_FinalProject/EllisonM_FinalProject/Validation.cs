﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EllisonM_FinalProject
{
    class Validation
    {
        public static bool validWholeNum(string input)
        {
            if(input == "") { return false; }
            bool validity = false;
            for (int i = 0; i < input.Length; i++)
            {                                                                           //loops for however many characters there are in input
                if (char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57) { validity = true; }    //checks each character of input to see if it is a number
                else { validity = false; break; }                                       //if input has a non number in it validity is set to false
            }
            return validity;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool validRealNum(string input)
        {
            if (input == "") { return false; }
            bool validity = false;
            int count = 0;
            if (char.Parse(input[0].ToString()) == 45)
            {
                for (int i = 1; i < input.Length; i++)
                {                                       //loops for however many characters there are in input
                    if (char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57) { validity = true; }        //checks each character of input to see if it is a number
                    else
                    {
                        if (char.Parse(input[i].ToString()) == 46 && count == 0) { count = 1; validity = true; }  //checks each character of input to see if it is a period and if count is 0
                        else { validity = false; break; }                                       //if input has a non number in it and count is 1, validity is set to false
                    }
                }
            }
            else
            {                                                                               //if the first position of input is not a minus sign
                for (int i = 0; i < input.Length; i++)
                {                                       //loops for however many characters there are in input
                    if (char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57) { validity = true; }        //checks each character of input to see if it is a number
                    else
                    {
                        if (char.Parse(input[i].ToString()) == 46 && count == 0) { count = 1; validity = true; }  //checks each character of input to see if it is a period and if count is 0
                        else { validity = false; break; }                                       //if input has a non number in it and count is 1, validity is set to false
                    }
                }
            }
            return validity;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool validChar(string input)
        {
            if (input == "") { return false; }
            bool validity = false;
            for (int i = 0; i < input.Length; i++)
            {
                if ((char.Parse(input[i].ToString()) >= 65 && char.Parse(input[i].ToString()) <= 90) || (char.Parse(input[i].ToString()) >= 97 && char.Parse(input[i].ToString()) <= 122)) { validity = true; } //checks to see if all of the characters are alphabetical characters
            }
            return validity;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool validPhoneNum(string input)
        {
            bool validity = false;
            int count = 0;
            if (input.Length == 12)
            {                                                                               //checks to see if the user used the ###-###-#### format
                if (!(char.Parse(input[3].ToString()) == 45 && char.Parse(input[7].ToString()) == 45)) { count = 1; }                                   //checks to see if the dashes are in the places they are supposed to be
                for (int i = 0; i < 3; i++) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57)) { count = 1; } }   //checks the first three positions to see if they are numbers 0-9
                for (int i = 4; i < 6; i++) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57)) { count = 1; } }   //checks the middle three positions to see if they are numbers 0-9
                for (int i = 8; i < 11; i++) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57)) { count = 1; } }  //checks the last four positions to see if they are numbers 0-9
            }
            else if (input.Length == 13)
            {                                                                       //checks to see if the user used the (###)###-#### format
                if (!(char.Parse(input[0].ToString()) == 40 && char.Parse(input[4].ToString()) == 41)) { count = 1; }                                   //checks to see if the () are in the right place
                if (!(char.Parse(input[8].ToString()) == 45)) { count = 1; }                                                          //checks to see if the dash is in place
                for (int i = 1; i < 4; i++) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57)) { count = 1; } }   //checks the first three positions to see if they aer numbers 0-9
                for (int i = 5; i < 7; i++) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57)) { count = 1; } }   //checks the middle three positions to see if they are numbers 0-9
                for (int i = 9; i < 12; i++) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57)) { count = 1; } }  //checks the lastfour positions to see if they are numbers 0-9
            }
            else { count = 1; }                                                                                     //if the user hadn't put in the right format then validity is going to be false
            if (count == 1) { validity = false; }                                                                   //checks to see if count has been changed to one, and if so validity is set to false
            else { validity = true; }                                                                               //otherwise validity is set to true
            return validity;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool validSSN(string input)
        {
            bool validity = false;
            int count = 0;
            if (input.Length == 11)
            {                                                                               //checks to see if the user input the correct length for a ssn
                if (!(char.Parse(input[3].ToString()) == 45 && char.Parse(input[6].ToString()) == 45)) { count = 1; }                                   //checks to see if the dashes are in the places they are supposed to be
                for (int i = 0; i < 3; i++) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57)) { count = 1; } }   //checks the first three positions to see if they are numbers 0-9
                for (int i = 4; i < 5; i++) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57)) { count = 1; } }   //checks the middle two positions to see if they are numbers 0-9
                for (int i = 7; i < 11; i++) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57)) { count = 1; } }  //checks the last four positions  to see if they are numbers 0-9
            }
            else { count = 1; }                                                                                     //if the user hadn't put in the right format then validity is going to be false
            if (count == 1) { validity = false; }                                                                   //checks to se if count has been changed to one ,and if so, validity is set to false
            else { validity = true; }                                                                               //otherwise validity is set to true
            return validity;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool validEmail(string input)
        {
            bool validity = false;
            int count = 0;
            bool foundAt = false;
            bool foundDot = false;
            if (input.Length < 5) { return false; }                                               //checks if the length is too short
            if (char.Parse(input[0].ToString()) == 46) { return false; }                                              //checks if the first position is a dot
            for (int i = 0; i < input.Length; i++)
            {                                               //loops for however long the input is
                if (char.Parse(input[i].ToString()) == 64)
                {                                                           //looks for a @
                    foundAt = true;
                    if (char.Parse(input[i - 1].ToString()) == 46) { return false; }                                  //checks to see if there is a dot right after the @
                    for (int j = i; j < input.Length; j++)
                    {                                       //loops for however long the input is
                        if (char.Parse(input[j].ToString()) == 46)
                        {                                                   //checks the part after the @ to see if ther is at least one dot there
                            if (!(char.Parse(input[j + 1].ToString()) == 46)) { count = 0; foundDot = true; break; }  //checks to see if there is another dot after the previous dot, if there isn't then all is well
                            else { return false; }                                                  //if there is a second dot, then the program straight up returns false
                        }
                        else { count = 1; }                                                         //count is set to one when there isn't a dot at position j
                    }
                    if (foundDot == true) { break; }                                                //when the program finds a valid dot, it exits the for loop
                }
                else { count = 1; }                                                                 //count is set to one when there is no @ at position i
                if (foundAt == true) { break; }                                                     //when the program finds a valid @, it exits the for loop
            }
            if (count == 1) { validity = false; }                                                   //if the user hadn't put in the right format somewhere then validity is going to be false
            else { validity = true; }                                                               //otherwise validity is set to true
            return validity;
        }
        //------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        //This is a bit broken, fix later if needed.

        /*public static bool validDate(string input)
        {
            bool validity = false;
            int count = 0;
            if (input.Length == 10)
            {                                                                                                                                       //checks the length of the input, it should be 10 each time
                for (int i = 0; i < input.Length; i++)
                {
                    if (i == 2 || i == 5) { if (char.Parse(input[i].ToString()) != 47) { count = 1; break; } }                                                                                //checks for slashes
                    if (i == 0) { if (!(char.Parse(input[i].ToString()) == 48 || char.Parse(input[i].ToString()) == 49)) { count = 1; break; } }                                                                //checks the first position, which can only be a 0 or a 1
                    if (i == 1) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57)) { count = 1; break; } }                                                                //checks the second position which can be 0-9
                    if (i == 3)
                    {                                                                                                                                           //checks the fourth position
                        if (char.Parse(input[1].ToString()) == 50)
                        {                                                                                                                           //check to see if it's february
                            if (char.Parse(input[8].ToString()) == 48 && char.Parse(input[9].ToString()) == 48))
                            {                                                                                               //checks the last positions of the year to see if they are zero
                                if (atoi(input.substr(6, 4).c_str()) % 400 == 0)
                                {                                                                                           //check to see if its a leap year
                                    if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 50)) { count = 1; break; }                                                                //checks the fourth position which can be 0-2
                                    if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57)) { count = 1; break; }                                                                //checks the fifth position which can be 0-9
                                }
                                else { count = 1; break; }                                                                                                                  //if its not a leap year year and your using leap year days the input is invalid
                            }
                            else if (char.Parse(input[8].ToString()) != 48 || char.Parse(input[9].ToString()) != 48)
                            {                                                                                           //checks the last positions of the year to see if they are anything but zero
                                if (atoi(input.substr(6, 4).c_str()) % 4 == 0)
                                {                                                                                           //check to see if its a leap year
                                    if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 50)) { count = 1; break; }                                                                //checks the fourth position which can be 0-2
                                    if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57)) { count = 1; break; }                                                                //checks the fifth position which can be 0-9
                                }
                                else { count = 1; break; }                                                                                                                  //if its not a leap year year and your using leap year days the input is invalid
                            }
                            else
                            {                                                                                                                                           //if its not a leap year
                                if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 50)) { count = 1; break; }                                                                    //checks the fourth position which can be 0-2
                                if (!(char.Parse(input[4].ToString()) >= 48 && char.Parse(input[4].ToString()) <= 56)) { count = 1; break; }                                                                    //checks the fifth position which can be 0-8
                            }
                        }
                        else
                        {                                                                                                                                               //if it's not february
                            if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 51)) { count = 1; break; }                                                                        //checks the fourth position which can be 0-3
                            if (char.Parse(input[i].ToString()) == 51)
                            {                                                                                                                       //checks to see if the days goes into the thirties
                                if ((char.Parse(input[0].ToString()) == 48 && char.Parse(input[1].ToString()) == 49) || (char.Parse(input[0].ToString()) == 48 && char.Parse(input[1].ToString()) == 51) || (char.Parse(input[0].ToString()) == 48 && char.Parse(input[1].ToString()) == 53) || (char.Parse(input[0].ToString()) == 48 && char.Parse(input[1].ToString()) == 55) || (char.Parse(input[0].ToString()) == 48 && char.Parse(input[1].ToString()) == 56) || (char.Parse(input[0].ToString()) == 49 && char.Parse(input[1].ToString()) == 48) || (char.Parse(input[0].ToString()) == 49 && char.Parse(input[1].ToString()) == 50))
                                {//checks to see if the month is one that has 31 days
                                    if (!(char.Parse(input[4].ToString()) == 49)) { count = 1; break; }                                                                                       //checks the fifth position which can only be 1
                                }
                                else if ((char.Parse(input[0].ToString()) == 48 && char.Parse(input[1].ToString()) == 52) || (char.Parse(input[0].ToString()) == 48 && char.Parse(input[1].ToString()) == 54) || (char.Parse(input[0].ToString()) == 48 && char.Parse(input[1].ToString()) == 57) || (char.Parse(input[0].ToString()) == 49 && char.Parse(input[1].ToString()) == 49))
                                {//checks to see if the month is one that has 30 days
                                    if (!(char.Parse(input[4].ToString()) == 48)) { count = 1; break; }                                                                                       //checks the fifth position which can only be 0
                                }
                            }
                            else { if (!(char.Parse(input[4].ToString()) >= 48 && char.Parse(input[4].ToString()) <= 57)) { count = 1; break; } }                                                               //checks the fifth position which can be 0-9
                        }
                    }
                    if (i >= 6 && i <= 9) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57)) { count = 1; break; } }                                                      //checks the last four positions which can all be 0-9
                    if (i == 0) { if (char.Parse(input[i].ToString()) == 48 && char.Parse(input[i + 1].ToString()) == 48) { count = 1; break; } }                                                               //checks to see if the months are both at 0
                    if (i == 3) { if (char.Parse(input[i].ToString()) == 48 && char.Parse(input[i + 1].ToString()) == 48) { count = 1; break; } }                                                               //checks to see if the days are both at 0
                }
            }
            else { count = 1; }

            if (count == 1) { validity = false; }                                                                                                                           //if the program finds an error, change validity to false
            else { validity = true; }                                                                                                                                       //if everything works then set validity to true
            return validity;
        }*/
        //------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
        public static bool validTime(string input)
        {
            bool validity = false;
            int count = 0;
            if (input.Length == 8)
            {                                                                                                       //checks the length of the time, it should be 8 each time
                for (int i = 0; i < input.Length; i++)
                {
                    if (i == 2 || i == 5) { if (char.Parse(input[i].ToString()) != 58) { count = 1; break; } }                                                //checks to see if the colons are in the right place
                    if (i == 0) { if (!(char.Parse(input[i].ToString()) == 48 || char.Parse(input[i].ToString()) == 49)) { count = 1; break; } }                                //checks the first position which can be 0-1
                    if (char.Parse(input[0].ToString()) == 49) { if (i == 1) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 50)) { count = 1; break; } } }   //checks to see if the first position is one, then checks the second position which can be 0-2
                    else { if (i == 1) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57)) { count = 1; break; } } }                       //checks the second position which can be 0-9
                    if (i == 3) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 53)) { count = 1; break; } }                                //checks the fourth position which can be 0-6
                    if (i == 4) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57)) { count = 1; break; } }                                //checks the fifth position which can be 0-9
                    if (i == 6) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 53)) { count = 1; break; } }                                //checks the seventh position which can be 0-6
                    if (i == 8) { if (!(char.Parse(input[i].ToString()) >= 48 && char.Parse(input[i].ToString()) <= 57)) { count = 1; break; } }                                //checks the eighth position which can be 0-9
                    if (i == 0) { if (char.Parse(input[i].ToString()) == 48 && char.Parse(input[i + 1].ToString()) == 48) { count = 1; break; } }                               //checks to see if the hour positions are both at 0
                }
            }
            else { count = 1; }

            if (count == 1) { validity = false; }                                                                                           //if the program finds an error, change validity to false
            else { validity = true; }                                                                                                       //if everything works then set validity to true
            return validity;
        }

    }
}
