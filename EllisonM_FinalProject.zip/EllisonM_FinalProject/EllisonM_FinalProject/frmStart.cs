﻿//This form is the start of the application. The class here holds the instances of all the other forms and exiting information.
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EllisonM_FinalProject
{

    public partial class frmStart : Form
    {
        public static frmMain _main = new frmMain();
        public static string _pageType = "";

        public static frmMain main
        {
            get { return _main; }
            set { _main = value; }
        }

        public static string pageType
        {
            get { return _pageType; }
            set { _pageType = value; }
        }

        public frmStart()
        {
            InitializeComponent();
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            pageType = "reports";
            main.ShowDialog();
        }

        private void btnSales_Click(object sender, EventArgs e)
        {
            pageType = "sales";
            main.ShowDialog();
        }

        private void btnCustomers_Click(object sender, EventArgs e)
        {
            pageType = "customers";
            main.ShowDialog();
        }

        private void btnInventory_Click(object sender, EventArgs e)
        {
            pageType = "inventory";
            main.ShowDialog();
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            frmHelp help = new frmHelp();
            help.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void frmStart_FormClosing(object sender, FormClosingEventArgs e)
        {
            DataOps.backupOnExit();
            Application.Exit();
        }

        private void frmStart_Load(object sender, EventArgs e)
        {
            try
            {
                string holder = "";
                StreamReader sr = new StreamReader(".../.../Data/preferences.txt");
                while (!sr.EndOfStream)
                {
                    holder = sr.ReadLine();
                }
                if (holder == "1")
                    frmMain.dontMessage = true;
                else
                    frmMain.dontMessage = false;
                sr.Close();
            }
            catch (Exception)
            {
                MessageBox.Show("The preferences file does not exist.");
            }
        }
    }
}
