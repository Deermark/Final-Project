﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EllisonM_FinalProject
{
    public partial class frmEditInventory : Form
    {
        public frmEditInventory()
        {
            InitializeComponent();
        }

        public List<string> productMaterialsUsedIDs = new List<string> { };//list used for storing usedmaterialids to maintain specificity when adding and removing materials in the edit end product section
        public List<string> productMaterialsUsedIDsOld = new List<string>{ };//list used for storing the original usedmaterialids before adding any new ones.

        private void frmEditInventory_Load(object sender, EventArgs e)
        {
            pnlEditMaterials.Visible = false;
            pnlEditMaterials.Enabled = false;
            pnlEditProducts.Visible = false;
            pnlEditProducts.Enabled = false;
            pnlEditSuppies.Visible = false;
            pnlEditSuppies.Enabled = false;
            switch (frmMain.objective)
            {
                case "edit materials":
                    pnlEditMaterials.Visible = true;
                    pnlEditMaterials.Enabled = true;
                    lblTitle.Text = "Update Materials";
                    btnAddMaterial.Visible = true;
                    btnAddMaterial.Enabled = true;
                    btnUpdateMaterial.Visible = true;
                    btnUpdateMaterial.Enabled = false;

                    btnAddProduct.Visible = false;
                    btnAddProduct.Enabled = false;
                    btnAddSupply.Visible = false;
                    btnAddSupply.Enabled = false;
                    btnUpdateProduct.Visible = false;
                    btnUpdateProduct.Enabled = false;
                    btnUpdateSupply.Visible = false;
                    btnUpdateSupply.Enabled = false;
                    txtMaterialName.Visible = false;
                    txtMaterialName.Enabled = false;

                    DataOps.OleDbSelectMaterialNames();
                    List<string> materialNames = new List<string> { };//make a new list of material names
                    for (int i = 0; i < DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows.Count; i++)//loop for the amount of items in that list
                        materialNames.Add(DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows[i][0].ToString());//add values to that list

                    for (int i = 0; i < materialNames.Count; i++)//loop for the amount of items in the list
                    {
                        string currentMaterial = materialNames[i].ToLower();//make a variable to store the current name at position i
                        if (i != materialNames.Count)//doesn't move on to the next part if i has reached the final position
                        {
                            for (int j = i + 1; j < materialNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                            {
                                string comparedMaterial = materialNames[j].ToLower();//make a variable to store the current name at position j
                                if (currentMaterial == comparedMaterial)//checks if the material at point i is the same as at point j
                                    materialNames.RemoveAt(j);//removes the material at point j if it is the same                     
                            }
                        }
                    }

                    for (int i = 0; i < materialNames.Count; i++)//add names to combo box
                        cbxMaterials.Items.Add(materialNames[i]);
                    cbxMaterials.SelectedIndex = 0;

                    break;
                case "edit supplies":
                    pnlEditSuppies.Visible = true;
                    pnlEditSuppies.Enabled = true;
                    lblTitle.Text = "Update Supplies";
                    btnAddSupply.Visible = true;
                    btnAddSupply.Enabled = true;
                    btnUpdateSupply.Visible = true;
                    btnUpdateSupply.Enabled = false;

                    btnAddProduct.Visible = false;
                    btnAddProduct.Enabled = false;
                    btnAddMaterial.Visible = false;
                    btnAddMaterial.Enabled = false;
                    btnUpdateProduct.Visible = false;
                    btnUpdateProduct.Enabled = false;
                    btnUpdateMaterial.Visible = false;
                    btnUpdateMaterial.Enabled = false;
                    txtSupplyName.Visible = false;
                    txtSupplyName.Enabled = false;

                    DataOps.OleDbSelectSuppliesNames();
                    List<string> suppliesNames = new List<string> { };//make a new list of supply names
                    for (int i = 0; i < DataOps.dsSupplies2.Tables[DataOps.dtSupplies].Rows.Count; i++)//loop for the amount of items in that list
                        suppliesNames.Add(DataOps.dsSupplies2.Tables[DataOps.dtSupplies].Rows[i][0].ToString());//add values to that list

                    for (int i = 0; i < suppliesNames.Count; i++)//loop for the amount of items in the list
                    {
                        string currentSupply = suppliesNames[i].ToLower();//make a variable to store the current name at position i
                        if (i != suppliesNames.Count)//doesn't move on to the next part if i has reached the final position
                        {
                            for (int j = i + 1; j < suppliesNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                            {
                                string comparedSupply = suppliesNames[j].ToLower();//make a variable to store the current name at position j
                                if (currentSupply == comparedSupply)//checks if the supply at point i is the same as at point j
                                    suppliesNames.RemoveAt(j);//removes the supply at point j if it is the same                     
                            }
                        }
                    }

                    for (int i = 0; i < suppliesNames.Count; i++)//add names to combo box
                        cbxSupplies.Items.Add(suppliesNames[i]);
                    cbxSupplies.SelectedIndex = 0;

                    break;
                case "edit products":
                    pnlEditProducts.Visible = true;
                    pnlEditProducts.Enabled = true;
                    lblTitle.Text = "Update Products";
                    btnAddProduct.Visible = true;
                    btnAddProduct.Enabled = true;
                    btnUpdateProduct.Visible = true;
                    btnUpdateProduct.Enabled = false;

                    btnAddSupply.Visible = false;
                    btnAddSupply.Enabled = false;
                    btnAddMaterial.Visible = false;
                    btnAddMaterial.Enabled = false;
                    btnUpdateSupply.Visible = false;
                    btnUpdateSupply.Enabled = false;
                    btnUpdateMaterial.Visible = false;
                    btnUpdateMaterial.Enabled = false;
                    txtProductName.Visible = false;
                    txtProductName.Enabled = false;

                    DataOps.OleDbSelectEndProductNames();
                    List<string> productNames = new List<string> { };//make a new list of product names
                    for (int i = 0; i < DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows.Count; i++)//loop for the amount of items in that list
                        productNames.Add(DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[i][0].ToString());//add values to that list

                    for (int i = 0; i < productNames.Count; i++)//loop for the amount of items in the list
                    {
                        string currentProduct = productNames[i].ToLower();//make a variable to store the current name at position i
                        if (i != productNames.Count)//doesn't move on to the next part if i has reached the final position
                        {
                            for (int j = i + 1; j < productNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                            {
                                string comparedProduct = productNames[j].ToLower();//make a variable to store the current name at position j
                                if (currentProduct == comparedProduct)//checks if the product at point i is the same as at point j
                                    productNames.RemoveAt(j);//removes the product at point j if it is the same                     
                            }
                        }
                    }

                    for (int i = 0; i < productNames.Count; i++)//add names to combo box
                        cbxProducts.Items.Add(productNames[i]);
                    cbxProducts.SelectedIndex = 0;

                    break;
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            //add something that asks if they want to discard any changes
            this.Close();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            //validate stuff then write to database
            switch (frmMain.objective)
            {
                case "edit materials":
                    if (Validation.validRealNum(txtMaterialBuyPrice.Text.Substring(1)) == true)
                    {
                        if (Validation.validWholeNum(txtMaterialOnHand.Text) == true)
                        {
                            if (Validation.validRealNum(txtMaterialSize.Text) == true)
                            {
                                //maybe validate the dimentions and size too, but idk what to do for those
                                switch (lblTitle.Text)
                                {
                                    case "Add New Material":
                                        if (txtMaterialName.Text != "")
                                        {
                                            DataOps.OleDbInsertMaterial(txtMaterialID.Text, txtMaterialName.Text, txtMaterialDescription.Text, txtMaterialColor.Text, txtMaterialType.Text, txtMaterialBuyPrice.Text.Substring(1), txtMaterialOnHand.Text, txtMaterialSize.Text, txtMaterialCondition.Text, txtMaterialDimentions.Text);
                                            MessageBox.Show("Material Successfully Added.");
                                            txtMaterialID.Clear();
                                            txtMaterialDescription.Clear();
                                            txtMaterialColor.Clear();
                                            txtMaterialType.Clear();
                                            txtMaterialBuyPrice.Text = "$0";
                                            txtMaterialOnHand.Value = 0;
                                            txtMaterialSize.Clear();
                                            txtMaterialDimentions.Clear();
                                            txtMaterialName.Clear();
                                            txtMaterialCondition.Clear();

                                            DataOps.OleDbGetNextMaterialID();
                                            txtMaterialID.Text = DataOps.MaterialID;
                                        }
                                        else
                                        {
                                            MessageBox.Show("You must enter a name for this material.");
                                            txtMaterialName.Focus();
                                        }
                                        break;
                                    case "Update Materials":
                                        if (cbxMaterials.Text != "")
                                        {
                                            DataOps.OleDbUpdateMaterial(txtMaterialID.Text, cbxMaterials.Text, txtMaterialDescription.Text, txtMaterialColor.Text, txtMaterialType.Text, txtMaterialBuyPrice.Text.Substring(1), txtMaterialOnHand.Text, txtMaterialSize.Text, txtMaterialCondition.Text, txtMaterialDimentions.Text);
                                            MessageBox.Show("Material Successfully Updated.");
                                        }
                                        else
                                        {
                                            MessageBox.Show("You must enter a name for this material.");
                                            cbxMaterials.Focus();
                                        }
                                        break;
                                }
                                DataOps.OleDbSelectMaterialNames();
                                List<string> materialNames = new List<string> { };//make a new list of material names
                                for (int i = 0; i < DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows.Count; i++)//loop for the amount of items in that list
                                    materialNames.Add(DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows[i][0].ToString());//add values to that list

                                for (int i = 0; i < materialNames.Count; i++)//loop for the amount of items in the list
                                {
                                    string currentMaterial = materialNames[i].ToLower();//make a variable to store the current name at position i
                                    if (i != materialNames.Count)//doesn't move on to the next part if i has reached the final position
                                    {
                                        for (int j = i + 1; j < materialNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                                        {
                                            string comparedMaterial = materialNames[j].ToLower();//make a variable to store the current name at position j
                                            if (currentMaterial == comparedMaterial)//checks if the material at point i is the same as at point j
                                                materialNames.RemoveAt(j);//removes the material at point j if it is the same                     
                                        }
                                    }
                                }

                                for (int i = 0; i < materialNames.Count; i++)//add names to combo box
                                    cbxMaterials.Items.Add(materialNames[i]);
                                cbxMaterials.SelectedIndex = 0;
                            }
                            else
                            {
                                MessageBox.Show("Invalid Number, Please enter a proper real number.");
                                txtMaterialSize.Clear();
                                txtMaterialSize.Focus();
                            }
                        }
                        else
                        {
                            MessageBox.Show("Invalid Number, Please enter a proper whole number.");
                            txtMaterialOnHand.Value = 0;
                            txtMaterialOnHand.Focus();
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid Number, Please enter a proper real number.");
                        txtMaterialBuyPrice.Clear();
                        txtMaterialBuyPrice.Focus();
                    }                                       
                    break;
                case "edit supplies":
                    if(Validation.validRealNum(txtSupplyBuyPrice.Text.Substring(1)) == true)
                    {
                        if (Validation.validWholeNum(txtSupplyOnHand.Text) == true)
                        {
                            switch (lblTitle.Text)
                            {
                                case "Add New Supply":
                                    if (txtSupplyName.Text != "")
                                    {
                                        DataOps.OleDbInsertSupply(txtSupplyID.Text, txtSupplyName.Text, txtSupplyDescription.Text, txtSupplyBuyPrice.Text.Substring(1), txtSupplyOnHand.Text, txtSupplyCondition.Text);
                                        MessageBox.Show("Supply Successfully Added.");
                                        txtSupplyName.Clear();
                                        txtSupplyID.Clear();
                                        txtSupplyDescription.Clear();
                                        txtSupplyBuyPrice.Text = "$0";
                                        txtSupplyOnHand.Value = 0;
                                        txtSupplyCondition.Clear();
                                        txtProductName.Clear();

                                        DataOps.OleDbGetNextSupplyID();
                                        txtSupplyID.Text = DataOps.SupplyID;
                                    }
                                    else
                                    {
                                        MessageBox.Show("You must enter a name for this supply.");
                                        txtSupplyName.Focus();
                                    }
                                    break;
                                case "Update Supplies":
                                    if (cbxSupplies.Text != "")
                                    {
                                        DataOps.OleDbUpdateSupply(txtSupplyID.Text, cbxSupplies.Text, txtSupplyDescription.Text, txtSupplyBuyPrice.Text.Substring(1), txtSupplyOnHand.Text, txtSupplyCondition.Text);
                                        MessageBox.Show("Supply Successfully Updated.");

                                    }
                                    else
                                    {
                                        MessageBox.Show("You must enter a name for this material.");
                                        cbxSupplies.Focus();
                                    }                                   
                                    break;
                            }
                            DataOps.OleDbSelectSuppliesNames();
                            List<string> suppliesNames = new List<string> { };//make a new list of supply names
                            for (int i = 0; i < DataOps.dsSupplies2.Tables[DataOps.dtSupplies].Rows.Count; i++)//loop for the amount of items in that list
                                suppliesNames.Add(DataOps.dsSupplies2.Tables[DataOps.dtSupplies].Rows[i][0].ToString());//add values to that list

                            for (int i = 0; i < suppliesNames.Count; i++)//loop for the amount of items in the list
                            {
                                string currentSupply = suppliesNames[i].ToLower();//make a variable to store the current name at position i
                                if (i != suppliesNames.Count)//doesn't move on to the next part if i has reached the final position
                                {
                                    for (int j = i + 1; j < suppliesNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                                    {
                                        string comparedSupply = suppliesNames[j].ToLower();//make a variable to store the current name at position j
                                        if (currentSupply == comparedSupply)//checks if the supply at point i is the same as at point j
                                            suppliesNames.RemoveAt(j);//removes the supply at point j if it is the same                     
                                    }
                                }
                            }

                            for (int i = 0; i < suppliesNames.Count; i++)//add names to combo box
                                cbxSupplies.Items.Add(suppliesNames[i]);
                            cbxSupplies.SelectedIndex = 0;
                        }
                        else
                        {
                            MessageBox.Show("Invalid Number, Please enter a proper whole number.");
                            txtSupplyOnHand.Value = 0;
                            txtSupplyOnHand.Focus();
                        }
                    }else
                    {
                        MessageBox.Show("Invalid Number, Please enter a proper real number.");
                        txtSupplyBuyPrice.Clear();
                        txtSupplyBuyPrice.Focus();
                    }                  
                    break;
                case "edit products":
                    //check the name of the product, cost to make, on hand, dimentions?, sell price, and check to see if materials is empty
                    if (Validation.validRealNum(txtProductCostToMake.Text.Substring(1)) == true)
                    {
                        if (Validation.validWholeNum(txtProductOnHand.Text) == true)
                        {
                            if (Validation.validRealNum(txtProductSellPrice.Text.Substring(1)) == true)
                            {
                                if (lbxProductMaterialsUsed.Items.Count != 0)
                                {
                                    bool active = false;
                                    bool custom = false;
                                    string materialsUsed = "";
                                    string materialsUsedID = "";
                                    //sort out the check boxes
                                    if(chkProductActive.Checked == true)
                                        active = true;
                                    else
                                        active = false;
                                    if (chkProductCustom.Checked == true)
                                        custom = true;
                                    else
                                        custom = false;

                                    //make a string out of the materialsUsed and materialsUsedIDs
                                    try
                                    {
                                        for (int i = 0; i < lbxProductMaterialsUsed.Items.Count; i++)
                                        {
                                            materialsUsed += lbxProductMaterialsUsed.Items[i].ToString() + ",";
                                            materialsUsedID += productMaterialsUsedIDs[i] + ",";
                                        }
                                    }
                                    catch (Exception) { MessageBox.Show("Error rebuilding materials used id string."); }

                                    //makes a new temporary list to keep the integrity of the other one while performing an operation
                                    List<string> productMaterialsUsedIDsTemp = new List<string> { };
                                    for (int i = 0; i < productMaterialsUsedIDs.Count; i++)
                                        productMaterialsUsedIDsTemp.Add(productMaterialsUsedIDs[i]);

                                    //remove productmaterialsusedidold items from the productmaterilsusedid list
                                    for (int i = 0; i < productMaterialsUsedIDsOld.Count; i++)//loop for the amount of items in the old list
                                    {
                                        for (int j = 0; j < productMaterialsUsedIDsTemp.Count; j++)//loop for the amount of items in the new list
                                        {
                                            if (productMaterialsUsedIDsOld[i] == productMaterialsUsedIDsTemp[j])//checks if the ID at point i is the same as at point j
                                                productMaterialsUsedIDsTemp.RemoveAt(j);//removes the ID at point j if it is the same                     
                                        }
                                    }

                                    switch (lblTitle.Text)
                                    {
                                        case "Add New Product":
                                            if (txtProductName.Text != "")
                                            {                                    
                                                for (int i = 0; i < productMaterialsUsedIDsTemp.Count; i++)//decrement the onhand of the used materials
                                                {
                                                    DataOps.OleDbSelectMaterialOnHand(productMaterialsUsedIDsTemp[i]);//grab specific material on hand
                                                    if (int.Parse(DataOps.dsMaterials.Tables[DataOps.dtMaterials].Rows[0][0].ToString()) > 0)//check to see if the material on hand can decrement
                                                        DataOps.OleDbDecrementMaterialOnHand(productMaterialsUsedIDsTemp[i]);//do the operation if possible
                                                    else
                                                    {
                                                        MessageBox.Show("Not enough materials (of id " + productMaterialsUsedIDsTemp[i] + ") on hand to create product.");//display message if the on hand cannot decrement
                                                        return;//if there is a material that can't decrement, the program avoids the addition
                                                    }
                                                }
                                                DataOps.OleDbInsertEndProduct(txtProductID.Text, txtProductName.Text, txtProductDescription.Text, txtProductColor.Text, txtProductType.Text, txtProductCostToMake.Text, txtProductOnHand.Text, txtProductDimentions.Text, txtProductSellPrice.Text, custom, active, "$0", materialsUsed, materialsUsedID, txtProductNotes.Text, txtMarkup.Text.TrimEnd('%'));
                                                MessageBox.Show("Product Successfully Added.");
                                                txtProductID.Clear();
                                                txtProductDescription.Clear();
                                                txtProductColor.Clear();
                                                txtProductType.Clear();
                                                txtProductCostToMake.Text = "$0";
                                                txtProductOnHand.Value = 0;
                                                txtProductDimentions.Clear();
                                                txtProductSellPrice.Text = "$0";
                                                chkProductCustom.Checked = false;
                                                chkProductActive.Checked = false;
                                                txtProductRunningTotal.Text = "$0";
                                                lbxProductMaterials.Items.Clear();
                                                lbxProductMaterialsUsed.Items.Clear();
                                                lbxProductMaterialsID.Items.Clear();
                                                txtProductMaterialsUsedID.Clear();
                                                txtProductNotes.Clear();
                                                txtMarkup.Text = "0%";
                                                txtProductName.Clear();
                                                productMaterialsUsedIDs.Clear();
                                                productMaterialsUsedIDsOld.Clear();

                                                DataOps.OleDbGetNextEndProductID();
                                                txtProductID.Text = DataOps.EndProductID;

                                                DataOps.OleDbSelectMaterialNames();
                                                List<string> materialNames = new List<string> { };//make a new list of material names
                                                for (int i = 0; i < DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows.Count; i++)//loop for the amount of items in that list
                                                    materialNames.Add(DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows[i][0].ToString());//add values to that list

                                                for (int i = 0; i < materialNames.Count; i++)//loop for the amount of items in the list
                                                {
                                                    string currentMaterial = materialNames[i].ToLower();//make a variable to store the current name at position i
                                                    if (i != materialNames.Count)//doesn't move on to the next part if i has reached the final position
                                                    {
                                                        for (int j = i + 1; j < materialNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                                                        {
                                                            string comparedMaterial = materialNames[j].ToLower();//make a variable to store the current name at position j
                                                            if (currentMaterial == comparedMaterial)//checks if the material at point i is the same as at point j
                                                                materialNames.RemoveAt(j);//removes the material at point j if it is the same                     
                                                        }
                                                    }
                                                }

                                                for (int i = 0; i < materialNames.Count; i++)//add names to combo box
                                                    lbxProductMaterials.Items.Add(materialNames[i]);
                                                lbxProductMaterials.SelectedIndex = 0;
                                            }
                                            else
                                            {
                                                MessageBox.Show("You must enter a name for this product.");
                                                txtProductName.Focus();
                                            }
                                            break;
                                        case "Update Products":
                                            if (cbxProducts.Text != "")
                                            {
                                                for (int i = 0; i < productMaterialsUsedIDsTemp.Count; i++)//decrement the onhand of the used materials
                                                {
                                                    DataOps.OleDbSelectMaterialOnHand(productMaterialsUsedIDsTemp[i]);//grab specific material on hand
                                                    if (int.Parse(DataOps.dsMaterials.Tables[DataOps.dtMaterials].Rows[0][0].ToString()) > 0)//check to see if the material on hand can decrement
                                                        DataOps.OleDbDecrementMaterialOnHand(productMaterialsUsedIDsTemp[i]);//do the operation if possible
                                                    else
                                                    {
                                                        MessageBox.Show("Not enough materials (of id " + productMaterialsUsedIDsTemp[i] + ") on hand to create product.");//display message if the on hand cannot decrement
                                                        return;//if there is a material that can't decrement, the program avoids the update
                                                    }
                                                }
                                                DataOps.OleDbUpdateEndProduct(txtProductID.Text, cbxProducts.Text, txtProductDescription.Text, txtProductColor.Text, txtProductType.Text, txtProductCostToMake.Text, txtProductOnHand.Text, txtProductDimentions.Text, txtProductSellPrice.Text, custom, active, txtProductRunningTotal.Text, materialsUsed, materialsUsedID, txtProductNotes.Text, txtMarkup.Text.TrimEnd('%'));
                                                MessageBox.Show("Product Successfully Updated.");
                                                cbxProducts.Items.Clear();
                                                DataOps.OleDbSelectEndProductNames();
                                                List<string> productNames = new List<string> { };//make a new list of product names
                                                for (int i = 0; i < DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows.Count; i++)//loop for the amount of items in that list
                                                    productNames.Add(DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[i][0].ToString());//add values to that list

                                                for (int i = 0; i < productNames.Count; i++)//loop for the amount of items in the list
                                                {
                                                    string currentProduct = productNames[i].ToLower();//make a variable to store the current name at position i
                                                    if (i != productNames.Count)//doesn't move on to the next part if i has reached the final position
                                                    {
                                                        for (int j = i + 1; j < productNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                                                        {
                                                            string comparedProduct = productNames[j].ToLower();//make a variable to store the current name at position j
                                                            if (currentProduct == comparedProduct)//checks if the product at point i is the same as at point j
                                                                productNames.RemoveAt(j);//removes the product at point j if it is the same                     
                                                        }
                                                    }
                                                }

                                                for (int i = 0; i < productNames.Count; i++)//add names to combo box
                                                    cbxProducts.Items.Add(productNames[i]);
                                                cbxProducts.SelectedIndex = 0;
                                            }
                                            else
                                            {
                                                MessageBox.Show("You must enter a name for this product.");
                                                cbxProducts.Focus();
                                            }
                                            break;
                                    }
                                }
                                else
                                {
                                    MessageBox.Show("You must select which materials were used to make this product.");
                                    lbxProductMaterials.Focus();
                                }                                
                            }else
                            {
                                MessageBox.Show("Invalid Number, Please enter a proper real number.");
                                txtProductSellPrice.Clear();
                                txtProductSellPrice.Focus();
                            }
                        }else
                        {
                            MessageBox.Show("Invalid Number, Please enter a proper whole number.");
                            txtProductOnHand.Value = 0;
                            txtProductOnHand.Focus();
                        }
                    }else
                    {
                        MessageBox.Show("Invalid Number, Please enter a proper real number.");
                        txtProductCostToMake.Clear();
                        txtProductCostToMake.Focus();
                    }
                    break;
            }
        }

        private void btnAddMaterial_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Add New Material"; 
            btnSaveAdd.Text = "Add";
            cbxMaterials.Visible = false;
            cbxMaterials.Enabled = false;
            lblPleaseSelectAMaterial.Text = "Name:";
            cbxMaterialID.Visible = false;
            cbxMaterialID.Enabled = false;
            lblSelectMaterialID.Visible = false;
            txtMaterialName.Visible = true;
            txtMaterialName.Enabled = true;
            btnAddMaterial.Enabled = false;
            btnUpdateMaterial.Enabled = true;

            txtMaterialID.Clear();
            txtMaterialDescription.Clear();
            txtMaterialColor.Clear();
            txtMaterialType.Clear();
            txtMaterialBuyPrice.Text = "$0";
            txtMaterialOnHand.Value = 0;
            txtMaterialSize.Clear();
            txtMaterialDimentions.Clear();
            txtMaterialName.Clear();
            txtMaterialCondition.Clear();

            DataOps.OleDbGetNextMaterialID();
            txtMaterialID.Text = DataOps.MaterialID;
        }

        private void btnUpdateMaterial_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Update Materials";
            btnSaveAdd.Text = "Save";
            cbxMaterials.Visible = true;
            cbxMaterials.Enabled = true;
            lblPleaseSelectAMaterial.Text = "Please select a material to edit:";
            cbxMaterialID.Visible = true;
            cbxMaterialID.Enabled = true;
            lblSelectMaterialID.Visible = true;
            txtMaterialName.Visible = false;
            txtMaterialName.Enabled = false;
            btnAddMaterial.Enabled = true;
            btnUpdateMaterial.Enabled = false;

            txtMaterialID.Clear();
            txtMaterialDescription.Clear();
            txtMaterialColor.Clear();
            txtMaterialType.Clear();
            txtMaterialBuyPrice.Text = "$0";
            txtMaterialOnHand.Value = 0;
            txtMaterialSize.Clear();
            txtMaterialDimentions.Clear();
            txtMaterialCondition.Clear();
            cbxMaterials.Items.Clear();
            cbxMaterialID.Items.Clear();

            DataOps.OleDbSelectMaterialNames();
            List<string> materialNames = new List<string> { };//make a new list of material names
            for (int i = 0; i < DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows.Count; i++)//loop for the amount of items in that list
                materialNames.Add(DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows[i][0].ToString());//add values to that list

            for (int i = 0; i < materialNames.Count; i++)//loop for the amount of items in the list
            {
                string currentMaterial = materialNames[i].ToLower();//make a variable to store the current name at position i
                if (i != materialNames.Count)//doesn't move on to the next part if i has reached the final position
                {
                    for (int j = i + 1; j < materialNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                    {
                        string comparedMaterial = materialNames[j].ToLower();//make a variable to store the current name at position j
                        if (currentMaterial == comparedMaterial)//checks if the material at point i is the same as at point j
                            materialNames.RemoveAt(j);//removes the material at point j if it is the same                     
                    }
                }
            }

            for (int i = 0; i < materialNames.Count; i++)//add names to combo box
                cbxMaterials.Items.Add(materialNames[i]);
            cbxMaterials.SelectedIndex = 0;
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Add New Product";
            btnSaveAdd.Text = "Add";
            cbxProducts.Visible = false;
            cbxProducts.Enabled = false;
            lblPleaseSelectAProduct.Text = "Name:";
            cbxProductID.Visible = false;
            cbxProductID.Enabled = false;
            lblSelectProductID.Visible = false;
            txtProductName.Visible = true;
            txtProductName.Enabled = true;
            btnAddProduct.Enabled = false;
            btnUpdateProduct.Enabled = true;            

            txtProductID.Clear();
            txtProductDescription.Clear();
            txtProductColor.Clear();
            txtProductType.Clear();
            txtProductCostToMake.Text = "$0";
            txtProductOnHand.Value = 0;
            txtProductDimentions.Clear();
            txtProductSellPrice.Text = "$0";
            chkProductCustom.Checked = false;
            chkProductActive.Checked = false;
            txtProductRunningTotal.Text = "$0";
            lbxProductMaterials.Items.Clear();
            lbxProductMaterialsUsed.Items.Clear();
            lbxProductMaterialsID.Items.Clear();
            txtProductMaterialsUsedID.Clear();
            txtProductNotes.Clear();
            txtMarkup.Text = "0%";
            txtProductName.Clear();
            productMaterialsUsedIDs.Clear();
            productMaterialsUsedIDsOld.Clear();

            DataOps.OleDbGetNextEndProductID();
            txtProductID.Text = DataOps.EndProductID;

            DataOps.OleDbSelectMaterialNames();
            List<string> materialNames = new List<string> { };//make a new list of material names
            for (int i = 0; i < DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows.Count; i++)//loop for the amount of items in that list
                materialNames.Add(DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows[i][0].ToString());//add values to that list

            for (int i = 0; i < materialNames.Count; i++)//loop for the amount of items in the list
            {
                string currentMaterial = materialNames[i].ToLower();//make a variable to store the current name at position i
                if (i != materialNames.Count)//doesn't move on to the next part if i has reached the final position
                {
                    for (int j = i + 1; j < materialNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                    {
                        string comparedMaterial = materialNames[j].ToLower();//make a variable to store the current name at position j
                        if (currentMaterial == comparedMaterial)//checks if the material at point i is the same as at point j
                            materialNames.RemoveAt(j);//removes the material at point j if it is the same                     
                    }
                }
            }

            for (int i = 0; i < materialNames.Count; i++)//add names to combo box
                lbxProductMaterials.Items.Add(materialNames[i]);
            lbxProductMaterials.SelectedIndex = 0;
        }

        private void btnUpdateProduct_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Update Products";
            btnSaveAdd.Text = "Save";
            cbxProducts.Visible = true;
            cbxProducts.Enabled = true;
            lblPleaseSelectAProduct.Text = "Please select a product to edit:";
            cbxProductID.Visible = true;
            cbxProductID.Enabled = true;
            lblSelectProductID.Visible = true;
            txtProductName.Visible = false;
            txtProductName.Enabled = false;
            btnAddProduct.Enabled = true;
            btnUpdateProduct.Enabled = false;

            txtProductID.Clear();
            txtProductDescription.Clear();
            txtProductColor.Clear();
            txtProductType.Clear();
            txtProductCostToMake.Clear();
            txtProductOnHand.Value = 0;
            txtProductDimentions.Clear();
            txtProductSellPrice.Clear();
            chkProductCustom.Checked = false;
            chkProductActive.Checked = false;
            txtProductRunningTotal.Clear();
            lbxProductMaterials.Items.Clear();
            lbxProductMaterialsUsed.Items.Clear();
            lbxProductMaterialsID.Items.Clear();
            txtProductMaterialsUsedID.Clear();
            txtProductNotes.Clear();
            cbxProducts.Items.Clear();
            cbxProductID.Items.Clear();
            txtMarkup.Clear();
            productMaterialsUsedIDs.Clear();
            productMaterialsUsedIDsOld.Clear();

            DataOps.OleDbSelectEndProductNames();
            List<string> productNames = new List<string> { };//make a new list of product names
            for (int i = 0; i < DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows.Count; i++)//loop for the amount of items in that list
                productNames.Add(DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[i][0].ToString());//add values to that list

            for (int i = 0; i < productNames.Count; i++)//loop for the amount of items in the list
            {
                string currentProduct = productNames[i].ToLower();//make a variable to store the current name at position i
                if (i != productNames.Count)//doesn't move on to the next part if i has reached the final position
                {
                    for (int j = i + 1; j < productNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                    {
                        string comparedProduct = productNames[j].ToLower();//make a variable to store the current name at position j
                        if (currentProduct == comparedProduct)//checks if the product at point i is the same as at point j
                            productNames.RemoveAt(j);//removes the product at point j if it is the same                     
                    }
                }
            }

            for (int i = 0; i < productNames.Count; i++)//add names to combo box
                cbxProducts.Items.Add(productNames[i]);
            cbxProducts.SelectedIndex = 0;
        }

        private void btnAddSupply_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Add New Supply";
            btnSaveAdd.Text = "Add";
            cbxSupplies.Visible = false;
            cbxSupplies.Enabled = false;
            lblPleaseSelectASupply.Text = "Name:";
            cbxSupplyID.Visible = false;
            cbxSupplyID.Enabled = false;
            lblSelectSupplyID.Visible = false;
            txtSupplyName.Visible = true;
            txtSupplyName.Enabled = true;
            btnAddSupply.Enabled = false;
            btnUpdateSupply.Enabled = true;

            txtSupplyID.Clear();
            txtSupplyDescription.Clear();
            txtSupplyBuyPrice.Text = "$0";
            txtSupplyOnHand.Value = 0;
            txtSupplyCondition.Clear();
            txtProductName.Clear();

            DataOps.OleDbGetNextSupplyID();
            txtSupplyID.Text = DataOps.SupplyID;
        }

        private void btnUpdateSupply_Click(object sender, EventArgs e)
        {
            lblTitle.Text = "Update Supplies";
            btnSaveAdd.Text = "Save";
            cbxSupplies.Visible = true;
            cbxSupplies.Enabled = true;
            lblPleaseSelectASupply.Text = "Please select a supply to edit:";
            cbxSupplyID.Visible = true;
            cbxSupplyID.Enabled = true;
            lblSelectSupplyID.Visible = true;
            txtSupplyName.Visible = false;
            txtSupplyName.Enabled = false;
            btnAddSupply.Enabled = true;
            btnUpdateSupply.Enabled = false;

            txtSupplyID.Clear();
            txtSupplyDescription.Clear();
            txtSupplyBuyPrice.Clear();
            txtSupplyOnHand.Value = 0;
            txtSupplyCondition.Clear();
            cbxSupplies.Items.Clear();
            cbxSupplyID.Items.Clear();

            DataOps.OleDbSelectSuppliesNames();
            List<string> suppliesNames = new List<string> { };//make a new list of supply names
            for (int i = 0; i < DataOps.dsSupplies2.Tables[DataOps.dtSupplies].Rows.Count; i++)//loop for the amount of items in that list
                suppliesNames.Add(DataOps.dsSupplies2.Tables[DataOps.dtSupplies].Rows[i][0].ToString());//add values to that list

            for (int i = 0; i < suppliesNames.Count; i++)//loop for the amount of items in the list
            {
                string currentSupply = suppliesNames[i].ToLower();//make a variable to store the current name at position i
                if (i != suppliesNames.Count)//doesn't move on to the next part if i has reached the final position
                {
                    for (int j = i + 1; j < suppliesNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                    {
                        string comparedSupply = suppliesNames[j].ToLower();//make a variable to store the current name at position j
                        if (currentSupply == comparedSupply)//checks if the supply at point i is the same as at point j
                            suppliesNames.RemoveAt(j);//removes the supply at point j if it is the same                     
                    }
                }
            }

            for (int i = 0; i < suppliesNames.Count; i++)//add names to combo box
                cbxSupplies.Items.Add(suppliesNames[i]);
            cbxSupplies.SelectedIndex = 0;
        }

        //combo box events that host the name and id of the thing to be updated
        private void cbxMaterials_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbxMaterialID.Items.Clear();
            DataOps.OleDbSelectMaterialIDs(cbxMaterials.SelectedItem.ToString());
            for (int i = 0; i < DataOps.dsMaterials.Tables[DataOps.dtMaterials].Rows.Count; i++)
                cbxMaterialID.Items.Add(DataOps.dsMaterials.Tables[DataOps.dtMaterials].Rows[i][0].ToString());
            cbxMaterialID.SelectedIndex = 0;  
        }

        private void cbxMaterialID_SelectedIndexChanged(object sender, EventArgs e)
        {         
            DataOps.OleDbSelectMaterialInfo(cbxMaterials.SelectedItem.ToString(), cbxMaterialID.SelectedItem.ToString());
            txtMaterialID.Text = DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows[0][0].ToString();
            txtMaterialDescription.Text = DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows[0][2].ToString();
            txtMaterialColor.Text = DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows[0][3].ToString();
            txtMaterialType.Text = DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows[0][4].ToString();
            txtMaterialBuyPrice.Text = "$" + DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows[0][5].ToString();
            txtMaterialOnHand.Text = DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows[0][6].ToString();
            txtMaterialSize.Text = DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows[0][7].ToString();
            txtMaterialDimentions.Text = DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows[0][8].ToString();
            txtMaterialCondition.Text = DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows[0][9].ToString();
        }

        private void cbxProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbxProductID.Items.Clear();
            DataOps.OleDbSelectEndProductIDs(cbxProducts.SelectedItem.ToString());
            for (int i = 0; i < DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows.Count; i++)
                cbxProductID.Items.Add(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[i][0].ToString());
            cbxProductID.SelectedIndex = 0;           
        }

        private void cbxProductID_SelectedIndexChanged(object sender, EventArgs e)
        {
            productMaterialsUsedIDs.Clear();
            productMaterialsUsedIDsOld.Clear();
            lbxProductMaterials.Items.Clear();
            lbxProductMaterialsUsed.Items.Clear();
            if (cbxProductID.SelectedItem.ToString() != "")
            {
                DataOps.OleDbSelectEndProductInfo(cbxProducts.SelectedItem.ToString(), cbxProductID.SelectedItem.ToString());
                txtProductID.Text = DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[0][0].ToString();
                txtProductDescription.Text = DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[0][2].ToString();
                txtProductColor.Text = DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[0][3].ToString();
                txtProductType.Text = DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[0][4].ToString();
                txtProductCostToMake.Text = "$" + DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[0][5].ToString();
                txtProductOnHand.Text = DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[0][6].ToString();
                txtProductDimentions.Text = DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[0][7].ToString();
                txtProductSellPrice.Text = "$" + DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[0][8].ToString();
                if (DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[0][9].ToString() == "True")
                    chkProductCustom.Checked = true;
                else
                    chkProductCustom.Checked = false;
                if (DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[0][10].ToString() == "True")
                    chkProductActive.Checked = true;
                else
                    chkProductActive.Checked = false;
                txtProductRunningTotal.Text = "$" + DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[0][11].ToString();
                DataOps.OleDbSelectMaterialNames();
                List<string> materialNames = new List<string> { };//make a new list of material names
                for (int i = 0; i < DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows.Count; i++)//loop for the amount of items in that list
                    materialNames.Add(DataOps.dsMaterials2.Tables[DataOps.dtMaterials].Rows[i][0].ToString());//add values to that list

                for (int i = 0; i < materialNames.Count; i++)//loop for the amount of items in the list
                {
                    string currentMaterial = materialNames[i].ToLower();//make a variable to store the current name at position i
                    if (i != materialNames.Count)//doesn't move on to the next part if i has reached the final position
                    {
                        for (int j = i + 1; j < materialNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                        {
                            string comparedMaterial = materialNames[j].ToLower();//make a variable to store the current name at position j
                            if (currentMaterial == comparedMaterial)//checks if the material at point i is the same as at point j
                                materialNames.RemoveAt(j);//removes the material at point j if it is the same                     
                        }
                    }
                }

                for (int i = 0; i < materialNames.Count; i++)//add names to combo box
                    lbxProductMaterials.Items.Add(materialNames[i]);
                lbxProductMaterials.SelectedIndex = 0;
                //takes the text from the materials used field, splits the commas, then shoves the text into the listbox
                string[] tokens;
                char[] delim = { ',' };
                tokens = DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[0][12].ToString().Split(delim);
                string[] tokens2 = DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[0][15].ToString().Split(delim);
                for (int i = 0; i < tokens.Length - 1; i++)
                {
                    lbxProductMaterialsUsed.Items.Add(tokens[i]);//adds the tokenized materials to the used list box
                    productMaterialsUsedIDs.Add(tokens2[i]);     //adds the tokenized materialsid to the usedid list (this list updates)
                    productMaterialsUsedIDsOld.Add(tokens2[i]);  //adds the tokenized materialsid to the usedidold list (this list does not)
                    for (int j = 0; j < lbxProductMaterials.Items.Count; j++)//loops through the items in the materials list box
                    {
                        if (lbxProductMaterials.Items[j].ToString() == tokens[i])//checks if the items in the materials list box are the same as the current item in the tokenized materials used list box
                            lbxProductMaterials.Items.RemoveAt(j);//removes the duplicate item from the materials list box
                    }
                }
                lbxProductMaterials.SelectedIndex = 0;
                //end of the tokenizing weirdness
                txtProductNotes.Text = DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[0][13].ToString();
                txtMarkup.Text = DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[0][14].ToString() + "%";
            }
        }

        private void cbxSupplies_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbxSupplyID.Items.Clear();
            DataOps.OleDbSelectSuppliesIDs(cbxSupplies.SelectedItem.ToString());
            for (int i = 0; i < DataOps.dsSupplies.Tables[DataOps.dtSupplies].Rows.Count; i++)
                cbxSupplyID.Items.Add(DataOps.dsSupplies.Tables[DataOps.dtSupplies].Rows[i][0].ToString());
            cbxSupplyID.SelectedIndex = 0;            
        }

        private void cbxSupplyID_SelectedIndexChanged(object sender, EventArgs e)
        {            
            DataOps.OleDbSelectSuppliesInfo(cbxSupplies.SelectedItem.ToString(), cbxSupplyID.SelectedItem.ToString());
            txtSupplyID.Text = DataOps.dsSupplies2.Tables[DataOps.dtSupplies].Rows[0][0].ToString();
            txtSupplyDescription.Text = DataOps.dsSupplies2.Tables[DataOps.dtSupplies].Rows[0][2].ToString();
            txtSupplyBuyPrice.Text = "$" + DataOps.dsSupplies2.Tables[DataOps.dtSupplies].Rows[0][3].ToString();
            txtSupplyOnHand.Text = DataOps.dsSupplies2.Tables[DataOps.dtSupplies].Rows[0][4].ToString();
            txtSupplyCondition.Text = DataOps.dsSupplies2.Tables[DataOps.dtSupplies].Rows[0][5].ToString();
        }

        //these are the buttons for the listboxes

        //*****  This method may be a problem because you probably need to be able to use multiple of that material

        private void lbxProductMaterials_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbxProductMaterials.SelectedIndex != -1)
            {
                lbxProductMaterialsID.Items.Clear();
                DataOps.OleDbSelectMaterialIDs(lbxProductMaterials.SelectedItem.ToString());
                for (int i = 0; i < DataOps.dsMaterials.Tables[DataOps.dtMaterials].Rows.Count; i++)
                    lbxProductMaterialsID.Items.Add(DataOps.dsMaterials.Tables[DataOps.dtMaterials].Rows[i][0].ToString());
            }
        }

        private void lbxProductMaterialsUsed_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lbxProductMaterialsUsed.SelectedIndex != -1)
            {
                txtProductMaterialsUsedID.Clear();
                txtProductMaterialsUsedID.Text = productMaterialsUsedIDs[lbxProductMaterialsUsed.SelectedIndex];
            }
        }

        private void btnProductAddMaterial_Click(object sender, EventArgs e)
        {
            if (lbxProductMaterialsID.SelectedIndex != -1)
            {
                if (txtMarkup.Text != "")
                {
                    string ItemToBeMoved = lbxProductMaterials.SelectedItem.ToString();
                    string ItemToBeMovedID = lbxProductMaterialsID.SelectedItem.ToString();
                    DataOps.OleDbSelectCostToMakeForItem(ItemToBeMoved, ItemToBeMovedID);
                    try
                    {
                        string thing = DataOps.dsMaterials.Tables[DataOps.dtMaterials].Rows[0][0].ToString();
                        if (txtProductCostToMake.Text != "")
                            txtProductCostToMake.Text = "$" + (double.Parse(txtProductCostToMake.Text.Substring(1)) + double.Parse(DataOps.dsMaterials.Tables[DataOps.dtMaterials].Rows[0][0].ToString())).ToString();
                        else
                            txtProductCostToMake.Text = "$" + DataOps.dsMaterials.Tables[DataOps.dtMaterials].Rows[0][0].ToString();
                    }
                    catch (Exception ex) { MessageBox.Show("" + ex); }//this is just for debugging purposes, this section has a tendency to explode at seemingly random times. the error says input was in the incorrect format. its referring to the parsing.
                    productMaterialsUsedIDs.Add(lbxProductMaterialsID.SelectedItem.ToString());//add the selected material id to the list of used material ids
                    int ItemIndex = lbxProductMaterials.SelectedIndex;
                    lbxProductMaterialsUsed.Items.Add(ItemToBeMoved);
                    lbxProductMaterials.Items.RemoveAt(ItemIndex);
                    txtProductSellPrice.Text = "$" + (((double.Parse(txtMarkup.Text.TrimEnd('%')) / 100) * (double.Parse(txtProductCostToMake.Text.Substring(1)))) + double.Parse(txtProductCostToMake.Text.Substring(1))).ToString();
                    lbxProductMaterialsID.Items.Clear();
                    lbxProductMaterials.SelectedIndex = 0;
                }
                else
                    MessageBox.Show("Please enter a markup percentage before adding materials.");
            }
            else
                MessageBox.Show("Please select a material (and corresponding material id) to use.");
        }

        private void btnProductSubtractMaterial_Click(object sender, EventArgs e)
        {
            if (lbxProductMaterialsUsed.SelectedIndex != -1)
            {
                if (txtMarkup.Text != "")
                {
                    string ItemToBeMoved = lbxProductMaterialsUsed.SelectedItem.ToString();
                    string ItemToBeMovedID = txtProductMaterialsUsedID.Text;
                    DataOps.OleDbSelectCostToMakeForItem(ItemToBeMoved, ItemToBeMovedID);
                    txtProductCostToMake.Text = "$" + (double.Parse(txtProductCostToMake.Text.Substring(1)) - double.Parse(DataOps.dsMaterials.Tables[DataOps.dtMaterials].Rows[0][0].ToString())).ToString();
                    productMaterialsUsedIDs.RemoveAt(lbxProductMaterialsUsed.SelectedIndex);//remove the selected material id from the list of used material ids
                    int ItemIndex = lbxProductMaterialsUsed.SelectedIndex;
                    lbxProductMaterials.Items.Add(ItemToBeMoved);
                    lbxProductMaterialsUsed.Items.RemoveAt(ItemIndex);
                    txtProductSellPrice.Text = "$" + (((double.Parse(txtMarkup.Text.TrimEnd('%')) / 100) * (double.Parse(txtProductCostToMake.Text.Substring(1)))) + double.Parse(txtProductCostToMake.Text.Substring(1))).ToString();
                    lbxProductMaterialsID.Items.Clear();
                    lbxProductMaterials.SelectedIndex = 0;
                    txtProductMaterialsUsedID.Clear();
                }
                else
                    MessageBox.Show("Please enter a markup percentage before removing materials.");
            }
            else
                MessageBox.Show("Please select a material to remove.");
        }

        private void txtMarkup_Leave(object sender, EventArgs e)
        {
            if (txtMarkup.Text != "")
            {
                if (txtMarkup.Text.Remove(0, txtMarkup.Text.Length - 1) != "%")
                {
                    txtMarkup.Text = txtMarkup.Text + "%";
                }
            }
            if (txtMarkup.Text == "")
                txtMarkup.Text = "0%";
            if (txtProductCostToMake.Text != "" && txtProductSellPrice.Text != "")
                txtProductSellPrice.Text = "$" + (((double.Parse(txtMarkup.Text.TrimEnd('%')) / 100) * (double.Parse(txtProductCostToMake.Text.Substring(1)))) + double.Parse(txtProductCostToMake.Text.Substring(1))).ToString();
        }

        //These 4 things change the textboxes of the fields that need a currency type to have a $ in front no matter what
        private void txtMaterialBuyPrice_Leave(object sender, EventArgs e)
        {
            if (txtMaterialBuyPrice.Text != "")
            {
                if (txtMaterialBuyPrice.Text.Remove(1, txtMaterialBuyPrice.Text.Length - 1) != "$")
                {
                    txtMaterialBuyPrice.Text = "$" + txtMaterialBuyPrice.Text;
                }
            }
        }

        private void txtSupplyBuyPrice_Leave(object sender, EventArgs e)
        {
            if (txtSupplyBuyPrice.Text != "")
            {
                if (txtSupplyBuyPrice.Text.Remove(1, txtSupplyBuyPrice.Text.Length - 1) != "$")
                {
                    txtSupplyBuyPrice.Text = "$" + txtSupplyBuyPrice.Text;
                }
            }
        }

        private void txtProductCostToMake_Leave(object sender, EventArgs e)
        {
            if (txtProductCostToMake.Text != "")
            {
                if (txtProductCostToMake.Text.Remove(1, txtProductCostToMake.Text.Length - 1) != "$")
                {
                    txtProductCostToMake.Text = "$" + txtProductCostToMake.Text;
                }
            }
        }

        private void txtProductSellPrice_Leave(object sender, EventArgs e)
        {
            if (txtProductSellPrice.Text != "")
            {
                if (txtProductSellPrice.Text.Remove(1, txtProductSellPrice.Text.Length - 1) != "$")
                {
                    txtProductSellPrice.Text = "$" + txtProductSellPrice.Text;
                }
            }
        }
    }
}
