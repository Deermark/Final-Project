﻿namespace EllisonM_FinalProject
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            this.lblTitle = new System.Windows.Forms.Label();
            this.btnMain = new System.Windows.Forms.Button();
            this.btnReports = new System.Windows.Forms.Button();
            this.btnSales = new System.Windows.Forms.Button();
            this.btnCustomers = new System.Windows.Forms.Button();
            this.lblMaterialsAndGeneralLabel = new System.Windows.Forms.Label();
            this.pbxLogo = new System.Windows.Forms.PictureBox();
            this.lblNavigation = new System.Windows.Forms.Label();
            this.btnHelp = new System.Windows.Forms.Button();
            this.lblShowOneTable = new System.Windows.Forms.Label();
            this.btnViewProducts = new System.Windows.Forms.Button();
            this.btnViewSupplies = new System.Windows.Forms.Button();
            this.btnViewMaterials = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.lblAddUpdateInventory = new System.Windows.Forms.Label();
            this.btnMaterialsEdit = new System.Windows.Forms.Button();
            this.btnSuppliesEdit = new System.Windows.Forms.Button();
            this.btnProductsEdit = new System.Windows.Forms.Button();
            this.btnViewCustomer = new System.Windows.Forms.Button();
            this.btnUpdateCustomer = new System.Windows.Forms.Button();
            this.btnAddCustomer = new System.Windows.Forms.Button();
            this.lblEditCustomerInformation = new System.Windows.Forms.Label();
            this.btnCustomerReport = new System.Windows.Forms.Button();
            this.btnInventoryReport = new System.Windows.Forms.Button();
            this.btnSalesReport = new System.Windows.Forms.Button();
            this.btnInventory = new System.Windows.Forms.Button();
            this.pnlReports = new System.Windows.Forms.Panel();
            this.crvReport = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.pnlViewStuff = new System.Windows.Forms.Panel();
            this.crvViewInventory = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.pnlCustomer = new System.Windows.Forms.Panel();
            this.pnlViewCustomer = new System.Windows.Forms.Panel();
            this.crvViewCustomers = new CrystalDecisions.Windows.Forms.CrystalReportViewer();
            this.pnlAddUpdateCustomer = new System.Windows.Forms.Panel();
            this.lblSelectCustomerID = new System.Windows.Forms.Label();
            this.dtCustomerBirthday = new System.Windows.Forms.DateTimePicker();
            this.btnCustomerSaveAdd = new System.Windows.Forms.Button();
            this.txtCustomerName = new System.Windows.Forms.TextBox();
            this.txtCustomerItemsPurchased = new System.Windows.Forms.TextBox();
            this.txtCustomerPhone = new System.Windows.Forms.TextBox();
            this.txtCustomerAddress = new System.Windows.Forms.TextBox();
            this.txtCustomerEmail = new System.Windows.Forms.TextBox();
            this.txtCustomerID = new System.Windows.Forms.TextBox();
            this.lblCustomerItemsPurchased = new System.Windows.Forms.Label();
            this.lblCustomerBirthday = new System.Windows.Forms.Label();
            this.lblCustomerPhone = new System.Windows.Forms.Label();
            this.lblCustomerAddress = new System.Windows.Forms.Label();
            this.lblCustomerEmail = new System.Windows.Forms.Label();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.cbxCustomers = new System.Windows.Forms.ComboBox();
            this.cbxCustomerID = new System.Windows.Forms.ComboBox();
            this.lblSelectACustomerName = new System.Windows.Forms.Label();
            this.pnlSales = new System.Windows.Forms.Panel();
            this.pnlViewSales = new System.Windows.Forms.Panel();
            this.txtNumberOfProductSold = new System.Windows.Forms.TextBox();
            this.lblNumberOfProductSold = new System.Windows.Forms.Label();
            this.cbxSoldProductID = new System.Windows.Forms.ComboBox();
            this.lblPleaseSelectTransactionID = new System.Windows.Forms.Label();
            this.txtProfitFromProduct = new System.Windows.Forms.TextBox();
            this.lblProfitFromProduct = new System.Windows.Forms.Label();
            this.cbxProductsView = new System.Windows.Forms.ComboBox();
            this.lblProductsSold = new System.Windows.Forms.Label();
            this.txtProductNotes = new System.Windows.Forms.TextBox();
            this.lblTotalProfitAfterMessage = new System.Windows.Forms.Label();
            this.lblProductMaterialsUsed = new System.Windows.Forms.Label();
            this.txtTotalProfit = new System.Windows.Forms.TextBox();
            this.lbxProductMaterialsUsed = new System.Windows.Forms.ListBox();
            this.lblTotalProfit = new System.Windows.Forms.Label();
            this.txtProductRunningTotal = new System.Windows.Forms.TextBox();
            this.txtMarkupPercentage = new System.Windows.Forms.TextBox();
            this.txtProductDimentions = new System.Windows.Forms.TextBox();
            this.lblMarkupPercentage = new System.Windows.Forms.Label();
            this.txtProductColor = new System.Windows.Forms.TextBox();
            this.cbxSalesIDView = new System.Windows.Forms.ComboBox();
            this.txtProductDescription = new System.Windows.Forms.TextBox();
            this.lblSalesIDView = new System.Windows.Forms.Label();
            this.txtProductID = new System.Windows.Forms.TextBox();
            this.rdoSortByDateSoldView = new System.Windows.Forms.RadioButton();
            this.lblProductNotes = new System.Windows.Forms.Label();
            this.txtDateSold = new System.Windows.Forms.TextBox();
            this.lblProductRunningTotal = new System.Windows.Forms.Label();
            this.txtProductCostToMake = new System.Windows.Forms.TextBox();
            this.chkProductActive = new System.Windows.Forms.CheckBox();
            this.chkProductCustom = new System.Windows.Forms.CheckBox();
            this.rdoSortByCustomerView = new System.Windows.Forms.RadioButton();
            this.lblProductColor = new System.Windows.Forms.Label();
            this.cbxTransactionView = new System.Windows.Forms.ComboBox();
            this.lblProductDimentions = new System.Windows.Forms.Label();
            this.txtStore = new System.Windows.Forms.TextBox();
            this.lblProductDescription = new System.Windows.Forms.Label();
            this.lblStore = new System.Windows.Forms.Label();
            this.lblProductID = new System.Windows.Forms.Label();
            this.lblDateSold = new System.Windows.Forms.Label();
            this.txtAmountSold = new System.Windows.Forms.TextBox();
            this.lblProductCostToMake = new System.Windows.Forms.Label();
            this.lblAmoutSold = new System.Windows.Forms.Label();
            this.txtSalesCustomerTotalItemsPurchased = new System.Windows.Forms.TextBox();
            this.lblSalesCustomerTotalItemsPurchased = new System.Windows.Forms.Label();
            this.txtSalesCustomerName = new System.Windows.Forms.TextBox();
            this.lblSalesCustomerName = new System.Windows.Forms.Label();
            this.lblCustomerInfo = new System.Windows.Forms.Label();
            this.lblSalesInfo = new System.Windows.Forms.Label();
            this.lblPleaseSelectTransactionView = new System.Windows.Forms.Label();
            this.lblProductInformation = new System.Windows.Forms.Label();
            this.txtProductName = new System.Windows.Forms.TextBox();
            this.lblProductName = new System.Windows.Forms.Label();
            this.txtProductSellPrice = new System.Windows.Forms.TextBox();
            this.lblProductSellPrice = new System.Windows.Forms.Label();
            this.txtProductOnHand = new System.Windows.Forms.TextBox();
            this.txtProductType = new System.Windows.Forms.TextBox();
            this.lblProductOnHand = new System.Windows.Forms.Label();
            this.lblProductType = new System.Windows.Forms.Label();
            this.pnlMakeUpdateTransaction = new System.Windows.Forms.Panel();
            this.txtProductsSoldIDEdit = new System.Windows.Forms.TextBox();
            this.cbxSoldProductIDEdit = new System.Windows.Forms.ComboBox();
            this.lblPleaseSelectATransactionID = new System.Windows.Forms.Label();
            this.btnEditAmountSold = new System.Windows.Forms.Button();
            this.txtAmountSoldEdit2 = new System.Windows.Forms.TextBox();
            this.lblProductsSoldID = new System.Windows.Forms.Label();
            this.dtDateSoldEdit = new System.Windows.Forms.DateTimePicker();
            this.cbxCustomerIDEdit = new System.Windows.Forms.ComboBox();
            this.lblCustomerIDEdit = new System.Windows.Forms.Label();
            this.cbxCustomerEdit = new System.Windows.Forms.ComboBox();
            this.lblPleaseSelectACustomer = new System.Windows.Forms.Label();
            this.lblProductIDSales = new System.Windows.Forms.Label();
            this.btnUpdateAddSales = new System.Windows.Forms.Button();
            this.btnUpdateMarkup = new System.Windows.Forms.Button();
            this.txtProfitEdit = new System.Windows.Forms.TextBox();
            this.lblProfitEdit = new System.Windows.Forms.Label();
            this.pnlAmountSold = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnAmountSoldComfirmation = new System.Windows.Forms.Button();
            this.lblPleaseEnterAmountSold = new System.Windows.Forms.Label();
            this.txtAmountSoldEdit = new System.Windows.Forms.NumericUpDown();
            this.txtSellPriceEdit = new System.Windows.Forms.TextBox();
            this.lbxProductIDEdit = new System.Windows.Forms.ListBox();
            this.lblSellPriceEdit = new System.Windows.Forms.Label();
            this.rdoSortByTransactionDateEdit = new System.Windows.Forms.RadioButton();
            this.rdoSortByCustomerEdit = new System.Windows.Forms.RadioButton();
            this.btnSubtractProduct = new System.Windows.Forms.Button();
            this.btnAddProduct = new System.Windows.Forms.Button();
            this.lblAmountSoldEdit = new System.Windows.Forms.Label();
            this.lblProductsSoldEdit = new System.Windows.Forms.Label();
            this.lbxProductsSoldEdit = new System.Windows.Forms.ListBox();
            this.lbxProductsEdit = new System.Windows.Forms.ListBox();
            this.txtTotalProfitEdit = new System.Windows.Forms.TextBox();
            this.txtMarkupPercentageEdit = new System.Windows.Forms.TextBox();
            this.txtStoreEdit = new System.Windows.Forms.TextBox();
            this.txtTransactionIDEdit = new System.Windows.Forms.TextBox();
            this.lblTotalProfitEdit = new System.Windows.Forms.Label();
            this.lblMarkupPercentageEdit = new System.Windows.Forms.Label();
            this.lblProductsEdit = new System.Windows.Forms.Label();
            this.lblStoreEdit = new System.Windows.Forms.Label();
            this.lblDateSoldEdit = new System.Windows.Forms.Label();
            this.lblTransactionIDEdit = new System.Windows.Forms.Label();
            this.cbxSalesIDEdit = new System.Windows.Forms.ComboBox();
            this.lblSalesIDEdit = new System.Windows.Forms.Label();
            this.cbxTransactionEdit = new System.Windows.Forms.ComboBox();
            this.lblPleaseSelectTransactionEdit = new System.Windows.Forms.Label();
            this.lblSalesInformation = new System.Windows.Forms.Label();
            this.btnViewTransactions = new System.Windows.Forms.Button();
            this.btnMakeTransaction = new System.Windows.Forms.Button();
            this.btnUpdateTransaction = new System.Windows.Forms.Button();
            this.btnReportFullScreen = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLogo)).BeginInit();
            this.pnlReports.SuspendLayout();
            this.pnlViewStuff.SuspendLayout();
            this.pnlCustomer.SuspendLayout();
            this.pnlViewCustomer.SuspendLayout();
            this.pnlAddUpdateCustomer.SuspendLayout();
            this.pnlSales.SuspendLayout();
            this.pnlViewSales.SuspendLayout();
            this.pnlMakeUpdateTransaction.SuspendLayout();
            this.pnlAmountSold.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtAmountSoldEdit)).BeginInit();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.BackColor = System.Drawing.Color.Teal;
            this.lblTitle.Font = new System.Drawing.Font("Arial", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(194, 9);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(802, 49);
            this.lblTitle.TabIndex = 5;
            this.lblTitle.Text = "Inventory Information";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnMain
            // 
            this.btnMain.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMain.BackgroundImage")));
            this.btnMain.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMain.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMain.Font = new System.Drawing.Font("Arial", 12F);
            this.btnMain.Location = new System.Drawing.Point(6, 196);
            this.btnMain.Name = "btnMain";
            this.btnMain.Size = new System.Drawing.Size(180, 34);
            this.btnMain.TabIndex = 1;
            this.btnMain.Text = "Main Menu";
            this.btnMain.UseVisualStyleBackColor = true;
            this.btnMain.Click += new System.EventHandler(this.btnMain_Click);
            // 
            // btnReports
            // 
            this.btnReports.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnReports.BackgroundImage")));
            this.btnReports.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnReports.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReports.Font = new System.Drawing.Font("Arial", 12F);
            this.btnReports.Location = new System.Drawing.Point(6, 236);
            this.btnReports.Name = "btnReports";
            this.btnReports.Size = new System.Drawing.Size(180, 34);
            this.btnReports.TabIndex = 2;
            this.btnReports.Text = "Reports";
            this.btnReports.UseVisualStyleBackColor = true;
            this.btnReports.Click += new System.EventHandler(this.btnReports_Click);
            // 
            // btnSales
            // 
            this.btnSales.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSales.BackgroundImage")));
            this.btnSales.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSales.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSales.Font = new System.Drawing.Font("Arial", 12F);
            this.btnSales.Location = new System.Drawing.Point(6, 276);
            this.btnSales.Name = "btnSales";
            this.btnSales.Size = new System.Drawing.Size(180, 34);
            this.btnSales.TabIndex = 3;
            this.btnSales.Text = "Sales";
            this.btnSales.UseVisualStyleBackColor = true;
            this.btnSales.Click += new System.EventHandler(this.btnSales_Click);
            // 
            // btnCustomers
            // 
            this.btnCustomers.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCustomers.BackgroundImage")));
            this.btnCustomers.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCustomers.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCustomers.Font = new System.Drawing.Font("Arial", 12F);
            this.btnCustomers.Location = new System.Drawing.Point(6, 316);
            this.btnCustomers.Name = "btnCustomers";
            this.btnCustomers.Size = new System.Drawing.Size(180, 34);
            this.btnCustomers.TabIndex = 4;
            this.btnCustomers.Text = "Customers";
            this.btnCustomers.UseVisualStyleBackColor = true;
            this.btnCustomers.Click += new System.EventHandler(this.btnCustomers_Click);
            // 
            // lblMaterialsAndGeneralLabel
            // 
            this.lblMaterialsAndGeneralLabel.AutoSize = true;
            this.lblMaterialsAndGeneralLabel.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMaterialsAndGeneralLabel.Location = new System.Drawing.Point(191, 58);
            this.lblMaterialsAndGeneralLabel.Name = "lblMaterialsAndGeneralLabel";
            this.lblMaterialsAndGeneralLabel.Size = new System.Drawing.Size(72, 18);
            this.lblMaterialsAndGeneralLabel.TabIndex = 0;
            this.lblMaterialsAndGeneralLabel.Text = "Materials";
            // 
            // pbxLogo
            // 
            this.pbxLogo.Image = ((System.Drawing.Image)(resources.GetObject("pbxLogo.Image")));
            this.pbxLogo.Location = new System.Drawing.Point(6, 2);
            this.pbxLogo.Name = "pbxLogo";
            this.pbxLogo.Size = new System.Drawing.Size(180, 143);
            this.pbxLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxLogo.TabIndex = 15;
            this.pbxLogo.TabStop = false;
            // 
            // lblNavigation
            // 
            this.lblNavigation.BackColor = System.Drawing.Color.Teal;
            this.lblNavigation.Font = new System.Drawing.Font("Arial", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblNavigation.ForeColor = System.Drawing.Color.White;
            this.lblNavigation.Location = new System.Drawing.Point(6, 153);
            this.lblNavigation.Name = "lblNavigation";
            this.lblNavigation.Size = new System.Drawing.Size(180, 38);
            this.lblNavigation.TabIndex = 16;
            this.lblNavigation.Text = "Navigation:";
            this.lblNavigation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnHelp
            // 
            this.btnHelp.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnHelp.BackgroundImage")));
            this.btnHelp.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnHelp.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnHelp.Font = new System.Drawing.Font("Arial", 12F);
            this.btnHelp.Location = new System.Drawing.Point(6, 396);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(180, 34);
            this.btnHelp.TabIndex = 17;
            this.btnHelp.Text = "Help/ Preferences";
            this.btnHelp.UseVisualStyleBackColor = true;
            this.btnHelp.Click += new System.EventHandler(this.btnHelp_Click);
            // 
            // lblShowOneTable
            // 
            this.lblShowOneTable.BackColor = System.Drawing.Color.Teal;
            this.lblShowOneTable.Font = new System.Drawing.Font("Arial", 12F);
            this.lblShowOneTable.ForeColor = System.Drawing.Color.White;
            this.lblShowOneTable.Location = new System.Drawing.Point(6, 636);
            this.lblShowOneTable.Name = "lblShowOneTable";
            this.lblShowOneTable.Size = new System.Drawing.Size(180, 38);
            this.lblShowOneTable.TabIndex = 21;
            this.lblShowOneTable.Text = "Available Views:";
            this.lblShowOneTable.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnViewProducts
            // 
            this.btnViewProducts.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnViewProducts.BackgroundImage")));
            this.btnViewProducts.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnViewProducts.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnViewProducts.Font = new System.Drawing.Font("Arial", 12F);
            this.btnViewProducts.Location = new System.Drawing.Point(6, 759);
            this.btnViewProducts.Name = "btnViewProducts";
            this.btnViewProducts.Size = new System.Drawing.Size(180, 34);
            this.btnViewProducts.TabIndex = 14;
            this.btnViewProducts.Text = "Products";
            this.btnViewProducts.UseVisualStyleBackColor = true;
            this.btnViewProducts.Click += new System.EventHandler(this.btnProducts_Click);
            // 
            // btnViewSupplies
            // 
            this.btnViewSupplies.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnViewSupplies.BackgroundImage")));
            this.btnViewSupplies.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnViewSupplies.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnViewSupplies.Font = new System.Drawing.Font("Arial", 12F);
            this.btnViewSupplies.Location = new System.Drawing.Point(6, 719);
            this.btnViewSupplies.Name = "btnViewSupplies";
            this.btnViewSupplies.Size = new System.Drawing.Size(180, 34);
            this.btnViewSupplies.TabIndex = 13;
            this.btnViewSupplies.Text = "Supplies";
            this.btnViewSupplies.UseVisualStyleBackColor = true;
            this.btnViewSupplies.Click += new System.EventHandler(this.btnSupplies_Click);
            // 
            // btnViewMaterials
            // 
            this.btnViewMaterials.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnViewMaterials.BackgroundImage")));
            this.btnViewMaterials.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnViewMaterials.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnViewMaterials.Font = new System.Drawing.Font("Arial", 12F);
            this.btnViewMaterials.Location = new System.Drawing.Point(6, 679);
            this.btnViewMaterials.Name = "btnViewMaterials";
            this.btnViewMaterials.Size = new System.Drawing.Size(180, 34);
            this.btnViewMaterials.TabIndex = 12;
            this.btnViewMaterials.Text = "Materials";
            this.btnViewMaterials.UseVisualStyleBackColor = true;
            this.btnViewMaterials.Click += new System.EventHandler(this.btnMaterials_Click);
            // 
            // btnExit
            // 
            this.btnExit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnExit.BackgroundImage")));
            this.btnExit.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnExit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnExit.Font = new System.Drawing.Font("Arial", 12F);
            this.btnExit.Location = new System.Drawing.Point(6, 436);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(180, 34);
            this.btnExit.TabIndex = 6;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // lblAddUpdateInventory
            // 
            this.lblAddUpdateInventory.BackColor = System.Drawing.Color.Teal;
            this.lblAddUpdateInventory.Font = new System.Drawing.Font("Arial", 12F);
            this.lblAddUpdateInventory.ForeColor = System.Drawing.Color.White;
            this.lblAddUpdateInventory.Location = new System.Drawing.Point(6, 473);
            this.lblAddUpdateInventory.Name = "lblAddUpdateInventory";
            this.lblAddUpdateInventory.Size = new System.Drawing.Size(180, 38);
            this.lblAddUpdateInventory.TabIndex = 27;
            this.lblAddUpdateInventory.Text = "Add/Update Information:";
            this.lblAddUpdateInventory.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnMaterialsEdit
            // 
            this.btnMaterialsEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMaterialsEdit.BackgroundImage")));
            this.btnMaterialsEdit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMaterialsEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.btnMaterialsEdit.Location = new System.Drawing.Point(6, 514);
            this.btnMaterialsEdit.Name = "btnMaterialsEdit";
            this.btnMaterialsEdit.Size = new System.Drawing.Size(180, 34);
            this.btnMaterialsEdit.TabIndex = 7;
            this.btnMaterialsEdit.Text = "Materials";
            this.btnMaterialsEdit.UseVisualStyleBackColor = true;
            this.btnMaterialsEdit.Click += new System.EventHandler(this.btnMaterialsEdit_Click);
            // 
            // btnSuppliesEdit
            // 
            this.btnSuppliesEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSuppliesEdit.BackgroundImage")));
            this.btnSuppliesEdit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSuppliesEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.btnSuppliesEdit.Location = new System.Drawing.Point(6, 554);
            this.btnSuppliesEdit.Name = "btnSuppliesEdit";
            this.btnSuppliesEdit.Size = new System.Drawing.Size(180, 34);
            this.btnSuppliesEdit.TabIndex = 8;
            this.btnSuppliesEdit.Text = "Supplies";
            this.btnSuppliesEdit.UseVisualStyleBackColor = true;
            this.btnSuppliesEdit.Click += new System.EventHandler(this.btnSuppliesEdit_Click);
            // 
            // btnProductsEdit
            // 
            this.btnProductsEdit.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnProductsEdit.BackgroundImage")));
            this.btnProductsEdit.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnProductsEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.btnProductsEdit.Location = new System.Drawing.Point(6, 594);
            this.btnProductsEdit.Name = "btnProductsEdit";
            this.btnProductsEdit.Size = new System.Drawing.Size(180, 34);
            this.btnProductsEdit.TabIndex = 9;
            this.btnProductsEdit.Text = "Products";
            this.btnProductsEdit.UseVisualStyleBackColor = true;
            this.btnProductsEdit.Click += new System.EventHandler(this.btnProductsEdit_Click);
            // 
            // btnViewCustomer
            // 
            this.btnViewCustomer.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnViewCustomer.BackgroundImage")));
            this.btnViewCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnViewCustomer.Font = new System.Drawing.Font("Arial", 12F);
            this.btnViewCustomer.Location = new System.Drawing.Point(6, 594);
            this.btnViewCustomer.Name = "btnViewCustomer";
            this.btnViewCustomer.Size = new System.Drawing.Size(180, 34);
            this.btnViewCustomer.TabIndex = 9;
            this.btnViewCustomer.Text = "View Information";
            this.btnViewCustomer.UseVisualStyleBackColor = true;
            this.btnViewCustomer.Click += new System.EventHandler(this.btnViewCustomer_Click_1);
            // 
            // btnUpdateCustomer
            // 
            this.btnUpdateCustomer.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpdateCustomer.BackgroundImage")));
            this.btnUpdateCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUpdateCustomer.Font = new System.Drawing.Font("Arial", 12F);
            this.btnUpdateCustomer.Location = new System.Drawing.Point(6, 554);
            this.btnUpdateCustomer.Name = "btnUpdateCustomer";
            this.btnUpdateCustomer.Size = new System.Drawing.Size(180, 34);
            this.btnUpdateCustomer.TabIndex = 8;
            this.btnUpdateCustomer.Text = "Update Information";
            this.btnUpdateCustomer.UseVisualStyleBackColor = true;
            this.btnUpdateCustomer.Click += new System.EventHandler(this.btnUpdateCustomer_Click_1);
            // 
            // btnAddCustomer
            // 
            this.btnAddCustomer.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAddCustomer.BackgroundImage")));
            this.btnAddCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAddCustomer.Font = new System.Drawing.Font("Arial", 12F);
            this.btnAddCustomer.Location = new System.Drawing.Point(6, 514);
            this.btnAddCustomer.Name = "btnAddCustomer";
            this.btnAddCustomer.Size = new System.Drawing.Size(180, 34);
            this.btnAddCustomer.TabIndex = 7;
            this.btnAddCustomer.Text = "Add Customer";
            this.btnAddCustomer.UseVisualStyleBackColor = true;
            this.btnAddCustomer.Click += new System.EventHandler(this.btnAddCustomer_Click_1);
            // 
            // lblEditCustomerInformation
            // 
            this.lblEditCustomerInformation.BackColor = System.Drawing.Color.Teal;
            this.lblEditCustomerInformation.Font = new System.Drawing.Font("Arial", 14.25F);
            this.lblEditCustomerInformation.ForeColor = System.Drawing.Color.White;
            this.lblEditCustomerInformation.Location = new System.Drawing.Point(6, 473);
            this.lblEditCustomerInformation.Name = "lblEditCustomerInformation";
            this.lblEditCustomerInformation.Size = new System.Drawing.Size(180, 38);
            this.lblEditCustomerInformation.TabIndex = 35;
            this.lblEditCustomerInformation.Text = "Edit Information:";
            this.lblEditCustomerInformation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnCustomerReport
            // 
            this.btnCustomerReport.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCustomerReport.BackgroundImage")));
            this.btnCustomerReport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCustomerReport.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCustomerReport.Font = new System.Drawing.Font("Arial", 12F);
            this.btnCustomerReport.Location = new System.Drawing.Point(816, 82);
            this.btnCustomerReport.Name = "btnCustomerReport";
            this.btnCustomerReport.Size = new System.Drawing.Size(180, 34);
            this.btnCustomerReport.TabIndex = 41;
            this.btnCustomerReport.Text = "Customer Report";
            this.btnCustomerReport.UseVisualStyleBackColor = true;
            this.btnCustomerReport.Click += new System.EventHandler(this.btnCustomerReport_Click);
            // 
            // btnInventoryReport
            // 
            this.btnInventoryReport.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnInventoryReport.BackgroundImage")));
            this.btnInventoryReport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnInventoryReport.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnInventoryReport.Font = new System.Drawing.Font("Arial", 12F);
            this.btnInventoryReport.Location = new System.Drawing.Point(492, 82);
            this.btnInventoryReport.Name = "btnInventoryReport";
            this.btnInventoryReport.Size = new System.Drawing.Size(180, 34);
            this.btnInventoryReport.TabIndex = 40;
            this.btnInventoryReport.Text = "Inventory Report";
            this.btnInventoryReport.UseVisualStyleBackColor = true;
            this.btnInventoryReport.Click += new System.EventHandler(this.btnInventoryReport_Click);
            // 
            // btnSalesReport
            // 
            this.btnSalesReport.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSalesReport.BackgroundImage")));
            this.btnSalesReport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSalesReport.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSalesReport.Font = new System.Drawing.Font("Arial", 12F);
            this.btnSalesReport.Location = new System.Drawing.Point(192, 82);
            this.btnSalesReport.Name = "btnSalesReport";
            this.btnSalesReport.Size = new System.Drawing.Size(180, 34);
            this.btnSalesReport.TabIndex = 39;
            this.btnSalesReport.Text = "Sales Report";
            this.btnSalesReport.UseVisualStyleBackColor = true;
            this.btnSalesReport.Click += new System.EventHandler(this.btnSalesReport_Click);
            // 
            // btnInventory
            // 
            this.btnInventory.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnInventory.BackgroundImage")));
            this.btnInventory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnInventory.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnInventory.Font = new System.Drawing.Font("Arial", 12F);
            this.btnInventory.Location = new System.Drawing.Point(6, 356);
            this.btnInventory.Name = "btnInventory";
            this.btnInventory.Size = new System.Drawing.Size(180, 34);
            this.btnInventory.TabIndex = 5;
            this.btnInventory.Text = "Inventory";
            this.btnInventory.UseVisualStyleBackColor = true;
            this.btnInventory.Click += new System.EventHandler(this.btnInventory_Click);
            // 
            // pnlReports
            // 
            this.pnlReports.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlReports.Controls.Add(this.crvReport);
            this.pnlReports.Location = new System.Drawing.Point(192, 134);
            this.pnlReports.Name = "pnlReports";
            this.pnlReports.Size = new System.Drawing.Size(804, 619);
            this.pnlReports.TabIndex = 43;
            // 
            // crvReport
            // 
            this.crvReport.ActiveViewIndex = -1;
            this.crvReport.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crvReport.Cursor = System.Windows.Forms.Cursors.Default;
            this.crvReport.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crvReport.Location = new System.Drawing.Point(0, 0);
            this.crvReport.Name = "crvReport";
            this.crvReport.ShowCloseButton = false;
            this.crvReport.ShowCopyButton = false;
            this.crvReport.ShowGroupTreeButton = false;
            this.crvReport.ShowLogo = false;
            this.crvReport.ShowParameterPanelButton = false;
            this.crvReport.Size = new System.Drawing.Size(800, 615);
            this.crvReport.TabIndex = 0;
            this.crvReport.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            // 
            // pnlViewStuff
            // 
            this.pnlViewStuff.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlViewStuff.Controls.Add(this.crvViewInventory);
            this.pnlViewStuff.Location = new System.Drawing.Point(192, 79);
            this.pnlViewStuff.Name = "pnlViewStuff";
            this.pnlViewStuff.Size = new System.Drawing.Size(804, 714);
            this.pnlViewStuff.TabIndex = 44;
            // 
            // crvViewInventory
            // 
            this.crvViewInventory.ActiveViewIndex = -1;
            this.crvViewInventory.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crvViewInventory.Cursor = System.Windows.Forms.Cursors.Default;
            this.crvViewInventory.DisplayBackgroundEdge = false;
            this.crvViewInventory.DisplayStatusBar = false;
            this.crvViewInventory.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crvViewInventory.EnableToolTips = false;
            this.crvViewInventory.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.crvViewInventory.Location = new System.Drawing.Point(0, 0);
            this.crvViewInventory.Name = "crvViewInventory";
            this.crvViewInventory.ShowCloseButton = false;
            this.crvViewInventory.ShowCopyButton = false;
            this.crvViewInventory.ShowExportButton = false;
            this.crvViewInventory.ShowGroupTreeButton = false;
            this.crvViewInventory.ShowLogo = false;
            this.crvViewInventory.ShowParameterPanelButton = false;
            this.crvViewInventory.ShowPrintButton = false;
            this.crvViewInventory.ShowRefreshButton = false;
            this.crvViewInventory.ShowZoomButton = false;
            this.crvViewInventory.Size = new System.Drawing.Size(800, 710);
            this.crvViewInventory.TabIndex = 0;
            this.crvViewInventory.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            // 
            // pnlCustomer
            // 
            this.pnlCustomer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlCustomer.Controls.Add(this.pnlViewCustomer);
            this.pnlCustomer.Controls.Add(this.pnlAddUpdateCustomer);
            this.pnlCustomer.Location = new System.Drawing.Point(192, 79);
            this.pnlCustomer.Name = "pnlCustomer";
            this.pnlCustomer.Size = new System.Drawing.Size(804, 712);
            this.pnlCustomer.TabIndex = 48;
            // 
            // pnlViewCustomer
            // 
            this.pnlViewCustomer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlViewCustomer.Controls.Add(this.crvViewCustomers);
            this.pnlViewCustomer.Location = new System.Drawing.Point(0, 0);
            this.pnlViewCustomer.Name = "pnlViewCustomer";
            this.pnlViewCustomer.Size = new System.Drawing.Size(800, 710);
            this.pnlViewCustomer.TabIndex = 0;
            // 
            // crvViewCustomers
            // 
            this.crvViewCustomers.ActiveViewIndex = -1;
            this.crvViewCustomers.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.crvViewCustomers.Cursor = System.Windows.Forms.Cursors.Default;
            this.crvViewCustomers.DisplayBackgroundEdge = false;
            this.crvViewCustomers.DisplayStatusBar = false;
            this.crvViewCustomers.Dock = System.Windows.Forms.DockStyle.Fill;
            this.crvViewCustomers.EnableToolTips = false;
            this.crvViewCustomers.ImeMode = System.Windows.Forms.ImeMode.NoControl;
            this.crvViewCustomers.Location = new System.Drawing.Point(0, 0);
            this.crvViewCustomers.Name = "crvViewCustomers";
            this.crvViewCustomers.ShowCloseButton = false;
            this.crvViewCustomers.ShowCopyButton = false;
            this.crvViewCustomers.ShowExportButton = false;
            this.crvViewCustomers.ShowGroupTreeButton = false;
            this.crvViewCustomers.ShowLogo = false;
            this.crvViewCustomers.ShowParameterPanelButton = false;
            this.crvViewCustomers.ShowPrintButton = false;
            this.crvViewCustomers.ShowRefreshButton = false;
            this.crvViewCustomers.ShowZoomButton = false;
            this.crvViewCustomers.Size = new System.Drawing.Size(796, 706);
            this.crvViewCustomers.TabIndex = 4;
            this.crvViewCustomers.ToolPanelView = CrystalDecisions.Windows.Forms.ToolPanelViewType.None;
            // 
            // pnlAddUpdateCustomer
            // 
            this.pnlAddUpdateCustomer.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlAddUpdateCustomer.Controls.Add(this.lblSelectCustomerID);
            this.pnlAddUpdateCustomer.Controls.Add(this.dtCustomerBirthday);
            this.pnlAddUpdateCustomer.Controls.Add(this.btnCustomerSaveAdd);
            this.pnlAddUpdateCustomer.Controls.Add(this.txtCustomerName);
            this.pnlAddUpdateCustomer.Controls.Add(this.txtCustomerItemsPurchased);
            this.pnlAddUpdateCustomer.Controls.Add(this.txtCustomerPhone);
            this.pnlAddUpdateCustomer.Controls.Add(this.txtCustomerAddress);
            this.pnlAddUpdateCustomer.Controls.Add(this.txtCustomerEmail);
            this.pnlAddUpdateCustomer.Controls.Add(this.txtCustomerID);
            this.pnlAddUpdateCustomer.Controls.Add(this.lblCustomerItemsPurchased);
            this.pnlAddUpdateCustomer.Controls.Add(this.lblCustomerBirthday);
            this.pnlAddUpdateCustomer.Controls.Add(this.lblCustomerPhone);
            this.pnlAddUpdateCustomer.Controls.Add(this.lblCustomerAddress);
            this.pnlAddUpdateCustomer.Controls.Add(this.lblCustomerEmail);
            this.pnlAddUpdateCustomer.Controls.Add(this.lblCustomerID);
            this.pnlAddUpdateCustomer.Controls.Add(this.cbxCustomers);
            this.pnlAddUpdateCustomer.Controls.Add(this.cbxCustomerID);
            this.pnlAddUpdateCustomer.Controls.Add(this.lblSelectACustomerName);
            this.pnlAddUpdateCustomer.Location = new System.Drawing.Point(0, 0);
            this.pnlAddUpdateCustomer.Name = "pnlAddUpdateCustomer";
            this.pnlAddUpdateCustomer.Size = new System.Drawing.Size(800, 710);
            this.pnlAddUpdateCustomer.TabIndex = 1;
            // 
            // lblSelectCustomerID
            // 
            this.lblSelectCustomerID.AutoSize = true;
            this.lblSelectCustomerID.Font = new System.Drawing.Font("Arial", 12F);
            this.lblSelectCustomerID.Location = new System.Drawing.Point(584, 18);
            this.lblSelectCustomerID.Name = "lblSelectCustomerID";
            this.lblSelectCustomerID.Size = new System.Drawing.Size(27, 18);
            this.lblSelectCustomerID.TabIndex = 10;
            this.lblSelectCustomerID.Text = "ID:";
            // 
            // dtCustomerBirthday
            // 
            this.dtCustomerBirthday.Font = new System.Drawing.Font("Arial", 12F);
            this.dtCustomerBirthday.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtCustomerBirthday.Location = new System.Drawing.Point(134, 230);
            this.dtCustomerBirthday.Name = "dtCustomerBirthday";
            this.dtCustomerBirthday.Size = new System.Drawing.Size(200, 26);
            this.dtCustomerBirthday.TabIndex = 6;
            // 
            // btnCustomerSaveAdd
            // 
            this.btnCustomerSaveAdd.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCustomerSaveAdd.BackgroundImage")));
            this.btnCustomerSaveAdd.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCustomerSaveAdd.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCustomerSaveAdd.Font = new System.Drawing.Font("Arial", 12F);
            this.btnCustomerSaveAdd.Location = new System.Drawing.Point(703, 280);
            this.btnCustomerSaveAdd.Name = "btnCustomerSaveAdd";
            this.btnCustomerSaveAdd.Size = new System.Drawing.Size(90, 34);
            this.btnCustomerSaveAdd.TabIndex = 8;
            this.btnCustomerSaveAdd.Text = "Save/Add";
            this.btnCustomerSaveAdd.UseVisualStyleBackColor = true;
            this.btnCustomerSaveAdd.Click += new System.EventHandler(this.btnCustomerSaveAdd_Click);
            // 
            // txtCustomerName
            // 
            this.txtCustomerName.Font = new System.Drawing.Font("Arial", 12F);
            this.txtCustomerName.Location = new System.Drawing.Point(331, 10);
            this.txtCustomerName.Name = "txtCustomerName";
            this.txtCustomerName.Size = new System.Drawing.Size(247, 26);
            this.txtCustomerName.TabIndex = 1;
            // 
            // txtCustomerItemsPurchased
            // 
            this.txtCustomerItemsPurchased.Enabled = false;
            this.txtCustomerItemsPurchased.Font = new System.Drawing.Font("Arial", 12F);
            this.txtCustomerItemsPurchased.Location = new System.Drawing.Point(535, 232);
            this.txtCustomerItemsPurchased.Name = "txtCustomerItemsPurchased";
            this.txtCustomerItemsPurchased.Size = new System.Drawing.Size(149, 26);
            this.txtCustomerItemsPurchased.TabIndex = 7;
            // 
            // txtCustomerPhone
            // 
            this.txtCustomerPhone.Font = new System.Drawing.Font("Arial", 12F);
            this.txtCustomerPhone.Location = new System.Drawing.Point(482, 157);
            this.txtCustomerPhone.Name = "txtCustomerPhone";
            this.txtCustomerPhone.Size = new System.Drawing.Size(202, 26);
            this.txtCustomerPhone.TabIndex = 5;
            // 
            // txtCustomerAddress
            // 
            this.txtCustomerAddress.Font = new System.Drawing.Font("Arial", 12F);
            this.txtCustomerAddress.Location = new System.Drawing.Point(134, 160);
            this.txtCustomerAddress.Name = "txtCustomerAddress";
            this.txtCustomerAddress.Size = new System.Drawing.Size(200, 26);
            this.txtCustomerAddress.TabIndex = 4;
            // 
            // txtCustomerEmail
            // 
            this.txtCustomerEmail.Font = new System.Drawing.Font("Arial", 12F);
            this.txtCustomerEmail.Location = new System.Drawing.Point(391, 83);
            this.txtCustomerEmail.Name = "txtCustomerEmail";
            this.txtCustomerEmail.Size = new System.Drawing.Size(293, 26);
            this.txtCustomerEmail.TabIndex = 3;
            // 
            // txtCustomerID
            // 
            this.txtCustomerID.Enabled = false;
            this.txtCustomerID.Font = new System.Drawing.Font("Arial", 12F);
            this.txtCustomerID.Location = new System.Drawing.Point(134, 86);
            this.txtCustomerID.Name = "txtCustomerID";
            this.txtCustomerID.Size = new System.Drawing.Size(127, 26);
            this.txtCustomerID.TabIndex = 2;
            // 
            // lblCustomerItemsPurchased
            // 
            this.lblCustomerItemsPurchased.AutoSize = true;
            this.lblCustomerItemsPurchased.Font = new System.Drawing.Font("Arial", 12F);
            this.lblCustomerItemsPurchased.Location = new System.Drawing.Point(357, 235);
            this.lblCustomerItemsPurchased.Name = "lblCustomerItemsPurchased";
            this.lblCustomerItemsPurchased.Size = new System.Drawing.Size(164, 18);
            this.lblCustomerItemsPurchased.TabIndex = 7;
            this.lblCustomerItemsPurchased.Text = "Total Items Purchased:";
            // 
            // lblCustomerBirthday
            // 
            this.lblCustomerBirthday.AutoSize = true;
            this.lblCustomerBirthday.Font = new System.Drawing.Font("Arial", 12F);
            this.lblCustomerBirthday.Location = new System.Drawing.Point(56, 238);
            this.lblCustomerBirthday.Name = "lblCustomerBirthday";
            this.lblCustomerBirthday.Size = new System.Drawing.Size(69, 18);
            this.lblCustomerBirthday.TabIndex = 6;
            this.lblCustomerBirthday.Text = "Birthday:";
            // 
            // lblCustomerPhone
            // 
            this.lblCustomerPhone.AutoSize = true;
            this.lblCustomerPhone.Font = new System.Drawing.Font("Arial", 12F);
            this.lblCustomerPhone.Location = new System.Drawing.Point(357, 163);
            this.lblCustomerPhone.Name = "lblCustomerPhone";
            this.lblCustomerPhone.Size = new System.Drawing.Size(116, 18);
            this.lblCustomerPhone.TabIndex = 5;
            this.lblCustomerPhone.Text = "Phone Number:";
            // 
            // lblCustomerAddress
            // 
            this.lblCustomerAddress.AutoSize = true;
            this.lblCustomerAddress.Font = new System.Drawing.Font("Arial", 12F);
            this.lblCustomerAddress.Location = new System.Drawing.Point(55, 166);
            this.lblCustomerAddress.Name = "lblCustomerAddress";
            this.lblCustomerAddress.Size = new System.Drawing.Size(71, 18);
            this.lblCustomerAddress.TabIndex = 4;
            this.lblCustomerAddress.Text = "Address:";
            // 
            // lblCustomerEmail
            // 
            this.lblCustomerEmail.AutoSize = true;
            this.lblCustomerEmail.Font = new System.Drawing.Font("Arial", 12F);
            this.lblCustomerEmail.Location = new System.Drawing.Point(327, 89);
            this.lblCustomerEmail.Name = "lblCustomerEmail";
            this.lblCustomerEmail.Size = new System.Drawing.Size(52, 18);
            this.lblCustomerEmail.TabIndex = 3;
            this.lblCustomerEmail.Text = "Email:";
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.AutoSize = true;
            this.lblCustomerID.Font = new System.Drawing.Font("Arial", 12F);
            this.lblCustomerID.Location = new System.Drawing.Point(24, 92);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(99, 18);
            this.lblCustomerID.TabIndex = 2;
            this.lblCustomerID.Text = "Customer ID:";
            // 
            // cbxCustomers
            // 
            this.cbxCustomers.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxCustomers.FormattingEnabled = true;
            this.cbxCustomers.Location = new System.Drawing.Point(331, 10);
            this.cbxCustomers.MaxDropDownItems = 100;
            this.cbxCustomers.Name = "cbxCustomers";
            this.cbxCustomers.Size = new System.Drawing.Size(247, 26);
            this.cbxCustomers.TabIndex = 1;
            this.cbxCustomers.SelectedIndexChanged += new System.EventHandler(this.cbxCustomers_SelectedIndexChanged);
            // 
            // cbxCustomerID
            // 
            this.cbxCustomerID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxCustomerID.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxCustomerID.FormattingEnabled = true;
            this.cbxCustomerID.Location = new System.Drawing.Point(620, 10);
            this.cbxCustomerID.MaxDropDownItems = 100;
            this.cbxCustomerID.Name = "cbxCustomerID";
            this.cbxCustomerID.Size = new System.Drawing.Size(131, 26);
            this.cbxCustomerID.TabIndex = 9;
            this.cbxCustomerID.SelectedIndexChanged += new System.EventHandler(this.cbxCustomerID_SelectedIndexChanged);
            // 
            // lblSelectACustomerName
            // 
            this.lblSelectACustomerName.Font = new System.Drawing.Font("Arial", 12F);
            this.lblSelectACustomerName.Location = new System.Drawing.Point(61, 13);
            this.lblSelectACustomerName.Name = "lblSelectACustomerName";
            this.lblSelectACustomerName.Size = new System.Drawing.Size(264, 23);
            this.lblSelectACustomerName.TabIndex = 0;
            this.lblSelectACustomerName.Text = "Please select a customer to edit:";
            this.lblSelectACustomerName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pnlSales
            // 
            this.pnlSales.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlSales.Controls.Add(this.pnlMakeUpdateTransaction);
            this.pnlSales.Controls.Add(this.pnlViewSales);
            this.pnlSales.Font = new System.Drawing.Font("Arial", 12F);
            this.pnlSales.Location = new System.Drawing.Point(192, 79);
            this.pnlSales.Name = "pnlSales";
            this.pnlSales.Size = new System.Drawing.Size(804, 714);
            this.pnlSales.TabIndex = 49;
            // 
            // pnlViewSales
            // 
            this.pnlViewSales.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlViewSales.Controls.Add(this.txtNumberOfProductSold);
            this.pnlViewSales.Controls.Add(this.lblNumberOfProductSold);
            this.pnlViewSales.Controls.Add(this.cbxSoldProductID);
            this.pnlViewSales.Controls.Add(this.lblPleaseSelectTransactionID);
            this.pnlViewSales.Controls.Add(this.txtProfitFromProduct);
            this.pnlViewSales.Controls.Add(this.lblProfitFromProduct);
            this.pnlViewSales.Controls.Add(this.cbxProductsView);
            this.pnlViewSales.Controls.Add(this.lblProductsSold);
            this.pnlViewSales.Controls.Add(this.txtProductNotes);
            this.pnlViewSales.Controls.Add(this.lblTotalProfitAfterMessage);
            this.pnlViewSales.Controls.Add(this.lblProductMaterialsUsed);
            this.pnlViewSales.Controls.Add(this.txtTotalProfit);
            this.pnlViewSales.Controls.Add(this.lbxProductMaterialsUsed);
            this.pnlViewSales.Controls.Add(this.lblTotalProfit);
            this.pnlViewSales.Controls.Add(this.txtProductRunningTotal);
            this.pnlViewSales.Controls.Add(this.txtMarkupPercentage);
            this.pnlViewSales.Controls.Add(this.txtProductDimentions);
            this.pnlViewSales.Controls.Add(this.lblMarkupPercentage);
            this.pnlViewSales.Controls.Add(this.txtProductColor);
            this.pnlViewSales.Controls.Add(this.cbxSalesIDView);
            this.pnlViewSales.Controls.Add(this.txtProductDescription);
            this.pnlViewSales.Controls.Add(this.lblSalesIDView);
            this.pnlViewSales.Controls.Add(this.txtProductID);
            this.pnlViewSales.Controls.Add(this.rdoSortByDateSoldView);
            this.pnlViewSales.Controls.Add(this.lblProductNotes);
            this.pnlViewSales.Controls.Add(this.txtDateSold);
            this.pnlViewSales.Controls.Add(this.lblProductRunningTotal);
            this.pnlViewSales.Controls.Add(this.txtProductCostToMake);
            this.pnlViewSales.Controls.Add(this.chkProductActive);
            this.pnlViewSales.Controls.Add(this.chkProductCustom);
            this.pnlViewSales.Controls.Add(this.rdoSortByCustomerView);
            this.pnlViewSales.Controls.Add(this.lblProductColor);
            this.pnlViewSales.Controls.Add(this.cbxTransactionView);
            this.pnlViewSales.Controls.Add(this.lblProductDimentions);
            this.pnlViewSales.Controls.Add(this.txtStore);
            this.pnlViewSales.Controls.Add(this.lblProductDescription);
            this.pnlViewSales.Controls.Add(this.lblStore);
            this.pnlViewSales.Controls.Add(this.lblProductID);
            this.pnlViewSales.Controls.Add(this.lblDateSold);
            this.pnlViewSales.Controls.Add(this.txtAmountSold);
            this.pnlViewSales.Controls.Add(this.lblProductCostToMake);
            this.pnlViewSales.Controls.Add(this.lblAmoutSold);
            this.pnlViewSales.Controls.Add(this.txtSalesCustomerTotalItemsPurchased);
            this.pnlViewSales.Controls.Add(this.lblSalesCustomerTotalItemsPurchased);
            this.pnlViewSales.Controls.Add(this.txtSalesCustomerName);
            this.pnlViewSales.Controls.Add(this.lblSalesCustomerName);
            this.pnlViewSales.Controls.Add(this.lblCustomerInfo);
            this.pnlViewSales.Controls.Add(this.lblSalesInfo);
            this.pnlViewSales.Controls.Add(this.lblPleaseSelectTransactionView);
            this.pnlViewSales.Controls.Add(this.lblProductInformation);
            this.pnlViewSales.Controls.Add(this.txtProductName);
            this.pnlViewSales.Controls.Add(this.lblProductName);
            this.pnlViewSales.Controls.Add(this.txtProductSellPrice);
            this.pnlViewSales.Controls.Add(this.lblProductSellPrice);
            this.pnlViewSales.Controls.Add(this.txtProductOnHand);
            this.pnlViewSales.Controls.Add(this.txtProductType);
            this.pnlViewSales.Controls.Add(this.lblProductOnHand);
            this.pnlViewSales.Controls.Add(this.lblProductType);
            this.pnlViewSales.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.pnlViewSales.Location = new System.Drawing.Point(0, 0);
            this.pnlViewSales.Name = "pnlViewSales";
            this.pnlViewSales.Size = new System.Drawing.Size(802, 712);
            this.pnlViewSales.TabIndex = 0;
            // 
            // txtNumberOfProductSold
            // 
            this.txtNumberOfProductSold.Enabled = false;
            this.txtNumberOfProductSold.Font = new System.Drawing.Font("Arial", 12F);
            this.txtNumberOfProductSold.Location = new System.Drawing.Point(623, 195);
            this.txtNumberOfProductSold.Name = "txtNumberOfProductSold";
            this.txtNumberOfProductSold.Size = new System.Drawing.Size(162, 26);
            this.txtNumberOfProductSold.TabIndex = 90;
            // 
            // lblNumberOfProductSold
            // 
            this.lblNumberOfProductSold.AutoSize = true;
            this.lblNumberOfProductSold.Font = new System.Drawing.Font("Arial", 12F);
            this.lblNumberOfProductSold.Location = new System.Drawing.Point(439, 200);
            this.lblNumberOfProductSold.Name = "lblNumberOfProductSold";
            this.lblNumberOfProductSold.Size = new System.Drawing.Size(173, 18);
            this.lblNumberOfProductSold.TabIndex = 91;
            this.lblNumberOfProductSold.Text = "Number of product sold:";
            // 
            // cbxSoldProductID
            // 
            this.cbxSoldProductID.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSoldProductID.Enabled = false;
            this.cbxSoldProductID.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxSoldProductID.FormattingEnabled = true;
            this.cbxSoldProductID.Location = new System.Drawing.Point(271, 71);
            this.cbxSoldProductID.MaxDropDownItems = 100;
            this.cbxSoldProductID.Name = "cbxSoldProductID";
            this.cbxSoldProductID.Size = new System.Drawing.Size(121, 26);
            this.cbxSoldProductID.TabIndex = 5;
            this.cbxSoldProductID.Visible = false;
            this.cbxSoldProductID.SelectedIndexChanged += new System.EventHandler(this.cbxSoldProductID_SelectedIndexChanged);
            // 
            // lblPleaseSelectTransactionID
            // 
            this.lblPleaseSelectTransactionID.AutoSize = true;
            this.lblPleaseSelectTransactionID.Font = new System.Drawing.Font("Arial", 12F);
            this.lblPleaseSelectTransactionID.Location = new System.Drawing.Point(42, 75);
            this.lblPleaseSelectTransactionID.Name = "lblPleaseSelectTransactionID";
            this.lblPleaseSelectTransactionID.Size = new System.Drawing.Size(218, 18);
            this.lblPleaseSelectTransactionID.TabIndex = 89;
            this.lblPleaseSelectTransactionID.Text = "Please select a transaction ID:";
            this.lblPleaseSelectTransactionID.Visible = false;
            // 
            // txtProfitFromProduct
            // 
            this.txtProfitFromProduct.Enabled = false;
            this.txtProfitFromProduct.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProfitFromProduct.Location = new System.Drawing.Point(290, 262);
            this.txtProfitFromProduct.Name = "txtProfitFromProduct";
            this.txtProfitFromProduct.Size = new System.Drawing.Size(113, 26);
            this.txtProfitFromProduct.TabIndex = 86;
            // 
            // lblProfitFromProduct
            // 
            this.lblProfitFromProduct.AutoSize = true;
            this.lblProfitFromProduct.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProfitFromProduct.Location = new System.Drawing.Point(70, 265);
            this.lblProfitFromProduct.Name = "lblProfitFromProduct";
            this.lblProfitFromProduct.Size = new System.Drawing.Size(203, 18);
            this.lblProfitFromProduct.TabIndex = 87;
            this.lblProfitFromProduct.Text = "Profit from selected product:";
            // 
            // cbxProductsView
            // 
            this.cbxProductsView.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxProductsView.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxProductsView.FormattingEnabled = true;
            this.cbxProductsView.Location = new System.Drawing.Point(230, 122);
            this.cbxProductsView.MaxDropDownItems = 100;
            this.cbxProductsView.Name = "cbxProductsView";
            this.cbxProductsView.Size = new System.Drawing.Size(204, 26);
            this.cbxProductsView.TabIndex = 6;
            this.cbxProductsView.SelectedIndexChanged += new System.EventHandler(this.cbxProducts_SelectedIndexChanged);
            // 
            // lblProductsSold
            // 
            this.lblProductsSold.AutoSize = true;
            this.lblProductsSold.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductsSold.Location = new System.Drawing.Point(7, 130);
            this.lblProductsSold.Name = "lblProductsSold";
            this.lblProductsSold.Size = new System.Drawing.Size(209, 18);
            this.lblProductsSold.TabIndex = 84;
            this.lblProductsSold.Text = "Products Sold In Transaction:";
            // 
            // txtProductNotes
            // 
            this.txtProductNotes.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductNotes.Location = new System.Drawing.Point(340, 589);
            this.txtProductNotes.Multiline = true;
            this.txtProductNotes.Name = "txtProductNotes";
            this.txtProductNotes.ReadOnly = true;
            this.txtProductNotes.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtProductNotes.Size = new System.Drawing.Size(429, 104);
            this.txtProductNotes.TabIndex = 52;
            // 
            // lblTotalProfitAfterMessage
            // 
            this.lblTotalProfitAfterMessage.AutoSize = true;
            this.lblTotalProfitAfterMessage.Font = new System.Drawing.Font("Arial", 8F);
            this.lblTotalProfitAfterMessage.Location = new System.Drawing.Point(409, 280);
            this.lblTotalProfitAfterMessage.Name = "lblTotalProfitAfterMessage";
            this.lblTotalProfitAfterMessage.Size = new System.Drawing.Size(148, 14);
            this.lblTotalProfitAfterMessage.TabIndex = 83;
            this.lblTotalProfitAfterMessage.Text = "*After tax and 60% reduction";
            // 
            // lblProductMaterialsUsed
            // 
            this.lblProductMaterialsUsed.AutoSize = true;
            this.lblProductMaterialsUsed.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductMaterialsUsed.Location = new System.Drawing.Point(10, 566);
            this.lblProductMaterialsUsed.Name = "lblProductMaterialsUsed";
            this.lblProductMaterialsUsed.Size = new System.Drawing.Size(117, 18);
            this.lblProductMaterialsUsed.TabIndex = 53;
            this.lblProductMaterialsUsed.Text = "Materials Used:";
            // 
            // txtTotalProfit
            // 
            this.txtTotalProfit.Enabled = false;
            this.txtTotalProfit.Font = new System.Drawing.Font("Arial", 12F);
            this.txtTotalProfit.Location = new System.Drawing.Point(290, 293);
            this.txtTotalProfit.Name = "txtTotalProfit";
            this.txtTotalProfit.Size = new System.Drawing.Size(113, 26);
            this.txtTotalProfit.TabIndex = 81;
            // 
            // lbxProductMaterialsUsed
            // 
            this.lbxProductMaterialsUsed.Font = new System.Drawing.Font("Arial", 12F);
            this.lbxProductMaterialsUsed.FormattingEnabled = true;
            this.lbxProductMaterialsUsed.ItemHeight = 18;
            this.lbxProductMaterialsUsed.Location = new System.Drawing.Point(7, 589);
            this.lbxProductMaterialsUsed.Name = "lbxProductMaterialsUsed";
            this.lbxProductMaterialsUsed.Size = new System.Drawing.Size(298, 94);
            this.lbxProductMaterialsUsed.TabIndex = 51;
            // 
            // lblTotalProfit
            // 
            this.lblTotalProfit.AutoSize = true;
            this.lblTotalProfit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblTotalProfit.Location = new System.Drawing.Point(200, 296);
            this.lblTotalProfit.Name = "lblTotalProfit";
            this.lblTotalProfit.Size = new System.Drawing.Size(85, 18);
            this.lblTotalProfit.TabIndex = 82;
            this.lblTotalProfit.Text = "Total Profit:";
            // 
            // txtProductRunningTotal
            // 
            this.txtProductRunningTotal.Enabled = false;
            this.txtProductRunningTotal.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductRunningTotal.Location = new System.Drawing.Point(365, 470);
            this.txtProductRunningTotal.Name = "txtProductRunningTotal";
            this.txtProductRunningTotal.Size = new System.Drawing.Size(152, 26);
            this.txtProductRunningTotal.TabIndex = 45;
            // 
            // txtMarkupPercentage
            // 
            this.txtMarkupPercentage.Enabled = false;
            this.txtMarkupPercentage.Font = new System.Drawing.Font("Arial", 12F);
            this.txtMarkupPercentage.Location = new System.Drawing.Point(290, 226);
            this.txtMarkupPercentage.Name = "txtMarkupPercentage";
            this.txtMarkupPercentage.Size = new System.Drawing.Size(113, 26);
            this.txtMarkupPercentage.TabIndex = 79;
            // 
            // txtProductDimentions
            // 
            this.txtProductDimentions.Enabled = false;
            this.txtProductDimentions.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductDimentions.Location = new System.Drawing.Point(616, 470);
            this.txtProductDimentions.Name = "txtProductDimentions";
            this.txtProductDimentions.Size = new System.Drawing.Size(153, 26);
            this.txtProductDimentions.TabIndex = 44;
            // 
            // lblMarkupPercentage
            // 
            this.lblMarkupPercentage.AutoSize = true;
            this.lblMarkupPercentage.Font = new System.Drawing.Font("Arial", 12F);
            this.lblMarkupPercentage.Location = new System.Drawing.Point(0, 233);
            this.lblMarkupPercentage.Name = "lblMarkupPercentage";
            this.lblMarkupPercentage.Size = new System.Drawing.Size(283, 18);
            this.lblMarkupPercentage.TabIndex = 80;
            this.lblMarkupPercentage.Text = "Markup percentage of selected product:";
            // 
            // txtProductColor
            // 
            this.txtProductColor.Enabled = false;
            this.txtProductColor.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductColor.Location = new System.Drawing.Point(616, 430);
            this.txtProductColor.MaxLength = 50;
            this.txtProductColor.Name = "txtProductColor";
            this.txtProductColor.Size = new System.Drawing.Size(153, 26);
            this.txtProductColor.TabIndex = 38;
            // 
            // cbxSalesIDView
            // 
            this.cbxSalesIDView.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSalesIDView.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxSalesIDView.FormattingEnabled = true;
            this.cbxSalesIDView.Location = new System.Drawing.Point(564, 37);
            this.cbxSalesIDView.MaxDropDownItems = 100;
            this.cbxSalesIDView.Name = "cbxSalesIDView";
            this.cbxSalesIDView.Size = new System.Drawing.Size(121, 26);
            this.cbxSalesIDView.TabIndex = 4;
            this.cbxSalesIDView.SelectedIndexChanged += new System.EventHandler(this.cbxSalesID_SelectedIndexChanged);
            // 
            // txtProductDescription
            // 
            this.txtProductDescription.Enabled = false;
            this.txtProductDescription.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductDescription.Location = new System.Drawing.Point(98, 506);
            this.txtProductDescription.MaxLength = 100;
            this.txtProductDescription.Multiline = true;
            this.txtProductDescription.Name = "txtProductDescription";
            this.txtProductDescription.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtProductDescription.Size = new System.Drawing.Size(671, 52);
            this.txtProductDescription.TabIndex = 36;
            // 
            // lblSalesIDView
            // 
            this.lblSalesIDView.AutoSize = true;
            this.lblSalesIDView.Font = new System.Drawing.Font("Arial", 12F);
            this.lblSalesIDView.Location = new System.Drawing.Point(528, 42);
            this.lblSalesIDView.Name = "lblSalesIDView";
            this.lblSalesIDView.Size = new System.Drawing.Size(27, 18);
            this.lblSalesIDView.TabIndex = 77;
            this.lblSalesIDView.Text = "ID:";
            // 
            // txtProductID
            // 
            this.txtProductID.Enabled = false;
            this.txtProductID.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductID.Location = new System.Drawing.Point(98, 474);
            this.txtProductID.Name = "txtProductID";
            this.txtProductID.Size = new System.Drawing.Size(133, 26);
            this.txtProductID.TabIndex = 28;
            // 
            // rdoSortByDateSoldView
            // 
            this.rdoSortByDateSoldView.AutoSize = true;
            this.rdoSortByDateSoldView.Font = new System.Drawing.Font("Arial", 12F);
            this.rdoSortByDateSoldView.Location = new System.Drawing.Point(367, 3);
            this.rdoSortByDateSoldView.Name = "rdoSortByDateSoldView";
            this.rdoSortByDateSoldView.Size = new System.Drawing.Size(190, 22);
            this.rdoSortByDateSoldView.TabIndex = 2;
            this.rdoSortByDateSoldView.TabStop = true;
            this.rdoSortByDateSoldView.Text = "Sort by transaction date";
            this.rdoSortByDateSoldView.UseVisualStyleBackColor = true;
            this.rdoSortByDateSoldView.CheckedChanged += new System.EventHandler(this.rdoSortByDateSold_CheckedChanged);
            // 
            // lblProductNotes
            // 
            this.lblProductNotes.AutoSize = true;
            this.lblProductNotes.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductNotes.Location = new System.Drawing.Point(342, 567);
            this.lblProductNotes.Name = "lblProductNotes";
            this.lblProductNotes.Size = new System.Drawing.Size(53, 18);
            this.lblProductNotes.TabIndex = 47;
            this.lblProductNotes.Text = "Notes:";
            // 
            // txtDateSold
            // 
            this.txtDateSold.Enabled = false;
            this.txtDateSold.Font = new System.Drawing.Font("Arial", 12F);
            this.txtDateSold.Location = new System.Drawing.Point(290, 161);
            this.txtDateSold.Name = "txtDateSold";
            this.txtDateSold.Size = new System.Drawing.Size(113, 26);
            this.txtDateSold.TabIndex = 75;
            // 
            // lblProductRunningTotal
            // 
            this.lblProductRunningTotal.AutoSize = true;
            this.lblProductRunningTotal.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductRunningTotal.Location = new System.Drawing.Point(247, 478);
            this.lblProductRunningTotal.Name = "lblProductRunningTotal";
            this.lblProductRunningTotal.Size = new System.Drawing.Size(104, 18);
            this.lblProductRunningTotal.TabIndex = 46;
            this.lblProductRunningTotal.Text = "Running Total:";
            // 
            // txtProductCostToMake
            // 
            this.txtProductCostToMake.Enabled = false;
            this.txtProductCostToMake.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductCostToMake.Location = new System.Drawing.Point(365, 402);
            this.txtProductCostToMake.Name = "txtProductCostToMake";
            this.txtProductCostToMake.Size = new System.Drawing.Size(152, 26);
            this.txtProductCostToMake.TabIndex = 41;
            // 
            // chkProductActive
            // 
            this.chkProductActive.AutoSize = true;
            this.chkProductActive.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkProductActive.Enabled = false;
            this.chkProductActive.Font = new System.Drawing.Font("Arial", 12F);
            this.chkProductActive.Location = new System.Drawing.Point(527, 400);
            this.chkProductActive.Name = "chkProductActive";
            this.chkProductActive.Size = new System.Drawing.Size(74, 22);
            this.chkProductActive.TabIndex = 29;
            this.chkProductActive.Text = "Active:";
            this.chkProductActive.UseVisualStyleBackColor = true;
            // 
            // chkProductCustom
            // 
            this.chkProductCustom.AutoSize = true;
            this.chkProductCustom.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkProductCustom.Enabled = false;
            this.chkProductCustom.Font = new System.Drawing.Font("Arial", 12F);
            this.chkProductCustom.Location = new System.Drawing.Point(637, 400);
            this.chkProductCustom.Name = "chkProductCustom";
            this.chkProductCustom.Size = new System.Drawing.Size(85, 22);
            this.chkProductCustom.TabIndex = 32;
            this.chkProductCustom.Text = "Custom:";
            this.chkProductCustom.UseVisualStyleBackColor = true;
            // 
            // rdoSortByCustomerView
            // 
            this.rdoSortByCustomerView.AutoSize = true;
            this.rdoSortByCustomerView.Font = new System.Drawing.Font("Arial", 12F);
            this.rdoSortByCustomerView.Location = new System.Drawing.Point(187, 3);
            this.rdoSortByCustomerView.Name = "rdoSortByCustomerView";
            this.rdoSortByCustomerView.Size = new System.Drawing.Size(143, 22);
            this.rdoSortByCustomerView.TabIndex = 1;
            this.rdoSortByCustomerView.TabStop = true;
            this.rdoSortByCustomerView.Text = "Sort by customer";
            this.rdoSortByCustomerView.UseVisualStyleBackColor = true;
            this.rdoSortByCustomerView.CheckedChanged += new System.EventHandler(this.rdoSortByCustomer_CheckedChanged);
            // 
            // lblProductColor
            // 
            this.lblProductColor.AutoSize = true;
            this.lblProductColor.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductColor.Location = new System.Drawing.Point(526, 436);
            this.lblProductColor.Name = "lblProductColor";
            this.lblProductColor.Size = new System.Drawing.Size(88, 18);
            this.lblProductColor.TabIndex = 37;
            this.lblProductColor.Text = "Main Color:";
            // 
            // cbxTransactionView
            // 
            this.cbxTransactionView.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxTransactionView.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxTransactionView.FormattingEnabled = true;
            this.cbxTransactionView.Location = new System.Drawing.Point(271, 37);
            this.cbxTransactionView.MaxDropDownItems = 100;
            this.cbxTransactionView.Name = "cbxTransactionView";
            this.cbxTransactionView.Size = new System.Drawing.Size(251, 26);
            this.cbxTransactionView.TabIndex = 3;
            this.cbxTransactionView.SelectedIndexChanged += new System.EventHandler(this.cbxTransaction_SelectedIndexChanged);
            // 
            // lblProductDimentions
            // 
            this.lblProductDimentions.AutoSize = true;
            this.lblProductDimentions.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductDimentions.Location = new System.Drawing.Point(523, 474);
            this.lblProductDimentions.Name = "lblProductDimentions";
            this.lblProductDimentions.Size = new System.Drawing.Size(91, 18);
            this.lblProductDimentions.TabIndex = 33;
            this.lblProductDimentions.Text = "Dimentions:";
            // 
            // txtStore
            // 
            this.txtStore.Enabled = false;
            this.txtStore.Font = new System.Drawing.Font("Arial", 12F);
            this.txtStore.Location = new System.Drawing.Point(623, 163);
            this.txtStore.Name = "txtStore";
            this.txtStore.Size = new System.Drawing.Size(162, 26);
            this.txtStore.TabIndex = 70;
            // 
            // lblProductDescription
            // 
            this.lblProductDescription.AutoSize = true;
            this.lblProductDescription.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductDescription.Location = new System.Drawing.Point(3, 512);
            this.lblProductDescription.Name = "lblProductDescription";
            this.lblProductDescription.Size = new System.Drawing.Size(92, 18);
            this.lblProductDescription.TabIndex = 30;
            this.lblProductDescription.Text = "Description:";
            // 
            // lblStore
            // 
            this.lblStore.AutoSize = true;
            this.lblStore.Font = new System.Drawing.Font("Arial", 12F);
            this.lblStore.Location = new System.Drawing.Point(565, 168);
            this.lblStore.Name = "lblStore";
            this.lblStore.Size = new System.Drawing.Size(50, 18);
            this.lblStore.TabIndex = 69;
            this.lblStore.Text = "Store:";
            // 
            // lblProductID
            // 
            this.lblProductID.AutoSize = true;
            this.lblProductID.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductID.Location = new System.Drawing.Point(7, 480);
            this.lblProductID.Name = "lblProductID";
            this.lblProductID.Size = new System.Drawing.Size(85, 18);
            this.lblProductID.TabIndex = 27;
            this.lblProductID.Text = "Product ID:";
            // 
            // lblDateSold
            // 
            this.lblDateSold.AutoSize = true;
            this.lblDateSold.Font = new System.Drawing.Font("Arial", 12F);
            this.lblDateSold.Location = new System.Drawing.Point(194, 165);
            this.lblDateSold.Name = "lblDateSold";
            this.lblDateSold.Size = new System.Drawing.Size(82, 18);
            this.lblDateSold.TabIndex = 68;
            this.lblDateSold.Text = "Date Sold:";
            // 
            // txtAmountSold
            // 
            this.txtAmountSold.Enabled = false;
            this.txtAmountSold.Font = new System.Drawing.Font("Arial", 12F);
            this.txtAmountSold.Location = new System.Drawing.Point(623, 225);
            this.txtAmountSold.Name = "txtAmountSold";
            this.txtAmountSold.Size = new System.Drawing.Size(162, 26);
            this.txtAmountSold.TabIndex = 65;
            // 
            // lblProductCostToMake
            // 
            this.lblProductCostToMake.AutoSize = true;
            this.lblProductCostToMake.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductCostToMake.Location = new System.Drawing.Point(250, 406);
            this.lblProductCostToMake.Name = "lblProductCostToMake";
            this.lblProductCostToMake.Size = new System.Drawing.Size(108, 18);
            this.lblProductCostToMake.TabIndex = 42;
            this.lblProductCostToMake.Text = "Cost To Make:";
            // 
            // lblAmoutSold
            // 
            this.lblAmoutSold.AutoSize = true;
            this.lblAmoutSold.Font = new System.Drawing.Font("Arial", 12F);
            this.lblAmoutSold.Location = new System.Drawing.Point(409, 229);
            this.lblAmoutSold.Name = "lblAmoutSold";
            this.lblAmoutSold.Size = new System.Drawing.Size(203, 18);
            this.lblAmoutSold.TabIndex = 66;
            this.lblAmoutSold.Text = "Products sold in transaction:";
            // 
            // txtSalesCustomerTotalItemsPurchased
            // 
            this.txtSalesCustomerTotalItemsPurchased.Enabled = false;
            this.txtSalesCustomerTotalItemsPurchased.Font = new System.Drawing.Font("Arial", 12F);
            this.txtSalesCustomerTotalItemsPurchased.Location = new System.Drawing.Point(462, 340);
            this.txtSalesCustomerTotalItemsPurchased.Name = "txtSalesCustomerTotalItemsPurchased";
            this.txtSalesCustomerTotalItemsPurchased.Size = new System.Drawing.Size(95, 26);
            this.txtSalesCustomerTotalItemsPurchased.TabIndex = 63;
            // 
            // lblSalesCustomerTotalItemsPurchased
            // 
            this.lblSalesCustomerTotalItemsPurchased.AutoSize = true;
            this.lblSalesCustomerTotalItemsPurchased.Font = new System.Drawing.Font("Arial", 12F);
            this.lblSalesCustomerTotalItemsPurchased.Location = new System.Drawing.Point(284, 346);
            this.lblSalesCustomerTotalItemsPurchased.Name = "lblSalesCustomerTotalItemsPurchased";
            this.lblSalesCustomerTotalItemsPurchased.Size = new System.Drawing.Size(164, 18);
            this.lblSalesCustomerTotalItemsPurchased.TabIndex = 64;
            this.lblSalesCustomerTotalItemsPurchased.Text = "Total Items Purchased:";
            // 
            // txtSalesCustomerName
            // 
            this.txtSalesCustomerName.Enabled = false;
            this.txtSalesCustomerName.Font = new System.Drawing.Font("Arial", 12F);
            this.txtSalesCustomerName.Location = new System.Drawing.Point(62, 343);
            this.txtSalesCustomerName.Name = "txtSalesCustomerName";
            this.txtSalesCustomerName.Size = new System.Drawing.Size(216, 26);
            this.txtSalesCustomerName.TabIndex = 62;
            // 
            // lblSalesCustomerName
            // 
            this.lblSalesCustomerName.AutoSize = true;
            this.lblSalesCustomerName.Font = new System.Drawing.Font("Arial", 12F);
            this.lblSalesCustomerName.Location = new System.Drawing.Point(1, 349);
            this.lblSalesCustomerName.Name = "lblSalesCustomerName";
            this.lblSalesCustomerName.Size = new System.Drawing.Size(54, 18);
            this.lblSalesCustomerName.TabIndex = 61;
            this.lblSalesCustomerName.Text = "Name:";
            // 
            // lblCustomerInfo
            // 
            this.lblCustomerInfo.AutoSize = true;
            this.lblCustomerInfo.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Underline);
            this.lblCustomerInfo.Location = new System.Drawing.Point(0, 320);
            this.lblCustomerInfo.Name = "lblCustomerInfo";
            this.lblCustomerInfo.Size = new System.Drawing.Size(160, 18);
            this.lblCustomerInfo.TabIndex = 60;
            this.lblCustomerInfo.Text = "Customer Information:";
            // 
            // lblSalesInfo
            // 
            this.lblSalesInfo.AutoSize = true;
            this.lblSalesInfo.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Underline);
            this.lblSalesInfo.Location = new System.Drawing.Point(3, 101);
            this.lblSalesInfo.Name = "lblSalesInfo";
            this.lblSalesInfo.Size = new System.Drawing.Size(132, 18);
            this.lblSalesInfo.TabIndex = 59;
            this.lblSalesInfo.Text = "Sales Information:";
            // 
            // lblPleaseSelectTransactionView
            // 
            this.lblPleaseSelectTransactionView.AutoSize = true;
            this.lblPleaseSelectTransactionView.Font = new System.Drawing.Font("Arial", 12F);
            this.lblPleaseSelectTransactionView.Location = new System.Drawing.Point(10, 45);
            this.lblPleaseSelectTransactionView.Name = "lblPleaseSelectTransactionView";
            this.lblPleaseSelectTransactionView.Size = new System.Drawing.Size(251, 18);
            this.lblPleaseSelectTransactionView.TabIndex = 58;
            this.lblPleaseSelectTransactionView.Text = "Please select a transaction to view:";
            // 
            // lblProductInformation
            // 
            this.lblProductInformation.AutoSize = true;
            this.lblProductInformation.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Underline);
            this.lblProductInformation.Location = new System.Drawing.Point(0, 380);
            this.lblProductInformation.Name = "lblProductInformation";
            this.lblProductInformation.Size = new System.Drawing.Size(146, 18);
            this.lblProductInformation.TabIndex = 57;
            this.lblProductInformation.Text = "Product Information:";
            // 
            // txtProductName
            // 
            this.txtProductName.Enabled = false;
            this.txtProductName.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductName.Location = new System.Drawing.Point(60, 403);
            this.txtProductName.Name = "txtProductName";
            this.txtProductName.Size = new System.Drawing.Size(171, 26);
            this.txtProductName.TabIndex = 55;
            // 
            // lblProductName
            // 
            this.lblProductName.AutoSize = true;
            this.lblProductName.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductName.Location = new System.Drawing.Point(2, 406);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(54, 18);
            this.lblProductName.TabIndex = 54;
            this.lblProductName.Text = "Name:";
            // 
            // txtProductSellPrice
            // 
            this.txtProductSellPrice.Enabled = false;
            this.txtProductSellPrice.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductSellPrice.Location = new System.Drawing.Point(290, 195);
            this.txtProductSellPrice.Name = "txtProductSellPrice";
            this.txtProductSellPrice.Size = new System.Drawing.Size(113, 26);
            this.txtProductSellPrice.TabIndex = 34;
            // 
            // lblProductSellPrice
            // 
            this.lblProductSellPrice.AutoSize = true;
            this.lblProductSellPrice.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductSellPrice.Location = new System.Drawing.Point(67, 198);
            this.lblProductSellPrice.Name = "lblProductSellPrice";
            this.lblProductSellPrice.Size = new System.Drawing.Size(213, 18);
            this.lblProductSellPrice.TabIndex = 35;
            this.lblProductSellPrice.Text = "Sell price of selected product:";
            // 
            // txtProductOnHand
            // 
            this.txtProductOnHand.Enabled = false;
            this.txtProductOnHand.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductOnHand.Location = new System.Drawing.Point(365, 434);
            this.txtProductOnHand.Name = "txtProductOnHand";
            this.txtProductOnHand.Size = new System.Drawing.Size(152, 26);
            this.txtProductOnHand.TabIndex = 43;
            // 
            // txtProductType
            // 
            this.txtProductType.Enabled = false;
            this.txtProductType.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductType.Location = new System.Drawing.Point(60, 435);
            this.txtProductType.MaxLength = 50;
            this.txtProductType.Name = "txtProductType";
            this.txtProductType.Size = new System.Drawing.Size(171, 26);
            this.txtProductType.TabIndex = 39;
            // 
            // lblProductOnHand
            // 
            this.lblProductOnHand.AutoSize = true;
            this.lblProductOnHand.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductOnHand.Location = new System.Drawing.Point(281, 440);
            this.lblProductOnHand.Name = "lblProductOnHand";
            this.lblProductOnHand.Size = new System.Drawing.Size(73, 18);
            this.lblProductOnHand.TabIndex = 31;
            this.lblProductOnHand.Text = "On Hand:";
            // 
            // lblProductType
            // 
            this.lblProductType.AutoSize = true;
            this.lblProductType.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductType.Location = new System.Drawing.Point(7, 441);
            this.lblProductType.Name = "lblProductType";
            this.lblProductType.Size = new System.Drawing.Size(45, 18);
            this.lblProductType.TabIndex = 40;
            this.lblProductType.Text = "Type:";
            // 
            // pnlMakeUpdateTransaction
            // 
            this.pnlMakeUpdateTransaction.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlMakeUpdateTransaction.Controls.Add(this.txtProductsSoldIDEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.cbxSoldProductIDEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblPleaseSelectATransactionID);
            this.pnlMakeUpdateTransaction.Controls.Add(this.btnEditAmountSold);
            this.pnlMakeUpdateTransaction.Controls.Add(this.txtAmountSoldEdit2);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblProductsSoldID);
            this.pnlMakeUpdateTransaction.Controls.Add(this.dtDateSoldEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.cbxCustomerIDEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblCustomerIDEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.cbxCustomerEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblPleaseSelectACustomer);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblProductIDSales);
            this.pnlMakeUpdateTransaction.Controls.Add(this.btnUpdateAddSales);
            this.pnlMakeUpdateTransaction.Controls.Add(this.btnUpdateMarkup);
            this.pnlMakeUpdateTransaction.Controls.Add(this.txtProfitEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblProfitEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.pnlAmountSold);
            this.pnlMakeUpdateTransaction.Controls.Add(this.txtSellPriceEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lbxProductIDEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblSellPriceEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.rdoSortByTransactionDateEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.rdoSortByCustomerEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.btnSubtractProduct);
            this.pnlMakeUpdateTransaction.Controls.Add(this.btnAddProduct);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblAmountSoldEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblProductsSoldEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lbxProductsSoldEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lbxProductsEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.txtTotalProfitEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.txtMarkupPercentageEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.txtStoreEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.txtTransactionIDEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblTotalProfitEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblMarkupPercentageEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblProductsEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblStoreEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblDateSoldEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblTransactionIDEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.cbxSalesIDEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblSalesIDEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.cbxTransactionEdit);
            this.pnlMakeUpdateTransaction.Controls.Add(this.lblPleaseSelectTransactionEdit);
            this.pnlMakeUpdateTransaction.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.pnlMakeUpdateTransaction.Location = new System.Drawing.Point(0, 0);
            this.pnlMakeUpdateTransaction.Name = "pnlMakeUpdateTransaction";
            this.pnlMakeUpdateTransaction.Size = new System.Drawing.Size(802, 710);
            this.pnlMakeUpdateTransaction.TabIndex = 77;
            // 
            // txtProductsSoldIDEdit
            // 
            this.txtProductsSoldIDEdit.Enabled = false;
            this.txtProductsSoldIDEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProductsSoldIDEdit.Location = new System.Drawing.Point(669, 286);
            this.txtProductsSoldIDEdit.Name = "txtProductsSoldIDEdit";
            this.txtProductsSoldIDEdit.Size = new System.Drawing.Size(82, 26);
            this.txtProductsSoldIDEdit.TabIndex = 124;
            // 
            // cbxSoldProductIDEdit
            // 
            this.cbxSoldProductIDEdit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSoldProductIDEdit.Enabled = false;
            this.cbxSoldProductIDEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxSoldProductIDEdit.FormattingEnabled = true;
            this.cbxSoldProductIDEdit.Location = new System.Drawing.Point(313, 76);
            this.cbxSoldProductIDEdit.MaxDropDownItems = 100;
            this.cbxSoldProductIDEdit.Name = "cbxSoldProductIDEdit";
            this.cbxSoldProductIDEdit.Size = new System.Drawing.Size(121, 26);
            this.cbxSoldProductIDEdit.TabIndex = 122;
            this.cbxSoldProductIDEdit.Visible = false;
            this.cbxSoldProductIDEdit.SelectedIndexChanged += new System.EventHandler(this.cbxSoldProductIDEdit_SelectedIndexChanged);
            // 
            // lblPleaseSelectATransactionID
            // 
            this.lblPleaseSelectATransactionID.AutoSize = true;
            this.lblPleaseSelectATransactionID.Font = new System.Drawing.Font("Arial", 12F);
            this.lblPleaseSelectATransactionID.Location = new System.Drawing.Point(84, 80);
            this.lblPleaseSelectATransactionID.Name = "lblPleaseSelectATransactionID";
            this.lblPleaseSelectATransactionID.Size = new System.Drawing.Size(218, 18);
            this.lblPleaseSelectATransactionID.TabIndex = 123;
            this.lblPleaseSelectATransactionID.Text = "Please select a transaction ID:";
            this.lblPleaseSelectATransactionID.Visible = false;
            // 
            // btnEditAmountSold
            // 
            this.btnEditAmountSold.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnEditAmountSold.BackgroundImage")));
            this.btnEditAmountSold.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnEditAmountSold.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnEditAmountSold.Font = new System.Drawing.Font("Arial", 8F);
            this.btnEditAmountSold.Location = new System.Drawing.Point(539, 438);
            this.btnEditAmountSold.Name = "btnEditAmountSold";
            this.btnEditAmountSold.Size = new System.Drawing.Size(95, 27);
            this.btnEditAmountSold.TabIndex = 18;
            this.btnEditAmountSold.Text = "Edit amount sold";
            this.btnEditAmountSold.UseVisualStyleBackColor = true;
            this.btnEditAmountSold.Click += new System.EventHandler(this.btnEditAmountSold_Click);
            // 
            // txtAmountSoldEdit2
            // 
            this.txtAmountSoldEdit2.Enabled = false;
            this.txtAmountSoldEdit2.Font = new System.Drawing.Font("Arial", 12F);
            this.txtAmountSoldEdit2.Location = new System.Drawing.Point(370, 440);
            this.txtAmountSoldEdit2.Name = "txtAmountSoldEdit2";
            this.txtAmountSoldEdit2.Size = new System.Drawing.Size(162, 26);
            this.txtAmountSoldEdit2.TabIndex = 17;
            // 
            // lblProductsSoldID
            // 
            this.lblProductsSoldID.AutoSize = true;
            this.lblProductsSoldID.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductsSoldID.Location = new System.Drawing.Point(667, 263);
            this.lblProductsSoldID.Name = "lblProductsSoldID";
            this.lblProductsSoldID.Size = new System.Drawing.Size(27, 18);
            this.lblProductsSoldID.TabIndex = 121;
            this.lblProductsSoldID.Text = "ID:";
            // 
            // dtDateSoldEdit
            // 
            this.dtDateSoldEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.dtDateSoldEdit.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dtDateSoldEdit.Location = new System.Drawing.Point(206, 197);
            this.dtDateSoldEdit.Name = "dtDateSoldEdit";
            this.dtDateSoldEdit.Size = new System.Drawing.Size(200, 26);
            this.dtDateSoldEdit.TabIndex = 9;
            // 
            // cbxCustomerIDEdit
            // 
            this.cbxCustomerIDEdit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxCustomerIDEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxCustomerIDEdit.FormattingEnabled = true;
            this.cbxCustomerIDEdit.Location = new System.Drawing.Point(606, 110);
            this.cbxCustomerIDEdit.MaxDropDownItems = 100;
            this.cbxCustomerIDEdit.Name = "cbxCustomerIDEdit";
            this.cbxCustomerIDEdit.Size = new System.Drawing.Size(121, 26);
            this.cbxCustomerIDEdit.TabIndex = 6;
            this.cbxCustomerIDEdit.SelectedIndexChanged += new System.EventHandler(this.cbxCustomerIDEdit_SelectedIndexChanged);
            // 
            // lblCustomerIDEdit
            // 
            this.lblCustomerIDEdit.AutoSize = true;
            this.lblCustomerIDEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblCustomerIDEdit.Location = new System.Drawing.Point(570, 115);
            this.lblCustomerIDEdit.Name = "lblCustomerIDEdit";
            this.lblCustomerIDEdit.Size = new System.Drawing.Size(27, 18);
            this.lblCustomerIDEdit.TabIndex = 119;
            this.lblCustomerIDEdit.Text = "ID:";
            // 
            // cbxCustomerEdit
            // 
            this.cbxCustomerEdit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxCustomerEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxCustomerEdit.FormattingEnabled = true;
            this.cbxCustomerEdit.Location = new System.Drawing.Point(313, 110);
            this.cbxCustomerEdit.MaxDropDownItems = 100;
            this.cbxCustomerEdit.Name = "cbxCustomerEdit";
            this.cbxCustomerEdit.Size = new System.Drawing.Size(251, 26);
            this.cbxCustomerEdit.TabIndex = 5;
            this.cbxCustomerEdit.SelectedIndexChanged += new System.EventHandler(this.cbxCustomerEdit_SelectedIndexChanged);
            // 
            // lblPleaseSelectACustomer
            // 
            this.lblPleaseSelectACustomer.Font = new System.Drawing.Font("Arial", 12F);
            this.lblPleaseSelectACustomer.Location = new System.Drawing.Point(52, 114);
            this.lblPleaseSelectACustomer.Name = "lblPleaseSelectACustomer";
            this.lblPleaseSelectACustomer.Size = new System.Drawing.Size(253, 20);
            this.lblPleaseSelectACustomer.TabIndex = 118;
            this.lblPleaseSelectACustomer.Text = "Please select a customer to sell to:";
            this.lblPleaseSelectACustomer.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblProductIDSales
            // 
            this.lblProductIDSales.AutoSize = true;
            this.lblProductIDSales.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductIDSales.Location = new System.Drawing.Point(300, 263);
            this.lblProductIDSales.Name = "lblProductIDSales";
            this.lblProductIDSales.Size = new System.Drawing.Size(27, 18);
            this.lblProductIDSales.TabIndex = 115;
            this.lblProductIDSales.Text = "ID:";
            // 
            // btnUpdateAddSales
            // 
            this.btnUpdateAddSales.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpdateAddSales.BackgroundImage")));
            this.btnUpdateAddSales.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnUpdateAddSales.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUpdateAddSales.Font = new System.Drawing.Font("Arial", 12F);
            this.btnUpdateAddSales.Location = new System.Drawing.Point(682, 658);
            this.btnUpdateAddSales.Name = "btnUpdateAddSales";
            this.btnUpdateAddSales.Size = new System.Drawing.Size(111, 34);
            this.btnUpdateAddSales.TabIndex = 24;
            this.btnUpdateAddSales.Text = "Save/Add";
            this.btnUpdateAddSales.UseVisualStyleBackColor = true;
            this.btnUpdateAddSales.Click += new System.EventHandler(this.btnUpdateAddSales_Click);
            // 
            // btnUpdateMarkup
            // 
            this.btnUpdateMarkup.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpdateMarkup.BackgroundImage")));
            this.btnUpdateMarkup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnUpdateMarkup.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUpdateMarkup.Font = new System.Drawing.Font("Arial", 8F);
            this.btnUpdateMarkup.Location = new System.Drawing.Point(538, 471);
            this.btnUpdateMarkup.Name = "btnUpdateMarkup";
            this.btnUpdateMarkup.Size = new System.Drawing.Size(95, 27);
            this.btnUpdateMarkup.TabIndex = 20;
            this.btnUpdateMarkup.Text = "Update Markup";
            this.btnUpdateMarkup.UseVisualStyleBackColor = true;
            this.btnUpdateMarkup.Click += new System.EventHandler(this.btnUpdateMarkup_Click);
            // 
            // txtProfitEdit
            // 
            this.txtProfitEdit.Enabled = false;
            this.txtProfitEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.txtProfitEdit.Location = new System.Drawing.Point(369, 545);
            this.txtProfitEdit.Name = "txtProfitEdit";
            this.txtProfitEdit.Size = new System.Drawing.Size(163, 26);
            this.txtProfitEdit.TabIndex = 22;
            // 
            // lblProfitEdit
            // 
            this.lblProfitEdit.AutoSize = true;
            this.lblProfitEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProfitEdit.Location = new System.Drawing.Point(182, 549);
            this.lblProfitEdit.Name = "lblProfitEdit";
            this.lblProfitEdit.Size = new System.Drawing.Size(168, 18);
            this.lblProfitEdit.TabIndex = 114;
            this.lblProfitEdit.Text = "Profit for selected item:";
            // 
            // pnlAmountSold
            // 
            this.pnlAmountSold.Controls.Add(this.btnCancel);
            this.pnlAmountSold.Controls.Add(this.btnAmountSoldComfirmation);
            this.pnlAmountSold.Controls.Add(this.lblPleaseEnterAmountSold);
            this.pnlAmountSold.Controls.Add(this.txtAmountSoldEdit);
            this.pnlAmountSold.Enabled = false;
            this.pnlAmountSold.Location = new System.Drawing.Point(296, 296);
            this.pnlAmountSold.Name = "pnlAmountSold";
            this.pnlAmountSold.Size = new System.Drawing.Size(224, 83);
            this.pnlAmountSold.TabIndex = 16;
            this.pnlAmountSold.Visible = false;
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F);
            this.btnCancel.Location = new System.Drawing.Point(196, -1);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(29, 23);
            this.btnCancel.TabIndex = 89;
            this.btnCancel.Text = "X";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnAmountSoldComfirmation
            // 
            this.btnAmountSoldComfirmation.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F);
            this.btnAmountSoldComfirmation.Location = new System.Drawing.Point(164, 50);
            this.btnAmountSoldComfirmation.Name = "btnAmountSoldComfirmation";
            this.btnAmountSoldComfirmation.Size = new System.Drawing.Size(43, 23);
            this.btnAmountSoldComfirmation.TabIndex = 2;
            this.btnAmountSoldComfirmation.Text = "✔";
            this.btnAmountSoldComfirmation.UseVisualStyleBackColor = true;
            this.btnAmountSoldComfirmation.Click += new System.EventHandler(this.btnAmountSoldComfirmation_Click);
            // 
            // lblPleaseEnterAmountSold
            // 
            this.lblPleaseEnterAmountSold.AutoSize = true;
            this.lblPleaseEnterAmountSold.Font = new System.Drawing.Font("Arial", 12F);
            this.lblPleaseEnterAmountSold.Location = new System.Drawing.Point(3, 24);
            this.lblPleaseEnterAmountSold.Name = "lblPleaseEnterAmountSold";
            this.lblPleaseEnterAmountSold.Size = new System.Drawing.Size(213, 18);
            this.lblPleaseEnterAmountSold.TabIndex = 88;
            this.lblPleaseEnterAmountSold.Text = "Please enter the amount sold:";
            // 
            // txtAmountSoldEdit
            // 
            this.txtAmountSoldEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.txtAmountSoldEdit.Location = new System.Drawing.Point(11, 49);
            this.txtAmountSoldEdit.Name = "txtAmountSoldEdit";
            this.txtAmountSoldEdit.Size = new System.Drawing.Size(135, 26);
            this.txtAmountSoldEdit.TabIndex = 1;
            // 
            // txtSellPriceEdit
            // 
            this.txtSellPriceEdit.Enabled = false;
            this.txtSellPriceEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.txtSellPriceEdit.Location = new System.Drawing.Point(369, 507);
            this.txtSellPriceEdit.Name = "txtSellPriceEdit";
            this.txtSellPriceEdit.Size = new System.Drawing.Size(163, 26);
            this.txtSellPriceEdit.TabIndex = 21;
            // 
            // lbxProductIDEdit
            // 
            this.lbxProductIDEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.lbxProductIDEdit.FormattingEnabled = true;
            this.lbxProductIDEdit.ItemHeight = 18;
            this.lbxProductIDEdit.Location = new System.Drawing.Point(302, 287);
            this.lbxProductIDEdit.Name = "lbxProductIDEdit";
            this.lbxProductIDEdit.Size = new System.Drawing.Size(69, 130);
            this.lbxProductIDEdit.TabIndex = 11;
            // 
            // lblSellPriceEdit
            // 
            this.lblSellPriceEdit.AutoSize = true;
            this.lblSellPriceEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblSellPriceEdit.Location = new System.Drawing.Point(155, 510);
            this.lblSellPriceEdit.Name = "lblSellPriceEdit";
            this.lblSellPriceEdit.Size = new System.Drawing.Size(196, 18);
            this.lblSellPriceEdit.TabIndex = 111;
            this.lblSellPriceEdit.Text = "Sell price for selected item:";
            // 
            // rdoSortByTransactionDateEdit
            // 
            this.rdoSortByTransactionDateEdit.AutoSize = true;
            this.rdoSortByTransactionDateEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.rdoSortByTransactionDateEdit.Location = new System.Drawing.Point(392, 7);
            this.rdoSortByTransactionDateEdit.Name = "rdoSortByTransactionDateEdit";
            this.rdoSortByTransactionDateEdit.Size = new System.Drawing.Size(190, 22);
            this.rdoSortByTransactionDateEdit.TabIndex = 2;
            this.rdoSortByTransactionDateEdit.TabStop = true;
            this.rdoSortByTransactionDateEdit.Text = "Sort by transaction date";
            this.rdoSortByTransactionDateEdit.UseVisualStyleBackColor = true;
            this.rdoSortByTransactionDateEdit.CheckedChanged += new System.EventHandler(this.rdoSortByTransactionDateEdit_CheckedChanged);
            // 
            // rdoSortByCustomerEdit
            // 
            this.rdoSortByCustomerEdit.AutoSize = true;
            this.rdoSortByCustomerEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.rdoSortByCustomerEdit.Location = new System.Drawing.Point(212, 7);
            this.rdoSortByCustomerEdit.Name = "rdoSortByCustomerEdit";
            this.rdoSortByCustomerEdit.Size = new System.Drawing.Size(143, 22);
            this.rdoSortByCustomerEdit.TabIndex = 1;
            this.rdoSortByCustomerEdit.TabStop = true;
            this.rdoSortByCustomerEdit.Text = "Sort by customer";
            this.rdoSortByCustomerEdit.UseVisualStyleBackColor = true;
            this.rdoSortByCustomerEdit.CheckedChanged += new System.EventHandler(this.rdoSortByCustomerEdit_CheckedChanged);
            // 
            // btnSubtractProduct
            // 
            this.btnSubtractProduct.Location = new System.Drawing.Point(382, 351);
            this.btnSubtractProduct.Name = "btnSubtractProduct";
            this.btnSubtractProduct.Size = new System.Drawing.Size(28, 28);
            this.btnSubtractProduct.TabIndex = 13;
            this.btnSubtractProduct.Text = "<";
            this.btnSubtractProduct.UseVisualStyleBackColor = true;
            this.btnSubtractProduct.Click += new System.EventHandler(this.btnSubtractProduct_Click);
            // 
            // btnAddProduct
            // 
            this.btnAddProduct.Location = new System.Drawing.Point(382, 317);
            this.btnAddProduct.Name = "btnAddProduct";
            this.btnAddProduct.Size = new System.Drawing.Size(28, 28);
            this.btnAddProduct.TabIndex = 12;
            this.btnAddProduct.Text = ">";
            this.btnAddProduct.UseVisualStyleBackColor = true;
            this.btnAddProduct.Click += new System.EventHandler(this.btnAddProduct_Click);
            // 
            // lblAmountSoldEdit
            // 
            this.lblAmountSoldEdit.AutoSize = true;
            this.lblAmountSoldEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblAmountSoldEdit.Location = new System.Drawing.Point(130, 442);
            this.lblAmountSoldEdit.Name = "lblAmountSoldEdit";
            this.lblAmountSoldEdit.Size = new System.Drawing.Size(217, 18);
            this.lblAmountSoldEdit.TabIndex = 106;
            this.lblAmountSoldEdit.Text = "Amount sold for selected item:";
            // 
            // lblProductsSoldEdit
            // 
            this.lblProductsSoldEdit.AutoSize = true;
            this.lblProductsSoldEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductsSoldEdit.Location = new System.Drawing.Point(413, 264);
            this.lblProductsSoldEdit.Name = "lblProductsSoldEdit";
            this.lblProductsSoldEdit.Size = new System.Drawing.Size(110, 18);
            this.lblProductsSoldEdit.TabIndex = 104;
            this.lblProductsSoldEdit.Text = "Products Sold:";
            // 
            // lbxProductsSoldEdit
            // 
            this.lbxProductsSoldEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.lbxProductsSoldEdit.FormattingEnabled = true;
            this.lbxProductsSoldEdit.ItemHeight = 18;
            this.lbxProductsSoldEdit.Location = new System.Drawing.Point(416, 287);
            this.lbxProductsSoldEdit.Name = "lbxProductsSoldEdit";
            this.lbxProductsSoldEdit.Size = new System.Drawing.Size(247, 130);
            this.lbxProductsSoldEdit.TabIndex = 14;
            this.lbxProductsSoldEdit.SelectedIndexChanged += new System.EventHandler(this.lbxProductsSoldEdit_SelectedIndexChanged);
            // 
            // lbxProductsEdit
            // 
            this.lbxProductsEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.lbxProductsEdit.FormattingEnabled = true;
            this.lbxProductsEdit.ItemHeight = 18;
            this.lbxProductsEdit.Location = new System.Drawing.Point(56, 287);
            this.lbxProductsEdit.Name = "lbxProductsEdit";
            this.lbxProductsEdit.Size = new System.Drawing.Size(240, 130);
            this.lbxProductsEdit.TabIndex = 10;
            this.lbxProductsEdit.SelectedIndexChanged += new System.EventHandler(this.lbxProductsEdit_SelectedIndexChanged);
            // 
            // txtTotalProfitEdit
            // 
            this.txtTotalProfitEdit.Enabled = false;
            this.txtTotalProfitEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.txtTotalProfitEdit.Location = new System.Drawing.Point(370, 602);
            this.txtTotalProfitEdit.Name = "txtTotalProfitEdit";
            this.txtTotalProfitEdit.Size = new System.Drawing.Size(162, 26);
            this.txtTotalProfitEdit.TabIndex = 23;
            // 
            // txtMarkupPercentageEdit
            // 
            this.txtMarkupPercentageEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.txtMarkupPercentageEdit.Location = new System.Drawing.Point(369, 472);
            this.txtMarkupPercentageEdit.Name = "txtMarkupPercentageEdit";
            this.txtMarkupPercentageEdit.Size = new System.Drawing.Size(163, 26);
            this.txtMarkupPercentageEdit.TabIndex = 19;
            this.txtMarkupPercentageEdit.Leave += new System.EventHandler(this.txtMarkupPercentageEdit_Leave);
            // 
            // txtStoreEdit
            // 
            this.txtStoreEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.txtStoreEdit.Location = new System.Drawing.Point(537, 163);
            this.txtStoreEdit.Name = "txtStoreEdit";
            this.txtStoreEdit.Size = new System.Drawing.Size(183, 26);
            this.txtStoreEdit.TabIndex = 8;
            // 
            // txtTransactionIDEdit
            // 
            this.txtTransactionIDEdit.Enabled = false;
            this.txtTransactionIDEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.txtTransactionIDEdit.Location = new System.Drawing.Point(206, 163);
            this.txtTransactionIDEdit.Name = "txtTransactionIDEdit";
            this.txtTransactionIDEdit.Size = new System.Drawing.Size(200, 26);
            this.txtTransactionIDEdit.TabIndex = 7;
            // 
            // lblTotalProfitEdit
            // 
            this.lblTotalProfitEdit.AutoSize = true;
            this.lblTotalProfitEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblTotalProfitEdit.Location = new System.Drawing.Point(264, 608);
            this.lblTotalProfitEdit.Name = "lblTotalProfitEdit";
            this.lblTotalProfitEdit.Size = new System.Drawing.Size(85, 18);
            this.lblTotalProfitEdit.TabIndex = 93;
            this.lblTotalProfitEdit.Text = "Total Profit:";
            // 
            // lblMarkupPercentageEdit
            // 
            this.lblMarkupPercentageEdit.AutoSize = true;
            this.lblMarkupPercentageEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblMarkupPercentageEdit.Location = new System.Drawing.Point(80, 476);
            this.lblMarkupPercentageEdit.Name = "lblMarkupPercentageEdit";
            this.lblMarkupPercentageEdit.Size = new System.Drawing.Size(268, 18);
            this.lblMarkupPercentageEdit.TabIndex = 92;
            this.lblMarkupPercentageEdit.Text = "Markup Percentage for selected item:";
            // 
            // lblProductsEdit
            // 
            this.lblProductsEdit.AutoSize = true;
            this.lblProductsEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblProductsEdit.Location = new System.Drawing.Point(52, 260);
            this.lblProductsEdit.Name = "lblProductsEdit";
            this.lblProductsEdit.Size = new System.Drawing.Size(74, 18);
            this.lblProductsEdit.TabIndex = 90;
            this.lblProductsEdit.Text = "Products:";
            // 
            // lblStoreEdit
            // 
            this.lblStoreEdit.AutoSize = true;
            this.lblStoreEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblStoreEdit.Location = new System.Drawing.Point(480, 166);
            this.lblStoreEdit.Name = "lblStoreEdit";
            this.lblStoreEdit.Size = new System.Drawing.Size(50, 18);
            this.lblStoreEdit.TabIndex = 89;
            this.lblStoreEdit.Text = "Store:";
            // 
            // lblDateSoldEdit
            // 
            this.lblDateSoldEdit.AutoSize = true;
            this.lblDateSoldEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblDateSoldEdit.Location = new System.Drawing.Point(114, 201);
            this.lblDateSoldEdit.Name = "lblDateSoldEdit";
            this.lblDateSoldEdit.Size = new System.Drawing.Size(82, 18);
            this.lblDateSoldEdit.TabIndex = 87;
            this.lblDateSoldEdit.Text = "Date Sold:";
            // 
            // lblTransactionIDEdit
            // 
            this.lblTransactionIDEdit.AutoSize = true;
            this.lblTransactionIDEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblTransactionIDEdit.Location = new System.Drawing.Point(82, 169);
            this.lblTransactionIDEdit.Name = "lblTransactionIDEdit";
            this.lblTransactionIDEdit.Size = new System.Drawing.Size(111, 18);
            this.lblTransactionIDEdit.TabIndex = 86;
            this.lblTransactionIDEdit.Text = "Transaction ID:";
            // 
            // cbxSalesIDEdit
            // 
            this.cbxSalesIDEdit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxSalesIDEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxSalesIDEdit.FormattingEnabled = true;
            this.cbxSalesIDEdit.Location = new System.Drawing.Point(606, 42);
            this.cbxSalesIDEdit.MaxDropDownItems = 100;
            this.cbxSalesIDEdit.Name = "cbxSalesIDEdit";
            this.cbxSalesIDEdit.Size = new System.Drawing.Size(121, 26);
            this.cbxSalesIDEdit.TabIndex = 4;
            this.cbxSalesIDEdit.SelectedIndexChanged += new System.EventHandler(this.cbxSalesIDEdit_SelectedIndexChanged);
            // 
            // lblSalesIDEdit
            // 
            this.lblSalesIDEdit.AutoSize = true;
            this.lblSalesIDEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblSalesIDEdit.Location = new System.Drawing.Point(570, 47);
            this.lblSalesIDEdit.Name = "lblSalesIDEdit";
            this.lblSalesIDEdit.Size = new System.Drawing.Size(27, 18);
            this.lblSalesIDEdit.TabIndex = 84;
            this.lblSalesIDEdit.Text = "ID:";
            // 
            // cbxTransactionEdit
            // 
            this.cbxTransactionEdit.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbxTransactionEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.cbxTransactionEdit.FormattingEnabled = true;
            this.cbxTransactionEdit.Location = new System.Drawing.Point(313, 42);
            this.cbxTransactionEdit.MaxDropDownItems = 100;
            this.cbxTransactionEdit.Name = "cbxTransactionEdit";
            this.cbxTransactionEdit.Size = new System.Drawing.Size(251, 26);
            this.cbxTransactionEdit.TabIndex = 3;
            this.cbxTransactionEdit.SelectedIndexChanged += new System.EventHandler(this.cbxTransactionEdit_SelectedIndexChanged);
            // 
            // lblPleaseSelectTransactionEdit
            // 
            this.lblPleaseSelectTransactionEdit.Font = new System.Drawing.Font("Arial", 12F);
            this.lblPleaseSelectTransactionEdit.Location = new System.Drawing.Point(52, 47);
            this.lblPleaseSelectTransactionEdit.Name = "lblPleaseSelectTransactionEdit";
            this.lblPleaseSelectTransactionEdit.Size = new System.Drawing.Size(253, 20);
            this.lblPleaseSelectTransactionEdit.TabIndex = 79;
            this.lblPleaseSelectTransactionEdit.Text = "Please select a transaction to edit:";
            this.lblPleaseSelectTransactionEdit.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblSalesInformation
            // 
            this.lblSalesInformation.BackColor = System.Drawing.Color.Teal;
            this.lblSalesInformation.Font = new System.Drawing.Font("Arial", 14.25F);
            this.lblSalesInformation.ForeColor = System.Drawing.Color.White;
            this.lblSalesInformation.Location = new System.Drawing.Point(6, 473);
            this.lblSalesInformation.Name = "lblSalesInformation";
            this.lblSalesInformation.Size = new System.Drawing.Size(180, 38);
            this.lblSalesInformation.TabIndex = 50;
            this.lblSalesInformation.Text = "Sales Information:";
            this.lblSalesInformation.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnViewTransactions
            // 
            this.btnViewTransactions.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnViewTransactions.BackgroundImage")));
            this.btnViewTransactions.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnViewTransactions.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnViewTransactions.Font = new System.Drawing.Font("Arial", 12F);
            this.btnViewTransactions.Location = new System.Drawing.Point(6, 514);
            this.btnViewTransactions.Name = "btnViewTransactions";
            this.btnViewTransactions.Size = new System.Drawing.Size(180, 34);
            this.btnViewTransactions.TabIndex = 7;
            this.btnViewTransactions.Text = "View Transactions";
            this.btnViewTransactions.UseVisualStyleBackColor = true;
            this.btnViewTransactions.Click += new System.EventHandler(this.btnViewTransactions_Click);
            // 
            // btnMakeTransaction
            // 
            this.btnMakeTransaction.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnMakeTransaction.BackgroundImage")));
            this.btnMakeTransaction.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMakeTransaction.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnMakeTransaction.Font = new System.Drawing.Font("Arial", 12F);
            this.btnMakeTransaction.Location = new System.Drawing.Point(6, 554);
            this.btnMakeTransaction.Name = "btnMakeTransaction";
            this.btnMakeTransaction.Size = new System.Drawing.Size(180, 34);
            this.btnMakeTransaction.TabIndex = 8;
            this.btnMakeTransaction.Text = "Make Transaction";
            this.btnMakeTransaction.UseVisualStyleBackColor = true;
            this.btnMakeTransaction.Click += new System.EventHandler(this.btnMakeTransaction_Click);
            // 
            // btnUpdateTransaction
            // 
            this.btnUpdateTransaction.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnUpdateTransaction.BackgroundImage")));
            this.btnUpdateTransaction.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnUpdateTransaction.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnUpdateTransaction.Font = new System.Drawing.Font("Arial", 12F);
            this.btnUpdateTransaction.Location = new System.Drawing.Point(6, 593);
            this.btnUpdateTransaction.Name = "btnUpdateTransaction";
            this.btnUpdateTransaction.Size = new System.Drawing.Size(180, 34);
            this.btnUpdateTransaction.TabIndex = 9;
            this.btnUpdateTransaction.Text = "Edit Transaction";
            this.btnUpdateTransaction.UseVisualStyleBackColor = true;
            this.btnUpdateTransaction.Click += new System.EventHandler(this.btnUpdateTransaction_Click);
            // 
            // btnReportFullScreen
            // 
            this.btnReportFullScreen.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnReportFullScreen.BackgroundImage")));
            this.btnReportFullScreen.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnReportFullScreen.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReportFullScreen.Font = new System.Drawing.Font("Arial", 12F);
            this.btnReportFullScreen.Location = new System.Drawing.Point(814, 757);
            this.btnReportFullScreen.Name = "btnReportFullScreen";
            this.btnReportFullScreen.Size = new System.Drawing.Size(180, 34);
            this.btnReportFullScreen.TabIndex = 4;
            this.btnReportFullScreen.Text = "Full Screen";
            this.btnReportFullScreen.UseVisualStyleBackColor = true;
            this.btnReportFullScreen.Click += new System.EventHandler(this.btnReportFullScreen_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(1008, 800);
            this.Controls.Add(this.btnInventoryReport);
            this.Controls.Add(this.btnSalesReport);
            this.Controls.Add(this.btnCustomerReport);
            this.Controls.Add(this.btnReportFullScreen);
            this.Controls.Add(this.pnlSales);
            this.Controls.Add(this.pnlReports);
            this.Controls.Add(this.pnlViewStuff);
            this.Controls.Add(this.pnlCustomer);
            this.Controls.Add(this.btnInventory);
            this.Controls.Add(this.btnUpdateTransaction);
            this.Controls.Add(this.btnMakeTransaction);
            this.Controls.Add(this.lblSalesInformation);
            this.Controls.Add(this.btnViewTransactions);
            this.Controls.Add(this.btnViewCustomer);
            this.Controls.Add(this.btnUpdateCustomer);
            this.Controls.Add(this.btnAddCustomer);
            this.Controls.Add(this.lblEditCustomerInformation);
            this.Controls.Add(this.btnProductsEdit);
            this.Controls.Add(this.btnSuppliesEdit);
            this.Controls.Add(this.btnMaterialsEdit);
            this.Controls.Add(this.lblAddUpdateInventory);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblShowOneTable);
            this.Controls.Add(this.btnViewProducts);
            this.Controls.Add(this.btnViewSupplies);
            this.Controls.Add(this.btnViewMaterials);
            this.Controls.Add(this.btnHelp);
            this.Controls.Add(this.lblNavigation);
            this.Controls.Add(this.pbxLogo);
            this.Controls.Add(this.lblMaterialsAndGeneralLabel);
            this.Controls.Add(this.btnCustomers);
            this.Controls.Add(this.btnSales);
            this.Controls.Add(this.btnReports);
            this.Controls.Add(this.btnMain);
            this.Controls.Add(this.lblTitle);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Main";
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxLogo)).EndInit();
            this.pnlReports.ResumeLayout(false);
            this.pnlViewStuff.ResumeLayout(false);
            this.pnlCustomer.ResumeLayout(false);
            this.pnlViewCustomer.ResumeLayout(false);
            this.pnlAddUpdateCustomer.ResumeLayout(false);
            this.pnlAddUpdateCustomer.PerformLayout();
            this.pnlSales.ResumeLayout(false);
            this.pnlViewSales.ResumeLayout(false);
            this.pnlViewSales.PerformLayout();
            this.pnlMakeUpdateTransaction.ResumeLayout(false);
            this.pnlMakeUpdateTransaction.PerformLayout();
            this.pnlAmountSold.ResumeLayout(false);
            this.pnlAmountSold.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtAmountSoldEdit)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Button btnMain;
        private System.Windows.Forms.Button btnReports;
        private System.Windows.Forms.Button btnSales;
        private System.Windows.Forms.Button btnCustomers;
        private System.Windows.Forms.Label lblMaterialsAndGeneralLabel;
        private System.Windows.Forms.PictureBox pbxLogo;
        private System.Windows.Forms.Label lblNavigation;
        private System.Windows.Forms.Button btnHelp;
        private System.Windows.Forms.Label lblShowOneTable;
        private System.Windows.Forms.Button btnViewProducts;
        private System.Windows.Forms.Button btnViewSupplies;
        private System.Windows.Forms.Button btnViewMaterials;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label lblAddUpdateInventory;
        private System.Windows.Forms.Button btnMaterialsEdit;
        private System.Windows.Forms.Button btnSuppliesEdit;
        private System.Windows.Forms.Button btnProductsEdit;
        private System.Windows.Forms.Button btnViewCustomer;
        private System.Windows.Forms.Button btnUpdateCustomer;
        private System.Windows.Forms.Button btnAddCustomer;
        private System.Windows.Forms.Label lblEditCustomerInformation;
        private System.Windows.Forms.Button btnCustomerReport;
        private System.Windows.Forms.Button btnInventoryReport;
        private System.Windows.Forms.Button btnSalesReport;
        private System.Windows.Forms.Button btnInventory;
        private System.Windows.Forms.Panel pnlReports;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crvReport;
        private System.Windows.Forms.Panel pnlViewStuff;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crvViewInventory;
        private System.Windows.Forms.Panel pnlCustomer;
        private System.Windows.Forms.Panel pnlAddUpdateCustomer;
        private System.Windows.Forms.Panel pnlViewCustomer;
        private System.Windows.Forms.TextBox txtCustomerItemsPurchased;
        private System.Windows.Forms.TextBox txtCustomerPhone;
        private System.Windows.Forms.TextBox txtCustomerAddress;
        private System.Windows.Forms.TextBox txtCustomerEmail;
        private System.Windows.Forms.TextBox txtCustomerID;
        private System.Windows.Forms.Label lblCustomerItemsPurchased;
        private System.Windows.Forms.Label lblCustomerBirthday;
        private System.Windows.Forms.Label lblCustomerPhone;
        private System.Windows.Forms.Label lblCustomerAddress;
        private System.Windows.Forms.Label lblCustomerEmail;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.ComboBox cbxCustomers;
        private System.Windows.Forms.Label lblSelectACustomerName;
        private System.Windows.Forms.Button btnCustomerSaveAdd;
        private CrystalDecisions.Windows.Forms.CrystalReportViewer crvViewCustomers;
        private System.Windows.Forms.DateTimePicker dtCustomerBirthday;
        private System.Windows.Forms.Label lblSelectCustomerID;
        private System.Windows.Forms.TextBox txtCustomerName;
        private System.Windows.Forms.ComboBox cbxCustomerID;
        private System.Windows.Forms.Panel pnlSales;
        private System.Windows.Forms.Label lblSalesInformation;
        private System.Windows.Forms.Button btnViewTransactions;
        private System.Windows.Forms.Button btnMakeTransaction;
        private System.Windows.Forms.Panel pnlViewSales;
        private System.Windows.Forms.TextBox txtProductNotes;
        private System.Windows.Forms.Label lblProductMaterialsUsed;
        private System.Windows.Forms.ListBox lbxProductMaterialsUsed;
        private System.Windows.Forms.TextBox txtProductRunningTotal;
        private System.Windows.Forms.TextBox txtProductCostToMake;
        private System.Windows.Forms.TextBox txtProductSellPrice;
        private System.Windows.Forms.TextBox txtProductDimentions;
        private System.Windows.Forms.TextBox txtProductOnHand;
        private System.Windows.Forms.TextBox txtProductType;
        private System.Windows.Forms.TextBox txtProductColor;
        private System.Windows.Forms.TextBox txtProductDescription;
        private System.Windows.Forms.TextBox txtProductID;
        private System.Windows.Forms.Label lblProductNotes;
        private System.Windows.Forms.Label lblProductRunningTotal;
        private System.Windows.Forms.CheckBox chkProductActive;
        private System.Windows.Forms.CheckBox chkProductCustom;
        private System.Windows.Forms.Label lblProductCostToMake;
        private System.Windows.Forms.Label lblProductType;
        private System.Windows.Forms.Label lblProductColor;
        private System.Windows.Forms.Label lblProductSellPrice;
        private System.Windows.Forms.Label lblProductDimentions;
        private System.Windows.Forms.Label lblProductOnHand;
        private System.Windows.Forms.Label lblProductDescription;
        private System.Windows.Forms.Label lblProductID;
        private System.Windows.Forms.TextBox txtProductName;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Label lblProductInformation;
        private System.Windows.Forms.Label lblPleaseSelectTransactionView;
        private System.Windows.Forms.TextBox txtSalesCustomerTotalItemsPurchased;
        private System.Windows.Forms.Label lblSalesCustomerTotalItemsPurchased;
        private System.Windows.Forms.TextBox txtSalesCustomerName;
        private System.Windows.Forms.Label lblSalesCustomerName;
        private System.Windows.Forms.Label lblCustomerInfo;
        private System.Windows.Forms.Label lblSalesInfo;
        private System.Windows.Forms.Label lblDateSold;
        private System.Windows.Forms.TextBox txtAmountSold;
        private System.Windows.Forms.Label lblAmoutSold;
        private System.Windows.Forms.TextBox txtStore;
        private System.Windows.Forms.Label lblStore;
        private System.Windows.Forms.ComboBox cbxTransactionView;
        private System.Windows.Forms.RadioButton rdoSortByDateSoldView;
        private System.Windows.Forms.TextBox txtDateSold;
        private System.Windows.Forms.RadioButton rdoSortByCustomerView;
        private System.Windows.Forms.Panel pnlMakeUpdateTransaction;
        private System.Windows.Forms.ComboBox cbxSalesIDView;
        private System.Windows.Forms.Label lblSalesIDView;
        private System.Windows.Forms.TextBox txtMarkupPercentage;
        private System.Windows.Forms.Label lblMarkupPercentage;
        private System.Windows.Forms.TextBox txtTotalProfit;
        private System.Windows.Forms.Label lblTotalProfit;
        private System.Windows.Forms.Label lblTotalProfitAfterMessage;
        private System.Windows.Forms.Button btnUpdateTransaction;
        private System.Windows.Forms.ComboBox cbxSalesIDEdit;
        private System.Windows.Forms.Label lblSalesIDEdit;
        private System.Windows.Forms.ComboBox cbxTransactionEdit;
        private System.Windows.Forms.Label lblPleaseSelectTransactionEdit;
        private System.Windows.Forms.Label lblDateSoldEdit;
        private System.Windows.Forms.Label lblTransactionIDEdit;
        private System.Windows.Forms.Label lblMarkupPercentageEdit;
        private System.Windows.Forms.Label lblProductsEdit;
        private System.Windows.Forms.Label lblStoreEdit;
        private System.Windows.Forms.Label lblPleaseEnterAmountSold;
        private System.Windows.Forms.Label lblTotalProfitEdit;
        private System.Windows.Forms.TextBox txtTotalProfitEdit;
        private System.Windows.Forms.TextBox txtMarkupPercentageEdit;
        private System.Windows.Forms.TextBox txtStoreEdit;
        private System.Windows.Forms.NumericUpDown txtAmountSoldEdit;
        private System.Windows.Forms.TextBox txtTransactionIDEdit;
        private System.Windows.Forms.Label lblAmountSoldEdit;
        private System.Windows.Forms.Label lblProductsSoldEdit;
        private System.Windows.Forms.ListBox lbxProductsSoldEdit;
        private System.Windows.Forms.ListBox lbxProductsEdit;
        private System.Windows.Forms.Button btnSubtractProduct;
        private System.Windows.Forms.Button btnAddProduct;
        private System.Windows.Forms.RadioButton rdoSortByTransactionDateEdit;
        private System.Windows.Forms.RadioButton rdoSortByCustomerEdit;
        private System.Windows.Forms.ComboBox cbxProductsView;
        private System.Windows.Forms.Label lblProductsSold;
        private System.Windows.Forms.Panel pnlAmountSold;
        private System.Windows.Forms.TextBox txtSellPriceEdit;
        private System.Windows.Forms.Label lblSellPriceEdit;
        private System.Windows.Forms.TextBox txtProfitEdit;
        private System.Windows.Forms.Label lblProfitEdit;
        private System.Windows.Forms.Button btnUpdateMarkup;
        private System.Windows.Forms.Button btnUpdateAddSales;
        private System.Windows.Forms.Label lblProductIDSales;
        private System.Windows.Forms.ListBox lbxProductIDEdit;
        private System.Windows.Forms.ComboBox cbxCustomerIDEdit;
        private System.Windows.Forms.Label lblCustomerIDEdit;
        private System.Windows.Forms.ComboBox cbxCustomerEdit;
        private System.Windows.Forms.Label lblPleaseSelectACustomer;
        private System.Windows.Forms.DateTimePicker dtDateSoldEdit;
        private System.Windows.Forms.Label lblProductsSoldID;
        private System.Windows.Forms.Button btnEditAmountSold;
        private System.Windows.Forms.TextBox txtAmountSoldEdit2;
        private System.Windows.Forms.Button btnAmountSoldComfirmation;
        private System.Windows.Forms.TextBox txtProfitFromProduct;
        private System.Windows.Forms.Label lblProfitFromProduct;
        private System.Windows.Forms.ComboBox cbxSoldProductID;
        private System.Windows.Forms.Label lblPleaseSelectTransactionID;
        private System.Windows.Forms.TextBox txtNumberOfProductSold;
        private System.Windows.Forms.Label lblNumberOfProductSold;
        private System.Windows.Forms.ComboBox cbxSoldProductIDEdit;
        private System.Windows.Forms.Label lblPleaseSelectATransactionID;
        private System.Windows.Forms.TextBox txtProductsSoldIDEdit;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnReportFullScreen;
    }
}

