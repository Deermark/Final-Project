﻿namespace EllisonM_FinalProject
{
    partial class frmHelp
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmHelp));
            this.pnlHelp = new System.Windows.Forms.Panel();
            this.lblAbout = new System.Windows.Forms.Label();
            this.txtSales = new System.Windows.Forms.TextBox();
            this.txtCustomer = new System.Windows.Forms.TextBox();
            this.txtInventory = new System.Windows.Forms.TextBox();
            this.txtReport = new System.Windows.Forms.TextBox();
            this.pnlPreferences = new System.Windows.Forms.Panel();
            this.rdoNo = new System.Windows.Forms.RadioButton();
            this.rdoYes = new System.Windows.Forms.RadioButton();
            this.lblDisableExitMessage = new System.Windows.Forms.Label();
            this.lblTitle = new System.Windows.Forms.Label();
            this.pnlMenu = new System.Windows.Forms.Panel();
            this.btnClose = new System.Windows.Forms.Button();
            this.btnAbout = new System.Windows.Forms.Button();
            this.btnSales = new System.Windows.Forms.Button();
            this.btnReport = new System.Windows.Forms.Button();
            this.btnCustomer = new System.Windows.Forms.Button();
            this.lblOther = new System.Windows.Forms.Label();
            this.lblHelp = new System.Windows.Forms.Label();
            this.btnPreferences = new System.Windows.Forms.Button();
            this.btnInventory = new System.Windows.Forms.Button();
            this.pnlHelp.SuspendLayout();
            this.pnlPreferences.SuspendLayout();
            this.pnlMenu.SuspendLayout();
            this.SuspendLayout();
            // 
            // pnlHelp
            // 
            this.pnlHelp.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlHelp.Controls.Add(this.lblAbout);
            this.pnlHelp.Controls.Add(this.txtSales);
            this.pnlHelp.Controls.Add(this.txtCustomer);
            this.pnlHelp.Controls.Add(this.txtInventory);
            this.pnlHelp.Controls.Add(this.txtReport);
            this.pnlHelp.Controls.Add(this.pnlPreferences);
            this.pnlHelp.Location = new System.Drawing.Point(12, 65);
            this.pnlHelp.Name = "pnlHelp";
            this.pnlHelp.Size = new System.Drawing.Size(488, 413);
            this.pnlHelp.TabIndex = 1;
            // 
            // lblAbout
            // 
            this.lblAbout.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAbout.Location = new System.Drawing.Point(0, 0);
            this.lblAbout.Name = "lblAbout";
            this.lblAbout.Size = new System.Drawing.Size(486, 409);
            this.lblAbout.TabIndex = 4;
            this.lblAbout.Text = resources.GetString("lblAbout.Text");
            this.lblAbout.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtSales
            // 
            this.txtSales.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtSales.Location = new System.Drawing.Point(0, 0);
            this.txtSales.Multiline = true;
            this.txtSales.Name = "txtSales";
            this.txtSales.ReadOnly = true;
            this.txtSales.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtSales.Size = new System.Drawing.Size(486, 409);
            this.txtSales.TabIndex = 6;
            this.txtSales.TabStop = false;
            this.txtSales.Text = resources.GetString("txtSales.Text");
            this.txtSales.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtCustomer
            // 
            this.txtCustomer.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtCustomer.Location = new System.Drawing.Point(0, 0);
            this.txtCustomer.Multiline = true;
            this.txtCustomer.Name = "txtCustomer";
            this.txtCustomer.ReadOnly = true;
            this.txtCustomer.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtCustomer.Size = new System.Drawing.Size(486, 409);
            this.txtCustomer.TabIndex = 8;
            this.txtCustomer.TabStop = false;
            this.txtCustomer.Text = resources.GetString("txtCustomer.Text");
            this.txtCustomer.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtInventory
            // 
            this.txtInventory.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtInventory.Location = new System.Drawing.Point(0, 0);
            this.txtInventory.Multiline = true;
            this.txtInventory.Name = "txtInventory";
            this.txtInventory.ReadOnly = true;
            this.txtInventory.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtInventory.Size = new System.Drawing.Size(486, 409);
            this.txtInventory.TabIndex = 3;
            this.txtInventory.TabStop = false;
            this.txtInventory.Text = resources.GetString("txtInventory.Text");
            this.txtInventory.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txtReport
            // 
            this.txtReport.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.txtReport.Location = new System.Drawing.Point(0, 0);
            this.txtReport.Multiline = true;
            this.txtReport.Name = "txtReport";
            this.txtReport.ReadOnly = true;
            this.txtReport.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtReport.Size = new System.Drawing.Size(486, 409);
            this.txtReport.TabIndex = 7;
            this.txtReport.TabStop = false;
            this.txtReport.Text = resources.GetString("txtReport.Text");
            this.txtReport.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pnlPreferences
            // 
            this.pnlPreferences.Controls.Add(this.rdoNo);
            this.pnlPreferences.Controls.Add(this.rdoYes);
            this.pnlPreferences.Controls.Add(this.lblDisableExitMessage);
            this.pnlPreferences.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.pnlPreferences.Location = new System.Drawing.Point(0, 0);
            this.pnlPreferences.Name = "pnlPreferences";
            this.pnlPreferences.Size = new System.Drawing.Size(486, 409);
            this.pnlPreferences.TabIndex = 5;
            // 
            // rdoNo
            // 
            this.rdoNo.AutoSize = true;
            this.rdoNo.Location = new System.Drawing.Point(361, 25);
            this.rdoNo.Name = "rdoNo";
            this.rdoNo.Size = new System.Drawing.Size(47, 24);
            this.rdoNo.TabIndex = 2;
            this.rdoNo.TabStop = true;
            this.rdoNo.Text = "No";
            this.rdoNo.UseVisualStyleBackColor = true;
            // 
            // rdoYes
            // 
            this.rdoYes.AutoSize = true;
            this.rdoYes.Location = new System.Drawing.Point(300, 25);
            this.rdoYes.Name = "rdoYes";
            this.rdoYes.Size = new System.Drawing.Size(55, 24);
            this.rdoYes.TabIndex = 1;
            this.rdoYes.TabStop = true;
            this.rdoYes.Text = "Yes";
            this.rdoYes.UseVisualStyleBackColor = true;
            // 
            // lblDisableExitMessage
            // 
            this.lblDisableExitMessage.AutoSize = true;
            this.lblDisableExitMessage.Location = new System.Drawing.Point(35, 25);
            this.lblDisableExitMessage.Name = "lblDisableExitMessage";
            this.lblDisableExitMessage.Size = new System.Drawing.Size(259, 20);
            this.lblDisableExitMessage.TabIndex = 0;
            this.lblDisableExitMessage.Text = "Disable exit confirmation message?";
            // 
            // lblTitle
            // 
            this.lblTitle.BackColor = System.Drawing.Color.Teal;
            this.lblTitle.Font = new System.Drawing.Font("Arial", 24F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Location = new System.Drawing.Point(12, 12);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(488, 50);
            this.lblTitle.TabIndex = 1;
            this.lblTitle.Text = "This is a title";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pnlMenu
            // 
            this.pnlMenu.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlMenu.Controls.Add(this.btnClose);
            this.pnlMenu.Controls.Add(this.btnAbout);
            this.pnlMenu.Controls.Add(this.btnSales);
            this.pnlMenu.Controls.Add(this.btnReport);
            this.pnlMenu.Controls.Add(this.btnCustomer);
            this.pnlMenu.Controls.Add(this.lblOther);
            this.pnlMenu.Controls.Add(this.lblHelp);
            this.pnlMenu.Controls.Add(this.btnPreferences);
            this.pnlMenu.Controls.Add(this.btnInventory);
            this.pnlMenu.Location = new System.Drawing.Point(506, 12);
            this.pnlMenu.Name = "pnlMenu";
            this.pnlMenu.Size = new System.Drawing.Size(208, 466);
            this.pnlMenu.TabIndex = 2;
            // 
            // btnClose
            // 
            this.btnClose.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnClose.BackgroundImage")));
            this.btnClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnClose.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.Location = new System.Drawing.Point(5, 418);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(194, 41);
            this.btnClose.TabIndex = 7;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // btnAbout
            // 
            this.btnAbout.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnAbout.BackgroundImage")));
            this.btnAbout.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnAbout.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnAbout.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAbout.Location = new System.Drawing.Point(5, 327);
            this.btnAbout.Name = "btnAbout";
            this.btnAbout.Size = new System.Drawing.Size(194, 41);
            this.btnAbout.TabIndex = 6;
            this.btnAbout.Text = "About";
            this.btnAbout.UseVisualStyleBackColor = true;
            this.btnAbout.Click += new System.EventHandler(this.btnAbout_Click);
            // 
            // btnSales
            // 
            this.btnSales.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnSales.BackgroundImage")));
            this.btnSales.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnSales.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSales.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSales.Location = new System.Drawing.Point(5, 194);
            this.btnSales.Name = "btnSales";
            this.btnSales.Size = new System.Drawing.Size(194, 41);
            this.btnSales.TabIndex = 4;
            this.btnSales.Text = "Sales";
            this.btnSales.UseVisualStyleBackColor = true;
            this.btnSales.Click += new System.EventHandler(this.btnSales_Click);
            // 
            // btnReport
            // 
            this.btnReport.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnReport.BackgroundImage")));
            this.btnReport.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnReport.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnReport.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnReport.Location = new System.Drawing.Point(5, 147);
            this.btnReport.Name = "btnReport";
            this.btnReport.Size = new System.Drawing.Size(194, 41);
            this.btnReport.TabIndex = 3;
            this.btnReport.Text = "Report";
            this.btnReport.UseVisualStyleBackColor = true;
            this.btnReport.Click += new System.EventHandler(this.btnReport_Click);
            // 
            // btnCustomer
            // 
            this.btnCustomer.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCustomer.BackgroundImage")));
            this.btnCustomer.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCustomer.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnCustomer.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCustomer.Location = new System.Drawing.Point(5, 100);
            this.btnCustomer.Name = "btnCustomer";
            this.btnCustomer.Size = new System.Drawing.Size(194, 41);
            this.btnCustomer.TabIndex = 2;
            this.btnCustomer.Text = "Customer";
            this.btnCustomer.UseVisualStyleBackColor = true;
            this.btnCustomer.Click += new System.EventHandler(this.btnCustomer_Click);
            // 
            // lblOther
            // 
            this.lblOther.BackColor = System.Drawing.Color.Teal;
            this.lblOther.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblOther.ForeColor = System.Drawing.Color.White;
            this.lblOther.Location = new System.Drawing.Point(5, 238);
            this.lblOther.Name = "lblOther";
            this.lblOther.Size = new System.Drawing.Size(194, 39);
            this.lblOther.TabIndex = 4;
            this.lblOther.Text = "Other:";
            this.lblOther.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblHelp
            // 
            this.lblHelp.BackColor = System.Drawing.Color.Teal;
            this.lblHelp.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblHelp.ForeColor = System.Drawing.Color.White;
            this.lblHelp.Location = new System.Drawing.Point(5, 9);
            this.lblHelp.Name = "lblHelp";
            this.lblHelp.Size = new System.Drawing.Size(194, 39);
            this.lblHelp.TabIndex = 3;
            this.lblHelp.Text = "Help:";
            this.lblHelp.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnPreferences
            // 
            this.btnPreferences.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnPreferences.BackgroundImage")));
            this.btnPreferences.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPreferences.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPreferences.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPreferences.Location = new System.Drawing.Point(5, 280);
            this.btnPreferences.Name = "btnPreferences";
            this.btnPreferences.Size = new System.Drawing.Size(194, 41);
            this.btnPreferences.TabIndex = 5;
            this.btnPreferences.Text = "Set Preferences";
            this.btnPreferences.UseVisualStyleBackColor = true;
            this.btnPreferences.Click += new System.EventHandler(this.btnPreferences_Click);
            // 
            // btnInventory
            // 
            this.btnInventory.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnInventory.BackgroundImage")));
            this.btnInventory.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnInventory.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnInventory.Font = new System.Drawing.Font("Arial", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnInventory.Location = new System.Drawing.Point(5, 53);
            this.btnInventory.Name = "btnInventory";
            this.btnInventory.Size = new System.Drawing.Size(194, 41);
            this.btnInventory.TabIndex = 1;
            this.btnInventory.Text = "Inventory";
            this.btnInventory.UseVisualStyleBackColor = true;
            this.btnInventory.Click += new System.EventHandler(this.btnInventory_Click);
            // 
            // frmHelp
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.PowderBlue;
            this.ClientSize = new System.Drawing.Size(726, 490);
            this.ControlBox = false;
            this.Controls.Add(this.pnlMenu);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.pnlHelp);
            this.Name = "frmHelp";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Help/Preferences";
            this.Load += new System.EventHandler(this.frmHelp_Load);
            this.pnlHelp.ResumeLayout(false);
            this.pnlHelp.PerformLayout();
            this.pnlPreferences.ResumeLayout(false);
            this.pnlPreferences.PerformLayout();
            this.pnlMenu.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel pnlHelp;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Panel pnlMenu;
        private System.Windows.Forms.Button btnAbout;
        private System.Windows.Forms.Button btnSales;
        private System.Windows.Forms.Button btnReport;
        private System.Windows.Forms.Button btnCustomer;
        private System.Windows.Forms.Label lblOther;
        private System.Windows.Forms.Label lblHelp;
        private System.Windows.Forms.Button btnPreferences;
        private System.Windows.Forms.Button btnInventory;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Panel pnlPreferences;
        private System.Windows.Forms.Label lblAbout;
        private System.Windows.Forms.Label lblDisableExitMessage;
        private System.Windows.Forms.RadioButton rdoNo;
        private System.Windows.Forms.RadioButton rdoYes;
        private System.Windows.Forms.TextBox txtCustomer;
        private System.Windows.Forms.TextBox txtReport;
        private System.Windows.Forms.TextBox txtInventory;
        private System.Windows.Forms.TextBox txtSales;
    }
}