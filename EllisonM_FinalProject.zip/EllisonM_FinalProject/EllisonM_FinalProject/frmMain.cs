﻿//Marshall Ellison fall 2017
//INEW-2332-10Y1
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EllisonM_FinalProject
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        //hides the close button on the control box
        private const int CP_NOCLOSE_BUTTON = 0x200;
        protected override CreateParams CreateParams
        {
            get
            {
                CreateParams myCp = base.CreateParams;
                myCp.ClassStyle = myCp.ClassStyle | CP_NOCLOSE_BUTTON;
                return myCp;
            }
        }

        private static string _objective = "";
        private static bool _dontMessage = false;
        private static string _report = "";

        public static string objective
        {
            get { return _objective; }
            set { _objective = value; }
        }

        public static bool dontMessage
        {
            get { return _dontMessage; }
            set { _dontMessage = value; }
        }

        public static string report
        {
            get { return _report; }
            set { _report = value; }
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            setup();
        }

        private bool cancelTransactionBool = false;//used for sales purposes

        //***************  Navigation  ***************
        #region Navigation

        private void setup()
        {
            //set up the visiblily on the form
            switch (frmStart.pageType)
            {
                case "inventory":
                    this.Text = "Inventory";//change the name of the form
                    lblTitle.Text = "Inventory Information";
                    //everything uses this
                    objective = "View";                    
                    lblMaterialsAndGeneralLabel.Visible = true;
                    lblMaterialsAndGeneralLabel.Text = "Materials";
                    //inventory uses these
                    lblAddUpdateInventory.Visible = true;
                    btnMaterialsEdit.Visible = true;
                    btnMaterialsEdit.Enabled = true;
                    btnProductsEdit.Visible = true;
                    btnProductsEdit.Enabled = true;
                    btnSuppliesEdit.Visible = true;
                    btnSuppliesEdit.Enabled = true;
                    lblShowOneTable.Visible = true;
                    btnViewMaterials.Visible = true;
                    btnViewMaterials.Enabled = true;
                    btnViewProducts.Visible = true;
                    btnViewProducts.Enabled = true;
                    btnViewSupplies.Visible = true;
                    btnViewSupplies.Enabled = true;
                    pnlViewStuff.Visible = true;
                    pnlViewStuff.Enabled = true;

                    try
                    {
                        ViewMaterials vm = new ViewMaterials();
                        vm.SetDatabaseLogon("", "");
                        crvViewInventory.ReportSource = vm;

                        //hide the weird tab that says main report
                        foreach (Control c1 in crvViewInventory.Controls)
                        {
                            if (c1 is CrystalDecisions.Windows.Forms.PageView)
                            {
                                CrystalDecisions.Windows.Forms.PageView pv = (CrystalDecisions.Windows.Forms.PageView)c1;
                                foreach (Control c2 in pv.Controls)
                                {
                                    if (c2 is TabControl)
                                    {
                                        TabControl tc = (TabControl)c2;
                                        tc.ItemSize = new Size(0, 1);
                                        tc.SizeMode = TabSizeMode.Fixed;
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Please update crystal reports to the correct version.");
                    }


                    //inventory does not use any of these
                    pnlReports.Visible = false;
                    pnlReports.Enabled = false;
                    btnCustomerReport.Visible = false;
                    btnCustomerReport.Enabled = false;
                    btnInventoryReport.Visible = false;
                    btnInventoryReport.Enabled = false;
                    btnSalesReport.Visible = false;
                    btnSalesReport.Enabled = false;
                    lblEditCustomerInformation.Visible = false;
                    btnAddCustomer.Visible = false;
                    btnAddCustomer.Enabled = false;
                    btnUpdateCustomer.Visible = false;
                    btnUpdateCustomer.Enabled = false;
                    btnViewCustomer.Visible = false;
                    btnViewCustomer.Enabled = false;
                    pnlCustomer.Visible = false;
                    pnlCustomer.Enabled = false;
                    pnlSales.Visible = false;
                    pnlSales.Enabled = false;
                    lblSalesInformation.Visible = false;
                    btnViewTransactions.Visible = false;
                    btnViewTransactions.Enabled = false;
                    btnMakeTransaction.Visible = false;
                    btnMakeTransaction.Enabled = false;
                    btnUpdateTransaction.Visible = false;
                    btnUpdateTransaction.Enabled = false;
                    btnReportFullScreen.Visible = false;
                    btnReportFullScreen.Enabled = false;
                    break;
                case "reports":
                    this.Text = "Reports";//change the name of the form
                    lblTitle.Text = "Reports";
                    //reports uses these
                    pnlReports.Visible = true;
                    pnlReports.Enabled = true;
                    btnCustomerReport.Visible = true;
                    btnCustomerReport.Enabled = true;
                    btnInventoryReport.Visible = true;
                    btnInventoryReport.Enabled = true;
                    btnSalesReport.Visible = true;
                    btnSalesReport.Enabled = true;
                    btnReportFullScreen.Visible = true;
                    btnReportFullScreen.Enabled = true;
                    //reports does not use any of these
                    lblAddUpdateInventory.Visible = false;
                    btnMaterialsEdit.Visible = false;
                    btnMaterialsEdit.Enabled = false;
                    btnProductsEdit.Visible = false;
                    btnProductsEdit.Enabled = false;
                    btnSuppliesEdit.Visible = false;
                    btnSuppliesEdit.Enabled = false;
                    lblShowOneTable.Visible = false;
                    btnViewMaterials.Visible = false;
                    btnViewMaterials.Enabled = false;
                    btnViewProducts.Visible = false;
                    btnViewProducts.Enabled = false;
                    btnViewSupplies.Visible = false;
                    btnViewSupplies.Enabled = false;
                    lblEditCustomerInformation.Visible = false;
                    btnAddCustomer.Visible = false;
                    btnAddCustomer.Enabled = false;
                    btnUpdateCustomer.Visible = false;
                    btnUpdateCustomer.Enabled = false;
                    btnViewCustomer.Visible = false;
                    btnViewCustomer.Enabled = false;
                    lblMaterialsAndGeneralLabel.Visible = false;
                    pnlViewStuff.Visible = false;
                    pnlViewStuff.Enabled = false;
                    pnlCustomer.Visible = false;
                    pnlCustomer.Enabled = false;
                    pnlSales.Visible = false;
                    pnlSales.Enabled = false;
                    lblSalesInformation.Visible = false;
                    btnViewTransactions.Visible = false;
                    btnViewTransactions.Enabled = false;
                    btnMakeTransaction.Visible = false;
                    btnMakeTransaction.Enabled = false;
                    btnUpdateTransaction.Visible = false;
                    btnUpdateTransaction.Enabled = false;
                    break;
                case "sales":
                    this.Text = "Sales";//change the name of the form
                    lblTitle.Text = "Sales Information";
                    //everything uses this
                    lblMaterialsAndGeneralLabel.Visible = true;
                    lblMaterialsAndGeneralLabel.Text = "View Transaction Information";
                    //sales uses these
                    pnlSales.Visible = true;
                    pnlSales.Enabled = true;
                    lblSalesInformation.Visible = true;
                    btnViewTransactions.Visible = true;
                    btnViewTransactions.Enabled = true;
                    btnMakeTransaction.Visible = true;
                    btnMakeTransaction.Enabled = true;
                    btnUpdateTransaction.Visible = true;
                    btnUpdateTransaction.Enabled = true;
                    //sales does not use any of these
                    pnlReports.Visible = false;
                    pnlReports.Enabled = false;
                    btnCustomerReport.Visible = false;
                    btnCustomerReport.Enabled = false;
                    btnInventoryReport.Visible = false;
                    btnInventoryReport.Enabled = false;
                    btnSalesReport.Visible = false;
                    btnSalesReport.Enabled = false;
                    lblAddUpdateInventory.Visible = false;
                    btnMaterialsEdit.Visible = false;
                    btnMaterialsEdit.Enabled = false;
                    btnProductsEdit.Visible = false;
                    btnProductsEdit.Enabled = false;
                    btnSuppliesEdit.Visible = false;
                    btnSuppliesEdit.Enabled = false;
                    lblShowOneTable.Visible = false;
                    btnViewMaterials.Visible = false;
                    btnViewMaterials.Enabled = false;
                    btnViewProducts.Visible = false;
                    btnViewProducts.Enabled = false;
                    btnViewSupplies.Visible = false;
                    btnViewSupplies.Enabled = false;
                    lblEditCustomerInformation.Visible = false;
                    btnAddCustomer.Visible = false;
                    btnAddCustomer.Enabled = false;
                    btnUpdateCustomer.Visible = false;
                    btnUpdateCustomer.Enabled = false;
                    btnViewCustomer.Visible = false;
                    btnViewCustomer.Enabled = false;
                    pnlViewStuff.Visible = false;
                    pnlViewStuff.Enabled = false;
                    btnReportFullScreen.Visible = false;
                    btnReportFullScreen.Enabled = false;
                    break;
                case "customers":
                    this.Text = "Customers";//change the name of the form
                    lblTitle.Text = "Customer Information";
                    lblMaterialsAndGeneralLabel.Text = "View Customer Information";
                    //everything uses this
                    lblMaterialsAndGeneralLabel.Visible = true;
                    //customers uses these
                    lblEditCustomerInformation.Visible = true;
                    btnAddCustomer.Visible = true;
                    btnAddCustomer.Enabled = true;
                    btnUpdateCustomer.Visible = true;
                    btnUpdateCustomer.Enabled = true;
                    btnViewCustomer.Visible = true;
                    btnViewCustomer.Enabled = true;
                    pnlCustomer.Visible = true;
                    pnlCustomer.Enabled = true;
                    pnlAddUpdateCustomer.Visible = false;
                    pnlAddUpdateCustomer.Enabled = false;
                    pnlViewCustomer.Visible = true;
                    pnlViewCustomer.Enabled = true;
                    try
                    {
                        ViewCustomers vc = new ViewCustomers();
                        vc.SetDatabaseLogon("", "");
                        crvViewCustomers.ReportSource = vc;

                        //hide the weird tab that says main report
                        foreach (Control c1 in crvViewCustomers.Controls)
                        {
                            if (c1 is CrystalDecisions.Windows.Forms.PageView)
                            {
                                CrystalDecisions.Windows.Forms.PageView pv = (CrystalDecisions.Windows.Forms.PageView)c1;
                                foreach (Control c2 in pv.Controls)
                                {
                                    if (c2 is TabControl)
                                    {
                                        TabControl tc = (TabControl)c2;
                                        tc.ItemSize = new Size(0, 1);
                                        tc.SizeMode = TabSizeMode.Fixed;
                                    }
                                }
                            }
                        }
                    }
                    catch (Exception)
                    {
                        MessageBox.Show("Please update crystal reports to the correct version.");
                    }
                    //customers does not use any of these
                    pnlReports.Visible = false;
                    pnlReports.Enabled = false;
                    btnCustomerReport.Visible = false;
                    btnCustomerReport.Enabled = false;
                    btnInventoryReport.Visible = false;
                    btnInventoryReport.Enabled = false;
                    btnSalesReport.Visible = false;
                    btnSalesReport.Enabled = false;
                    lblAddUpdateInventory.Visible = false;
                    btnMaterialsEdit.Visible = false;
                    btnMaterialsEdit.Enabled = false;
                    btnProductsEdit.Visible = false;
                    btnProductsEdit.Enabled = false;
                    btnSuppliesEdit.Visible = false;
                    btnSuppliesEdit.Enabled = false;
                    lblShowOneTable.Visible = false;
                    btnViewMaterials.Visible = false;
                    btnViewMaterials.Enabled = false;
                    btnViewProducts.Visible = false;
                    btnViewProducts.Enabled = false;
                    btnViewSupplies.Visible = false;
                    btnViewSupplies.Enabled = false;
                    pnlViewStuff.Visible = false;
                    pnlViewStuff.Enabled = false;
                    pnlSales.Visible = false;
                    pnlSales.Enabled = false;
                    lblSalesInformation.Visible = false;
                    btnViewTransactions.Visible = false;
                    btnViewTransactions.Enabled = false;
                    btnMakeTransaction.Visible = false;
                    btnMakeTransaction.Enabled = false;
                    btnUpdateTransaction.Visible = false;
                    btnUpdateTransaction.Enabled = false;
                    btnReportFullScreen.Visible = false;
                    btnReportFullScreen.Enabled = false;
                    break;
            }
        }

        private void btnMain_Click(object sender, EventArgs e)
        {
            if (cancelTransaction() == false)
                return;
            this.Close();
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            if (cancelTransaction() == false)
                return;
            frmStart.pageType = "reports";
            setup();
        }

        private void btnSales_Click(object sender, EventArgs e)
        {
            if (cancelTransaction() == false)
                return;
            frmStart.pageType = "sales";
            setup();
        }

        private void btnCustomers_Click(object sender, EventArgs e)
        {
            if (cancelTransaction() == false)
                return;
            frmStart.pageType = "customers";
            setup();
        }

        private void btnInventory_Click(object sender, EventArgs e)
        {
            if (cancelTransaction() == false)
                return;
            frmStart.pageType = "inventory";
            setup();
        }

        private void btnHelp_Click(object sender, EventArgs e)
        {
            frmStart.pageType = "help";
            frmHelp help = new frmHelp();
            help.ShowDialog();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            if (cancelTransaction() == false)
                return;
            if (dontMessage == false)
            {
                if (MessageBox.Show("Are you sure you want to exit the application?", "Confirmation", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    Application.Exit();
                }
            }
            else
                Application.Exit();
        }

        #endregion

        //**************   Inventory   **************
        #region Inventory
        private void btnMaterials_Click(object sender, EventArgs e)
        {
            objective = "View";
            pnlViewStuff.Visible = true;
            pnlViewStuff.Enabled = true;

            lblMaterialsAndGeneralLabel.Text = "Materials";

            try {
                ViewMaterials vm = new ViewMaterials();
                vm.SetDatabaseLogon("", "");
                crvViewInventory.ReportSource = vm;

                //hide the weird tab that says main report
                foreach (Control c1 in crvViewInventory.Controls)
                {
                    if (c1 is CrystalDecisions.Windows.Forms.PageView)
                    {
                        CrystalDecisions.Windows.Forms.PageView pv = (CrystalDecisions.Windows.Forms.PageView)c1;
                        foreach (Control c2 in pv.Controls)
                        {
                            if (c2 is TabControl)
                            {
                                TabControl tc = (TabControl)c2;
                                tc.ItemSize = new Size(0, 1);
                                tc.SizeMode = TabSizeMode.Fixed;
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Please update crystal reports to the correct version.");
            }
        }//view materials

        private void btnSupplies_Click(object sender, EventArgs e)
        {
            objective = "View";
            pnlViewStuff.Visible = true;
            pnlViewStuff.Enabled = true;

            lblMaterialsAndGeneralLabel.Text = "Supplies";

            try
            {
                ViewSupplies vs = new ViewSupplies();
                vs.SetDatabaseLogon("", "");
                crvViewInventory.ReportSource = vs;

                //hide the weird tab that says main report
                foreach (Control c1 in crvViewInventory.Controls)
                {
                    if (c1 is CrystalDecisions.Windows.Forms.PageView)
                    {
                        CrystalDecisions.Windows.Forms.PageView pv = (CrystalDecisions.Windows.Forms.PageView)c1;
                        foreach (Control c2 in pv.Controls)
                        {
                            if (c2 is TabControl)
                            {
                                TabControl tc = (TabControl)c2;
                                tc.ItemSize = new Size(0, 1);
                                tc.SizeMode = TabSizeMode.Fixed;
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Please update crystal reports to the correct version.");
            }
        }//view supplies

        private void btnProducts_Click(object sender, EventArgs e)
        {
            objective = "View";
            pnlViewStuff.Visible = true;
            pnlViewStuff.Enabled = true;

            lblMaterialsAndGeneralLabel.Text = "Products";

            try
            {
                ViewProducts vp = new ViewProducts();
                vp.SetDatabaseLogon("", "");
                crvViewInventory.ReportSource = vp;

                //hide the weird tab that says main report
                foreach (Control c1 in crvViewInventory.Controls)
                {
                    if (c1 is CrystalDecisions.Windows.Forms.PageView)
                    {
                        CrystalDecisions.Windows.Forms.PageView pv = (CrystalDecisions.Windows.Forms.PageView)c1;
                        foreach (Control c2 in pv.Controls)
                        {
                            if (c2 is TabControl)
                            {
                                TabControl tc = (TabControl)c2;
                                tc.ItemSize = new Size(0, 1);
                                tc.SizeMode = TabSizeMode.Fixed;
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Please update crystal reports to the correct version.");
            }
        }//view products

        private void btnMaterialsEdit_Click(object sender, EventArgs e)
        {
            objective = "edit materials";
            frmEditInventory edit = new frmEditInventory();
            edit.ShowDialog();

        }

        private void btnSuppliesEdit_Click(object sender, EventArgs e)
        {
            objective = "edit supplies";
            frmEditInventory edit = new frmEditInventory();
            edit.ShowDialog();

        }

        private void btnProductsEdit_Click(object sender, EventArgs e)
        {
            objective = "edit products";
            frmEditInventory edit = new frmEditInventory();
            edit.ShowDialog();

        }

        #endregion

        //**************   Customers   **************
        #region Customers

        private void btnAddCustomer_Click_1(object sender, EventArgs e)
        {
            lblMaterialsAndGeneralLabel.Text = "Add Customer";
            pnlAddUpdateCustomer.Visible = true;
            pnlAddUpdateCustomer.Enabled = true;
            pnlViewCustomer.Visible = false;
            pnlViewCustomer.Enabled = false;
            btnCustomerSaveAdd.Text = "Add";
            txtCustomerItemsPurchased.Text = "0";
            txtCustomerAddress.Clear();
            txtCustomerEmail.Clear();
            txtCustomerName.Clear();
            txtCustomerPhone.Clear();
            dtCustomerBirthday.Value = DateTime.Now;

            txtCustomerAddress.Enabled = true;
            txtCustomerEmail.Enabled = true;
            txtCustomerName.Enabled = true;
            txtCustomerPhone.Enabled = true;
            dtCustomerBirthday.Enabled = true;
            btnCustomerSaveAdd.Enabled = true;

            lblSelectACustomerName.Text = "Name:";
            cbxCustomers.Visible = false;
            cbxCustomers.Enabled = false;
            lblSelectCustomerID.Visible = false;
            cbxCustomerID.Visible = false;
            cbxCustomerID.Enabled = false;
            txtCustomerName.Visible = true;
            txtCustomerName.Enabled = true;
            DataOps.OleDbGetNextCustomerID();
            txtCustomerID.Text = DataOps.CustomerID;
        }
        private void btnUpdateCustomer_Click_1(object sender, EventArgs e)
        {
            lblMaterialsAndGeneralLabel.Text = "Update Information";
            pnlAddUpdateCustomer.Visible = true;
            pnlAddUpdateCustomer.Enabled = true;
            pnlViewCustomer.Visible = false;
            pnlViewCustomer.Enabled = false;
            btnCustomerSaveAdd.Text = "Save";
            cbxCustomers.Items.Clear();
            cbxCustomerID.Items.Clear();
            txtCustomerID.Text = "";
            txtCustomerItemsPurchased.Text = "";
            dtCustomerBirthday.Value = DateTime.Now;

            txtCustomerAddress.Enabled = false;
            txtCustomerEmail.Enabled = false;
            txtCustomerName.Enabled = false;
            txtCustomerPhone.Enabled = false;
            dtCustomerBirthday.Enabled = false;
            btnCustomerSaveAdd.Enabled = false;

            lblSelectACustomerName.Text = "Please select a customer to edit:";
            cbxCustomers.Visible = true;
            cbxCustomers.Enabled = true;
            lblSelectCustomerID.Visible = true;
            cbxCustomerID.Visible = true;
            cbxCustomerID.Enabled = true;
            txtCustomerName.Visible = false;
            txtCustomerName.Enabled = false;

            DataOps.OleDbSelectCustomerNames();
            List<string> customerNames = new List<string> { };//make a new list of customer names
            for (int i = 0; i < DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows.Count; i++)//loop for the amount of items in that list
                customerNames.Add(DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows[i][0].ToString());//add values to that list

            for (int i = 0; i < customerNames.Count; i++)//loop for the amount of items in the list
            {
                string currentCustomer = customerNames[i].ToLower();//make a variable to store the current name at position i
                if (i != customerNames.Count)//doesn't move on to the next part if i has reached the final position
                {
                    for (int j = i + 1; j < customerNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                    {
                        string comparedCustomer = customerNames[j].ToLower();//make a variable to store the current name at position j
                        if (currentCustomer == comparedCustomer)//checks if the customer at point i is the same as at point j
                            customerNames.RemoveAt(j);//removes the customer at point j if it is the same                     
                    }
                }
            }

            for (int i = 0; i < customerNames.Count; i++)//add names to combo box
                cbxCustomers.Items.Add(customerNames[i]);
            cbxCustomers.SelectedIndex = 0;
        }

        private void btnViewCustomer_Click_1(object sender, EventArgs e)
        {
            lblMaterialsAndGeneralLabel.Text = "View Customer Information";
            pnlAddUpdateCustomer.Visible = false;
            pnlAddUpdateCustomer.Enabled = false;
            pnlViewCustomer.Visible = true;
            pnlViewCustomer.Enabled = true;

            try
            {
                ViewCustomers vc = new ViewCustomers();
                vc.SetDatabaseLogon("", "");
                crvViewCustomers.ReportSource = vc;

                //hide the weird tab that says main report
                foreach (Control c1 in crvViewCustomers.Controls)
                {
                    if (c1 is CrystalDecisions.Windows.Forms.PageView)
                    {
                        CrystalDecisions.Windows.Forms.PageView pv = (CrystalDecisions.Windows.Forms.PageView)c1;
                        foreach (Control c2 in pv.Controls)
                        {
                            if (c2 is TabControl)
                            {
                                TabControl tc = (TabControl)c2;
                                tc.ItemSize = new Size(0, 1);
                                tc.SizeMode = TabSizeMode.Fixed;
                            }
                        }
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Please update crystal reports to the correct version.");
            }
        }

        private void cbxCustomers_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbxCustomerID.Items.Clear();
            DataOps.OleDbSelectCustomerIDs(cbxCustomers.SelectedItem.ToString());
            for (int i = 0; i < DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows.Count; i++)
                cbxCustomerID.Items.Add(DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows[i][0].ToString());

            txtCustomerAddress.Clear();
            txtCustomerEmail.Clear();
            txtCustomerID.Clear();
            txtCustomerItemsPurchased.Clear();
            txtCustomerName.Clear();
            txtCustomerPhone.Clear();

            txtCustomerAddress.Enabled = false;
            txtCustomerEmail.Enabled = false;
            txtCustomerName.Enabled = false;
            txtCustomerPhone.Enabled = false;
            dtCustomerBirthday.Enabled = false;
            btnCustomerSaveAdd.Enabled = false;
        }

        private void cbxCustomerID_SelectedIndexChanged(object sender, EventArgs e)
        {
            DataOps.OleDbSelectCustomerInfo(cbxCustomers.SelectedItem.ToString(), cbxCustomerID.SelectedItem.ToString());
            txtCustomerID.Text = DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows[0][1].ToString();
            txtCustomerEmail.Text = DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows[0][2].ToString();
            txtCustomerAddress.Text = DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows[0][3].ToString();
            txtCustomerPhone.Text = DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows[0][4].ToString();
            dtCustomerBirthday.Value = Convert.ToDateTime(DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows[0][5].ToString());
            txtCustomerItemsPurchased.Text = DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows[0][6].ToString();

            txtCustomerAddress.Enabled = true;
            txtCustomerEmail.Enabled = true;
            txtCustomerName.Enabled = true;
            txtCustomerPhone.Enabled = true;
            dtCustomerBirthday.Enabled = true;
            btnCustomerSaveAdd.Enabled = true;
        }

        private void btnCustomerSaveAdd_Click(object sender, EventArgs e)
        {
            if(btnCustomerSaveAdd.Text == "Add")
            {//validate for email, phone number
                if (txtCustomerName.Text != "")
                {
                    DataOps.OleDbInsertCustomer(txtCustomerID.Text, txtCustomerName.Text, txtCustomerEmail.Text, txtCustomerAddress.Text, txtCustomerPhone.Text, dtCustomerBirthday.Text, txtCustomerItemsPurchased.Text);
                    MessageBox.Show("The new customer was successfully added.");
                    txtCustomerItemsPurchased.Text = "0";
                    txtCustomerAddress.Clear();
                    txtCustomerEmail.Clear();
                    txtCustomerName.Clear();
                    txtCustomerPhone.Clear();
                    dtCustomerBirthday.Value = DateTime.Now;
                    DataOps.OleDbGetNextCustomerID();
                    txtCustomerID.Text = DataOps.CustomerID;
                }
                else
                {
                    MessageBox.Show("Please enter a name for this customer.");
                    txtCustomerName.Focus();
                }
            } else if(btnCustomerSaveAdd.Text == "Save")
            {
                if(cbxCustomerEdit.Text == "") {
                    DataOps.OleDbUpdateCustomer(txtCustomerID.Text, cbxCustomers.Text, txtCustomerEmail.Text, txtCustomerAddress.Text, txtCustomerPhone.Text, dtCustomerBirthday.Text, txtCustomerItemsPurchased.Text);
                    MessageBox.Show("The customer's information was successfully changed.");
                }
                else
                {
                    MessageBox.Show("Please enter a name for this customer.");
                    txtCustomerName.Focus();
                }
            }
        }

        #endregion

        //**************    Reports    **************
        #region Reports

        private void btnSalesReport_Click(object sender, EventArgs e)
        {
            btnSalesReport.Enabled = false;
            btnInventoryReport.Enabled = true;
            btnCustomerReport.Enabled = true;
            report = "sales";

            try
            {
                SalesReport sr = new SalesReport();
                sr.SetDatabaseLogon("", "");
                crvReport.ReportSource = sr;
            }
            catch (Exception)
            {
                MessageBox.Show("Please update crystal reports to the correct version.");
            }
        }

        private void btnInventoryReport_Click(object sender, EventArgs e)
        {
            btnSalesReport.Enabled = true;
            btnInventoryReport.Enabled = false;
            btnCustomerReport.Enabled = true;
            report = "inventory";

            try
            {
                InventoryReport iv = new InventoryReport();
                iv.SetDatabaseLogon("", "");
                crvReport.ReportSource = iv;
            }
            catch (Exception)
            {
                MessageBox.Show("Please update crystal reports to the correct version.");
            }
        }

        private void btnCustomerReport_Click(object sender, EventArgs e)
        {
            btnSalesReport.Enabled = true;
            btnInventoryReport.Enabled = true;
            btnCustomerReport.Enabled = false;
            report = "customer";

            try
            {
                CustomerReport cr = new CustomerReport();
                cr.SetDatabaseLogon("", "");
                crvReport.ReportSource = cr;
            }
            catch (Exception)
            {
                MessageBox.Show("Please update crystal reports to the correct version.");
            }
        }

        private void btnReportFullScreen_Click(object sender, EventArgs e)
        {
            frmReport report = new frmReport();
            report.ShowDialog();
        }

        #endregion

        //**************     Sales     **************
        #region Sales

        //load sales
        #region load sales
        private void btnViewTransactions_Click(object sender, EventArgs e)
        {
            if (cancelTransaction() == false)
                return;
            pnlViewSales.Visible = true;
            pnlViewSales.Enabled = true;
            pnlMakeUpdateTransaction.Visible = false;
            pnlMakeUpdateTransaction.Enabled = false;
            lblMaterialsAndGeneralLabel.Text = "View Transaction Information";
        }
        private void btnMakeTransaction_Click(object sender, EventArgs e)
        {
            if(cancelTransactionBool == true)
            {               
                if (cancelTransaction() == false)
                    return;
            }
            cancelTransactionBool = true;
            pnlViewSales.Visible = false;
            pnlViewSales.Enabled = false;
            pnlMakeUpdateTransaction.Visible = true;
            pnlMakeUpdateTransaction.Enabled = true;
            lblMaterialsAndGeneralLabel.Text = "Make Transaction";
            rdoSortByCustomerEdit.Visible = false;
            rdoSortByCustomerEdit.Enabled = false;
            rdoSortByTransactionDateEdit.Visible = false;
            rdoSortByTransactionDateEdit.Enabled = false;
            cbxTransactionEdit.Visible = false;
            cbxTransactionEdit.Enabled = false;
            cbxSalesIDEdit.Visible = false;
            cbxSalesIDEdit.Enabled = false;
            lblPleaseSelectTransactionEdit.Visible = false;
            lblSalesIDEdit.Visible = false;
            btnUpdateAddSales.Text = "Add";

            rdoSortByCustomerEdit.Checked = false;
            rdoSortByTransactionDateEdit.Checked = false;
            cbxSalesIDEdit.Items.Clear();
            cbxCustomerEdit.Items.Clear();
            cbxCustomerIDEdit.Items.Clear();
            cbxSoldProductIDEdit.Visible = false;
            cbxSoldProductIDEdit.Enabled = false;
            lblPleaseSelectATransactionID.Visible = false;
            txtStoreEdit.Clear();
            dtDateSoldEdit.Value = DateTime.Now;
            lbxProductsEdit.Items.Clear();
            lbxProductIDEdit.Items.Clear();
            lbxProductsSoldEdit.Items.Clear();
            txtProductsSoldIDEdit.Clear();
            txtAmountSoldEdit.Value = 0;
            txtAmountSoldEdit2.Clear();
            txtMarkupPercentageEdit.Clear();
            txtSellPriceEdit.Clear();
            txtProfitEdit.Clear();
            txtTotalProfitEdit.Clear();
            cbxTransactionEdit.Items.Clear();
            clearUpdateAdd();

            //fill out all the customer names

            DataOps.OleDbSelectCustomerNames();
            List<string> customerNames = new List<string> { };//make a new list of customer names
            for (int i = 0; i < DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows.Count; i++)//loop for the amount of items in that list
                customerNames.Add(DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows[i][0].ToString());//add values to that list

            for (int i = 0; i < customerNames.Count; i++)//loop for the amount of items in the list
            {
                string currentCustomer = customerNames[i].ToLower();//make a variable to store the current name at position i
                if (i != customerNames.Count)//doesn't move on to the next part if i has reached the final position
                {
                    for (int j = i + 1; j < customerNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                    {
                        string comparedCustomer = customerNames[j].ToLower();//make a variable to store the current name at position j
                        if (currentCustomer == comparedCustomer)//checks if the customer at point i is the same as at point j
                            customerNames.RemoveAt(j);//removes the customer at point j if it is the same                     
                    }
                }
            }

            for (int i = 0; i < customerNames.Count; i++)//add names to combo box
                cbxCustomerEdit.Items.Add(customerNames[i]);
            cbxCustomerEdit.SelectedIndex = 0;

            //fill out all the products

            DataOps.OleDbSelectEndProductNames();
            List<string> productNames = new List<string> { };//make a new list of product names
            for (int i = 0; i < DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows.Count; i++)//loop for the amount of items in that list
                productNames.Add(DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[i][0].ToString());//add values to that list

            for (int i = 0; i < productNames.Count; i++)//loop for the amount of items in the list
            {
                string currentProduct = productNames[i].ToLower();//make a variable to store the current name at position i
                if (i != productNames.Count)//doesn't move on to the next part if i has reached the final position
                {
                    for (int j = i + 1; j < productNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                    {
                        string comparedProduct = productNames[j].ToLower();//make a variable to store the current name at position j
                        if (currentProduct == comparedProduct)//checks if the product at point i is the same as at point j
                            productNames.RemoveAt(j);//removes the product at point j if it is the same                     
                    }
                }
            }

            for (int i = 0; i < productNames.Count; i++)//add names to combo box
                lbxProductsEdit.Items.Add(productNames[i]);
            lbxProductsEdit.SelectedIndex = 0;

            DataOps.OleDbGetNextSoldProductID();
            txtTransactionIDEdit.Text = DataOps.SoldProductID;
            //insert a new soldproduct: new transactionid, current date, no products sold, no store yet, no productids, no customer yet, its not ready for updates just yet
            DataOps.OleDbInsertSoldProduct(txtTransactionIDEdit.Text, dtDateSoldEdit.Value.ToString("MM/dd/yyyy"), "", "", "", "", false);
        }

        private void btnUpdateTransaction_Click(object sender, EventArgs e)
        {
            if (cancelTransaction() == false)
                return;
            pnlViewSales.Visible = false;
            pnlViewSales.Enabled = false;
            pnlMakeUpdateTransaction.Visible = true;
            pnlMakeUpdateTransaction.Enabled = true;
            lblMaterialsAndGeneralLabel.Text = "Edit Transaction Information";
            rdoSortByCustomerEdit.Visible = true;
            rdoSortByCustomerEdit.Enabled = true;
            rdoSortByTransactionDateEdit.Visible = true;
            rdoSortByTransactionDateEdit.Enabled = true;
            cbxTransactionEdit.Visible = true;
            cbxTransactionEdit.Enabled = true;
            cbxSalesIDEdit.Visible = true;
            cbxSalesIDEdit.Enabled = true;
            lblPleaseSelectTransactionEdit.Visible = true;
            lblSalesIDEdit.Visible = true;
            btnUpdateAddSales.Text = "Save";

            rdoSortByCustomerEdit.Checked = false;
            rdoSortByTransactionDateEdit.Checked = false;
            cbxSalesIDEdit.Items.Clear();
            cbxCustomerEdit.Items.Clear();
            cbxCustomerIDEdit.Items.Clear();
            cbxSoldProductIDEdit.Visible = false;
            cbxSoldProductIDEdit.Enabled = false;
            lblPleaseSelectATransactionID.Visible = false;
            clearUpdateAdd();
            cbxTransactionEdit.Items.Clear();

        }

        private bool cancelTransaction()
        {
            //deletes the current transaction in the event that the user clicks on something else.
            if (cancelTransactionBool == true)
            {
                if (MessageBox.Show("Are you sure you want to leave this transaction unfinished? All progress will be lost.", "Warning", MessageBoxButtons.YesNo) == DialogResult.Yes)
                {
                    DataOps.OleDbDeleteUnfinishedTransaction(txtTransactionIDEdit.Text);
                    cancelTransactionBool = false;
                    return true;//means the event proceeds
                }
                else
                    return false;//means the event needs to be exited        
            }
            return true;
        }

        #endregion

        //view transaction
        #region view transaction

        private string selectedItemcbxTransaction = "";
        private void cbxTransaction_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbxSalesIDView.Items.Clear();
            clearViewSales();
            cbxProductsView.Items.Clear();
            cbxSoldProductID.Items.Clear();
            lblPleaseSelectTransactionID.Visible = false;
            cbxSoldProductID.Visible = false;
            cbxSoldProductID.Enabled = false;
            if (selectedItemcbxTransaction != cbxTransactionView.SelectedItem.ToString())//if the newly selected item is the same as the one that is already selected, then dont do anything
            {
                selectedItemcbxTransaction = cbxTransactionView.SelectedItem.ToString();//take note of the newly selected item
                if (rdoSortByCustomerView.Checked == true)
                {
                    cbxSalesIDView.Items.Clear();
                    DataOps.OleDbSelectCustomerIDFromCustomersWhereName(cbxTransactionView.Text);
                    for (int i = 0; i < DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows.Count; i++)
                        cbxSalesIDView.Items.Add(DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows[i][0]);
                }
                else if (rdoSortByDateSoldView.Checked == true)
                {
                    cbxSalesIDView.Items.Clear();
                    DataOps.OleDbSelectSoldProductIDFromSoldProductWhereDateSold(cbxTransactionView.Text);
                    for (int i = 0; i < DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows.Count; i++)
                        cbxSalesIDView.Items.Add(DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows[i][0]);
                }

            }
        }
        private bool extraNeeded = false;
        private string oldCbxTransactionViewText = "";
        private void cbxSalesID_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbxSoldProductID.Items.Clear();
            cbxProductsView.Items.Clear();
            clearViewSales();
            if (rdoSortByCustomerView.Checked == true)
            {
                DataOps.OleDbSelectAllFromSoldProductWhereCustomerID(cbxSalesIDView.Text);
                if (DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows.Count == 0)
                {
                    MessageBox.Show("That Customer has not purchased anything yet.");
                    lblPleaseSelectTransactionID.Visible = false;
                    cbxSoldProductID.Visible = false;
                    cbxSoldProductID.Enabled = false;
                    oldCbxTransactionViewText = cbxTransactionView.SelectedItem.ToString();
                    return;
                }
                if (DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows.Count < 1)//sets extra needed to false if the customer has had no one or no transactions
                    extraNeeded = false;
                if (cbxTransactionView.SelectedItem.ToString().ToLower() != oldCbxTransactionViewText.ToLower())//sets extra needed to false if the customer before this one doesn't share the same name as the current one
                    extraNeeded = false;
                if (extraNeeded == false)
                {
                    txtDateSold.Text = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][1].ToString().Replace("12:00:00 AM", "");
                    txtStore.Text = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][3].ToString();

                    DataOps.OleDbSelectAllFromCustomersWhereCustomerID(DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][5].ToString());
                    txtSalesCustomerName.Text = DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows[0][1].ToString();
                    txtSalesCustomerTotalItemsPurchased.Text = DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows[0][6].ToString();

                    string[] TASTokens;
                    char[] TASDelim = { ',' };
                    TASTokens = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][2].ToString().Split(TASDelim);//tokenize the amount sold
                    double amountSold = 0;
                    for(int i = 0; i < TASTokens.Length - 1; i++)//add up all the numbers to find the total amount of items sold in this transaction
                        amountSold += double.Parse(TASTokens[i]);
                    txtAmountSold.Text = amountSold.ToString();

                    cbxProductsView.Items.Clear();
                    string[] tokens;
                    char[] delim = { ',' };
                    tokens = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString().Split(delim);//tokenize the endproductid
                    if (tokens.Length - 1 == 1)//if theres only one product sold
                    {
                        DataOps.OleDbSelectProductName(tokens[0]);//use the individual id to query a name
                        cbxProductsView.Items.Add(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//add that name to the products box
                    }
                    else if (tokens.Length - 1 > 1)
                    {
                        for (int i = 0; i < tokens.Length - 1; i++)
                        {
                            DataOps.OleDbSelectProductName(tokens[i]);//use the individual id to query a name
                            cbxProductsView.Items.Add(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//add that name to the products box
                        }
                    }
                    else { }//if theres no products sold, just don't do anything

                    //recalculate total profit()
                    if (cbxSoldProductID.Visible == true)
                        DataOps.OleDbSelectAllFromSoldProductWhereCustomerIDAndSoldProductID(cbxSalesIDView.Text, cbxSoldProductID.Text);
                    else
                    {
                        if (rdoSortByCustomerView.Checked == true)
                        {
                            DataOps.OleDbSelectSoldProductIDFromSoldProductWhereCustomerID(cbxSalesIDView.Text);
                            DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows[0][0].ToString());
                        }
                        else if (rdoSortByDateSoldView.Checked == true)
                        {
                            DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(cbxSalesIDView.Text);
                        }
                    }
                    string[] tokens4;
                    char[] delim4 = { ',' };
                    tokens4 = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString().Split(delim4);//tokenize product ids
                    string[] tokens5;
                    char[] delim5 = { ',' };
                    tokens5 = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][2].ToString().Split(delim5);//tokenize amount sold 

                    double totalAmountSold = 0;
                    double totalCost = 0;
                    double totalSellPrice = 0;
                    if (tokens4.Length == 1)
                    {
                        DataOps.OleDbSelectProductCostAndSellPrice(tokens4[0]);
                        totalCost = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString());
                        totalSellPrice = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString());
                    }
                    else
                    {
                        for (int i = 0; i < tokens4.Length - 1; i++)
                        {
                            DataOps.OleDbSelectProductCostAndSellPrice(tokens4[i]);
                            totalAmountSold = double.Parse(tokens5[i]);
                            totalCost += double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString()) * totalAmountSold;
                            totalSellPrice += double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString()) * totalAmountSold;
                        }
                    }
                    double totalGrossProfit = totalSellPrice - totalCost;
                    double totalGrossProfitAfterTax = totalGrossProfit - (totalGrossProfit * .0625);
                    double totalGrossProfitAfterTaxAndReduction = totalGrossProfitAfterTax - (totalGrossProfitAfterTax * .6);
                    txtTotalProfit.Text = "$" + (Math.Truncate(100 * totalGrossProfitAfterTaxAndReduction) / 100);
                }
                extraNeeded = false;
                DataOps.OleDbSelectAllFromSoldProductWhereCustomerID(cbxSalesIDView.Text);
                if (cbxTransactionView.SelectedItem.ToString().ToLower() == oldCbxTransactionViewText.ToLower())//checks to see if the user is preparing to view the same customer name but with a different id
                {
                    lblPleaseSelectTransactionID.Visible = true;
                    cbxSoldProductID.Visible = true;
                    cbxSoldProductID.Enabled = true;
                    extraNeeded = true;
                    DataOps.OleDbSelectSoldProductIDFromSoldProductWhereCustomerID(DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][5].ToString());
                    for (int i = 0; i < DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows.Count; i++)
                        cbxSoldProductID.Items.Add(DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows[i][0].ToString());
                    cbxSoldProductID.SelectedIndex = 0;
                    oldCbxTransactionViewText = cbxTransactionView.SelectedItem.ToString();
                    return;
                }                
                if (DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows.Count > 1)//checks if the customer had numerous transactions
                {
                    lblPleaseSelectTransactionID.Visible = true;
                    cbxSoldProductID.Visible = true;
                    cbxSoldProductID.Enabled = true;
                    extraNeeded = true;
                    DataOps.OleDbSelectSoldProductIDFromSoldProductWhereCustomerID(DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][5].ToString());
                    for (int i = 0; i < DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows.Count; i++)
                        cbxSoldProductID.Items.Add(DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows[i][0].ToString());
                    cbxSoldProductID.SelectedIndex = 0;
                    oldCbxTransactionViewText = cbxTransactionView.SelectedItem.ToString();
                    return;
                }
                oldCbxTransactionViewText = cbxTransactionView.SelectedItem.ToString();
            }
            else if (rdoSortByDateSoldView.Checked == true)
            {
                DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(cbxSalesIDView.Text);
                txtDateSold.Text = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][1].ToString().Replace("12:00:00 AM", "");
                txtStore.Text = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][3].ToString();

                DataOps.OleDbSelectAllFromCustomersWhereCustomerID(DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][5].ToString());
                txtSalesCustomerName.Text = DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows[0][1].ToString();
                txtSalesCustomerTotalItemsPurchased.Text = DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows[0][6].ToString();

                string[] TASTokens;
                char[] TASDelim = { ',' };
                TASTokens = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][2].ToString().Split(TASDelim);//tokenize the amount sold
                double amountSold = 0;
                for (int i = 0; i < TASTokens.Length - 1; i++)//add up all the numbers to find the total amount of items sold in this transaction
                    amountSold += double.Parse(TASTokens[i]);
                txtAmountSold.Text = amountSold.ToString();

                cbxProductsView.Items.Clear();
                string[] tokens;
                char[] delim = { ',' };
                tokens = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString().Split(delim);//tokenize the endproductid
                if (tokens.Length - 1 == 1)//if theres only one product sold
                {
                    DataOps.OleDbSelectProductName(tokens[0]);//use the individual id to query a name
                    cbxProductsView.Items.Add(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//add that name to the products box
                }
                else if (tokens.Length - 1 > 1)
                {
                    for (int i = 0; i < tokens.Length - 1; i++)
                    {
                        DataOps.OleDbSelectProductName(tokens[i]);//use the individual id to query a name
                        cbxProductsView.Items.Add(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//add that name to the products box
                    }
                }
                else { }//if theres no products sold, just don't do anything

                //recalculate total profit()
                if (cbxSoldProductID.Visible == true)
                    DataOps.OleDbSelectAllFromSoldProductWhereCustomerIDAndSoldProductID(cbxSalesIDView.Text, cbxSoldProductID.Text);
                else
                {
                    if (rdoSortByCustomerView.Checked == true)
                    {
                        DataOps.OleDbSelectSoldProductIDFromSoldProductWhereCustomerID(cbxSalesIDView.Text);
                        DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows[0][0].ToString());
                    }
                    else if (rdoSortByDateSoldView.Checked == true)
                    {
                        DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(cbxSalesIDView.Text);
                    }
                }
                string[] tokens4;
                char[] delim4 = { ',' };
                tokens4 = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString().Split(delim4);//tokenize product ids
                string[] tokens5;
                char[] delim5 = { ',' };
                tokens5 = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][2].ToString().Split(delim5);//tokenize amount sold 

                double totalAmountSold = 0;
                double totalCost = 0;
                double totalSellPrice = 0;
                if (tokens4.Length == 1)
                {
                    DataOps.OleDbSelectProductCostAndSellPrice(tokens4[0]);
                    totalCost = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString());
                    totalSellPrice = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString());
                }
                else
                {
                    for (int i = 0; i < tokens4.Length - 1; i++)
                    {
                        DataOps.OleDbSelectProductCostAndSellPrice(tokens4[i]);
                        totalAmountSold = double.Parse(tokens5[i]);
                        totalCost += double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString()) * totalAmountSold;
                        totalSellPrice += double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString()) * totalAmountSold;
                    }
                }
                double totalGrossProfit = totalSellPrice - totalCost;
                double totalGrossProfitAfterTax = totalGrossProfit - (totalGrossProfit * .0625);
                double totalGrossProfitAfterTaxAndReduction = totalGrossProfitAfterTax - (totalGrossProfitAfterTax * .6);
                txtTotalProfit.Text = "$" + (Math.Truncate(100 * totalGrossProfitAfterTaxAndReduction) / 100);
            }
        }

        private void cbxSoldProductID_SelectedIndexChanged(object sender, EventArgs e)
        {
            clearViewSales();
            DataOps.OleDbSelectAllFromSoldProductWhereCustomerIDAndSoldProductID(cbxSalesIDView.Text, cbxSoldProductID.Text);
            if (DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows.Count == 0)
            {
                MessageBox.Show("That Customer has not purchased anything yet.");
                return;
            }
            txtDateSold.Text = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][1].ToString().Replace("12:00:00 AM", "");
            txtStore.Text = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][3].ToString();

            DataOps.OleDbSelectAllFromCustomersWhereCustomerID(DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][5].ToString());
            txtSalesCustomerName.Text = DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows[0][1].ToString();
            txtSalesCustomerTotalItemsPurchased.Text = DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows[0][6].ToString();

            string[] TASTokens;
            char[] TASDelim = { ',' };
            TASTokens = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][2].ToString().Split(TASDelim);//tokenize the amount sold
            double amountSold = 0;
            for (int i = 0; i < TASTokens.Length - 1; i++)//add up all the numbers to find the total amount of items sold in this transaction
                amountSold += double.Parse(TASTokens[i]);
            txtAmountSold.Text = amountSold.ToString();

            cbxProductsView.Items.Clear();
            string[] tokens;
            char[] delim = { ',' };
            tokens = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString().Split(delim);//tokenize the endproductid
            if (tokens.Length - 1 == 1)//if theres only one product sold
            {
                DataOps.OleDbSelectProductName(tokens[0]);//use the individual id to query a name
                cbxProductsView.Items.Add(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//add that name to the products box
            }
            else if (tokens.Length - 1 > 1)
            {
                for (int i = 0; i < tokens.Length - 1; i++)
                {
                    DataOps.OleDbSelectProductName(tokens[i]);//use the individual id to query a name
                    cbxProductsView.Items.Add(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//add that name to the products box
                }
            }
            else { }//if theres no products sold, just don't do anything

            //recalculate total profit()
            if (cbxSoldProductID.Visible == true)
                DataOps.OleDbSelectAllFromSoldProductWhereCustomerIDAndSoldProductID(cbxSalesIDView.Text, cbxSoldProductID.Text);
            else
            {
                if (rdoSortByCustomerView.Checked == true)
                {
                    DataOps.OleDbSelectSoldProductIDFromSoldProductWhereCustomerID(cbxSalesIDView.Text);
                    DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows[0][0].ToString());
                }
                else if (rdoSortByDateSoldView.Checked == true)
                {
                    DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(cbxSalesIDView.Text);
                }
            }
            string[] tokens4;
            char[] delim4 = { ',' };
            tokens4 = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString().Split(delim4);//tokenize product ids
            string[] tokens5;
            char[] delim5 = { ',' };
            tokens5 = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][2].ToString().Split(delim5);//tokenize amount sold 

            double totalAmountSold = 0;
            double totalCost = 0;
            double totalSellPrice = 0;
            if (tokens4.Length == 1)
            {
                DataOps.OleDbSelectProductCostAndSellPrice(tokens4[0]);
                totalCost = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString());
                totalSellPrice = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString());
            }
            else
            {
                for (int i = 0; i < tokens4.Length - 1; i++)
                {
                    DataOps.OleDbSelectProductCostAndSellPrice(tokens4[i]);
                    totalAmountSold = double.Parse(tokens5[i]);
                    totalCost += double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString()) * totalAmountSold;
                    totalSellPrice += double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString()) * totalAmountSold;
                }
            }
            double totalGrossProfit = totalSellPrice - totalCost;
            double totalGrossProfitAfterTax = totalGrossProfit - (totalGrossProfit * .0625);
            double totalGrossProfitAfterTaxAndReduction = totalGrossProfitAfterTax - (totalGrossProfitAfterTax * .6);
            txtTotalProfit.Text = "$" + (Math.Truncate(100 * totalGrossProfitAfterTaxAndReduction) / 100);

        }

        private void rdoSortByCustomer_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoSortByCustomerView.Checked == true)
            {
                cbxTransactionView.Items.Clear();
                cbxSalesIDView.Items.Clear();
                cbxProductsView.Items.Clear();
                cbxSoldProductID.Items.Clear();
                lblPleaseSelectTransactionID.Visible = false;
                cbxSoldProductID.Visible = false;
                cbxSoldProductID.Enabled = false;
                clearViewSales();

                DataOps.OleDbSelectSoldProductByCustomer();
                List<string> customerNames = new List<string> { };//make a new list of customer names
                for (int i = 0; i < DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows.Count; i++)//loop for the amount of items in that list
                    customerNames.Add(DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows[i][0].ToString());//add values to that list

                for (int i = 0; i < customerNames.Count; i++)//loop for the amount of items in the list
                {
                    string currentCustomer = customerNames[i].ToLower();//make a variable to store the current name at position i
                    if (i != customerNames.Count)//doesn't move on to the next part if i has reached the final position
                    {
                        for (int j = i + 1; j < customerNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                        {
                            string comparedCustomer = customerNames[j].ToLower();//make a variable to store the current name at position j
                            if (currentCustomer == comparedCustomer)//checks if the customer at point i is the same as at point j
                                customerNames.RemoveAt(j);//removes the customer at point j if it is the same                     
                        }
                    }
                }

                for (int i = 0; i < customerNames.Count; i++)//add names to combo box
                    cbxTransactionView.Items.Add(customerNames[i]);
                cbxTransactionView.SelectedIndex = 0;
            }
        }

        private void rdoSortByDateSold_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoSortByDateSoldView.Checked == true)
            {
                cbxTransactionView.Items.Clear();
                cbxSalesIDView.Items.Clear();
                cbxProductsView.Items.Clear();
                cbxSoldProductID.Items.Clear();
                lblPleaseSelectTransactionID.Visible = false;
                cbxSoldProductID.Visible = false;
                cbxSoldProductID.Enabled = false;
                clearViewSales();

                DataOps.OleDbSelectSoldProductByDateSold();
                List<string> productNames = new List<string> { };//make a new list of product names
                for (int i = 0; i < DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows.Count; i++)//loop for the amount of items in that list
                    productNames.Add(DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[i][0].ToString());//add values to that list

                for (int i = 0; i < productNames.Count; i++)//loop for the amount of items in the list
                {
                    string currentProduct = productNames[i].ToLower();//make a variable to store the current name at position i
                    if (i != productNames.Count)//doesn't move on to the next part if i has reached the final position
                    {
                        for (int j = i + 1; j < productNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                        {
                            string comparedProduct = productNames[j].ToLower();//make a variable to store the current name at position j
                            if (currentProduct == comparedProduct)//checks if the product at point i is the same as at point j
                                productNames.RemoveAt(j);//removes the product at point j if it is the same                     
                        }
                    }
                }

                for (int i = 0; i < productNames.Count; i++)//add names to combo box
                    cbxTransactionView.Items.Add(productNames[i].ToString().Replace("12:00:00 AM", ""));
                cbxTransactionView.SelectedIndex = 0;
            }
        }

        private void cbxProducts_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cbxSoldProductID.Visible == true)
                DataOps.OleDbSelectAllFromSoldProductWhereCustomerIDAndSoldProductID(cbxSalesIDView.Text, cbxSoldProductID.Text);
            else
            {
                if (rdoSortByCustomerView.Checked == true)
                {
                    DataOps.OleDbSelectSoldProductIDFromSoldProductWhereCustomerID(cbxSalesIDView.Text);
                    DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows[0][0].ToString());
                }
                else if(rdoSortByDateSoldView.Checked == true)
                {
                    DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(cbxSalesIDView.Text);
                }
            }
            string[] tokens;
            char[] delim = { ',' };
            tokens = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][2].ToString().Split(delim);
            txtNumberOfProductSold.Text = tokens[cbxProductsView.SelectedIndex];

            lbxProductMaterialsUsed.Items.Clear();
            string[] tokens2;
            char[] delim2 = { ',' };
            tokens2 = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString().Split(delim2);

            DataOps.OleDbSelectProduct(tokens2[cbxProductsView.SelectedIndex], cbxProductsView.Text);//grabs info based on whichever id after tokenizing
            txtProductName.Text = DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString();
            txtProductSellPrice.Text = "$" + DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][8].ToString();
            txtProductType.Text = DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][4].ToString();
            txtProductOnHand.Text = DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][6].ToString();
            txtProductID.Text = DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString();
            if (DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][10].ToString() == "True")
                chkProductActive.Checked = true;
            else
                chkProductActive.Checked = false;
            if (DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][9].ToString() == "True")
                chkProductCustom.Checked = true;
            else
                chkProductCustom.Checked = false;
            txtProductCostToMake.Text = "$" + DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][5].ToString();
            txtProductDescription.Text = DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][2].ToString();
            txtProductColor.Text = DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][3].ToString();
            txtProductDimentions.Text = DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][7].ToString();
            txtProductRunningTotal.Text = "$" + DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][11].ToString();
            string[] tokens3;
            char[] delim3 = { ',' };
            tokens3 = DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][12].ToString().Split(delim3);
            for (int i = 0; i < tokens3.Length - 1; i++)
                lbxProductMaterialsUsed.Items.Add(tokens3[i]);
            txtProductNotes.Text = DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][13].ToString();
            txtMarkupPercentage.Text = DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][14].ToString() + "%";
            
            double cost = double.Parse(txtProductCostToMake.Text.Substring(1));
            double sellPrice = double.Parse(txtProductSellPrice.Text.Substring(1));
            double grossProfit = sellPrice - cost;
            double grossProfitAfterTax = grossProfit - (grossProfit * .0625);
            double grossprofitAfterTaxAndReduction = grossProfitAfterTax - (grossProfitAfterTax * .6);
            txtProfitFromProduct.Text = "$" + (Math.Truncate(100 * grossprofitAfterTaxAndReduction) / 100) * double.Parse(txtNumberOfProductSold.Text);

            //calculate total profit
            if (cbxSoldProductID.Visible == true)
                DataOps.OleDbSelectAllFromSoldProductWhereCustomerIDAndSoldProductID(cbxSalesIDView.Text, cbxSoldProductID.Text);
            else
            {
                if (rdoSortByCustomerView.Checked == true)
                {
                    DataOps.OleDbSelectSoldProductIDFromSoldProductWhereCustomerID(cbxSalesIDView.Text);
                    DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows[0][0].ToString());
                }
                else if (rdoSortByDateSoldView.Checked == true)
                {
                    DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(cbxSalesIDView.Text);
                }
            }
            string[] tokens4;
            char[] delim4 = { ',' };
            tokens4 = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString().Split(delim4);//tokenize product ids
            string[] tokens5;
            char[] delim5 = { ',' };
            tokens5 = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][2].ToString().Split(delim5);//tokenize amount sold 

            double totalAmountSold = 0;
            double totalCost = 0;
            double totalSellPrice = 0;
            if (tokens4.Length == 1)
            {
                DataOps.OleDbSelectProductCostAndSellPrice(tokens4[0]);
                totalCost = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString());
                totalSellPrice = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString());
            }
            else
            {
                for (int i = 0; i < tokens4.Length - 1; i++)
                {
                    DataOps.OleDbSelectProductCostAndSellPrice(tokens4[i]);
                    totalAmountSold = double.Parse(tokens5[i]);
                    totalCost += double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString()) * totalAmountSold;
                    totalSellPrice += double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString()) * totalAmountSold;
                }
            }
            double totalGrossProfit = totalSellPrice - totalCost;
            double totalGrossProfitAfterTax = totalGrossProfit - (totalGrossProfit * .0625);
            double totalGrossProfitAfterTaxAndReduction = totalGrossProfitAfterTax - (totalGrossProfitAfterTax * .6);
            txtTotalProfit.Text = "$" + (Math.Truncate(100 * totalGrossProfitAfterTaxAndReduction) / 100);
        }

        private void clearViewSales()
        {
            txtAmountSold.Clear();
            txtDateSold.Clear();
            txtStore.Clear();
            txtProductSellPrice.Clear();
            txtMarkupPercentage.Clear();
            txtSalesCustomerName.Clear();
            txtSalesCustomerTotalItemsPurchased.Clear();
            txtProductName.Clear();
            txtProductCostToMake.Clear();
            txtProductType.Clear();
            txtProductOnHand.Clear();
            txtProductID.Clear();
            chkProductActive.Checked = false;
            chkProductCustom.Checked = false;
            txtProductDescription.Clear();
            txtProductColor.Clear();
            txtProductDimentions.Clear();
            txtProductRunningTotal.Clear();
            lbxProductMaterialsUsed.Items.Clear();
            txtProductNotes.Clear();
            txtTotalProfit.Clear();
            lbxProductMaterialsUsed.Items.Clear();
            txtProfitFromProduct.Clear();
            txtNumberOfProductSold.Clear();
        }

        #endregion

        //make and edit transaction
        #region make and edit transaction

        private void cbxTransactionEdit_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbxSalesIDEdit.Items.Clear();
            cbxCustomerEdit.Items.Clear();
            cbxCustomerIDEdit.Items.Clear();
            cbxSoldProductIDEdit.Visible = false;
            cbxSoldProductIDEdit.Enabled = false;
            lblPleaseSelectATransactionID.Visible = false;
            clearUpdateAdd();
            if (rdoSortByCustomerEdit.Checked == true)
            {              
                DataOps.OleDbSelectCustomerIDFromCustomersWhereName(cbxTransactionEdit.Text);
                for (int i = 0; i < DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows.Count; i++)
                    cbxSalesIDEdit.Items.Add(DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows[i][0]);
            }
            else if(rdoSortByTransactionDateEdit.Checked == true)
            {
                DataOps.OleDbSelectSoldProductIDFromSoldProductWhereDateSold(cbxTransactionEdit.Text);
                for (int i = 0; i < DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows.Count; i++)
                    cbxSalesIDEdit.Items.Add(DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows[i][0]);
            }
        }
        private bool extraNeededEdit = false;
        private string oldCbxTransactionEditText = "";
        private void cbxSalesIDEdit_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbxCustomerEdit.Items.Clear();
            cbxCustomerIDEdit.Items.Clear();
            cbxSoldProductIDEdit.Items.Clear();
            clearUpdateAdd();
            if (rdoSortByCustomerEdit.Checked == true)
            {
                DataOps.OleDbSelectAllFromSoldProductWhereCustomerID(cbxSalesIDEdit.Text);
                if (DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows.Count == 0)
                {
                    MessageBox.Show("That Customer has not purchased anything yet.");
                    lblPleaseSelectATransactionID.Visible = false;
                    cbxSoldProductIDEdit.Visible = false;
                    cbxSoldProductIDEdit.Enabled = false;
                    oldCbxTransactionEditText = cbxTransactionEdit.SelectedItem.ToString();
                    return;
                }
                if (DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows.Count < 1)//sets extra needed to false if the customer has had no one or no transactions
                    extraNeededEdit = false;
                if (cbxTransactionEdit.SelectedItem.ToString().ToLower() != oldCbxTransactionEditText.ToLower())//sets extra needed to false if the customer before this one doesn't share the same name as the current one
                    extraNeededEdit = false;
                if (extraNeededEdit == false)
                {
                    txtTransactionIDEdit.Text = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][0].ToString();
                    dtDateSoldEdit.Text = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][1].ToString();
                    txtStoreEdit.Text = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][3].ToString();

                    DataOps.OleDbSelectCustomerNames();
                    List<string> customerNames = new List<string> { };//make a new list of customer names
                    for (int i = 0; i < DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows.Count; i++)//loop for the amount of items in that list
                        customerNames.Add(DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows[i][0].ToString());//add values to that list

                    for (int i = 0; i < customerNames.Count; i++)//loop for the amount of items in the list
                    {
                        string currentCustomer = customerNames[i].ToLower();//make a variable to store the current name at position i
                        if (i != customerNames.Count)//doesn't move on to the next part if i has reached the final position
                        {
                            for (int j = i + 1; j < customerNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                            {
                                string comparedCustomer = customerNames[j].ToLower();//make a variable to store the current name at position j
                                if (currentCustomer == comparedCustomer)//checks if the customer at point i is the same as at point j
                                    customerNames.RemoveAt(j);//removes the customer at point j if it is the same                     
                            }
                        }
                    }

                    for (int i = 0; i < customerNames.Count; i++)//add names to combo box
                        cbxCustomerEdit.Items.Add(customerNames[i]);
                    cbxCustomerEdit.SelectedIndex = 0;

                    DataOps.OleDbSelectAllFromCustomersWhereCustomerID(DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][5].ToString());
                    cbxCustomerEdit.SelectedItem = DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows[0][1].ToString();
                    cbxCustomerIDEdit.SelectedItem = DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows[0][0].ToString();

                    DataOps.OleDbSelectEndProductNames();
                    List<string> productNames = new List<string> { };//make a new list of product names
                    for (int i = 0; i < DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows.Count; i++)//loop for the amount of items in that list
                        productNames.Add(DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[i][0].ToString());//add values to that list

                    for (int i = 0; i < productNames.Count; i++)//loop for the amount of items in the list
                    {
                        string currentProduct = productNames[i].ToLower();//make a variable to store the current name at position i
                        if (i != productNames.Count)//doesn't move on to the next part if i has reached the final position
                        {
                            for (int j = i + 1; j < productNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                            {
                                string comparedProduct = productNames[j].ToLower();//make a variable to store the current name at position j
                                if (currentProduct == comparedProduct)//checks if the product at point i is the same as at point j
                                    productNames.RemoveAt(j);//removes the product at point j if it is the same                     
                            }
                        }
                    }

                    for (int i = 0; i < productNames.Count; i++)//add names to combo box
                        lbxProductsEdit.Items.Add(productNames[i]);
                    lbxProductsEdit.SelectedIndex = 0;

                    lbxProductsSoldEdit.Items.Clear();
                    string[] tokens;
                    char[] delim = { ',' };
                    tokens = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString().Split(delim);//tokenize the endproductid
                    if (tokens.Length - 1 == 1)//if theres only one product sold
                    {
                        DataOps.OleDbSelectProductName(tokens[0]);//use the individual id to query a name
                        lbxProductsSoldEdit.Items.Add(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//add that name to the products box
                        lbxProductsEdit.Items.Remove(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//remove that name from the other products box
                    }
                    else if (tokens.Length - 1 > 1)
                    {
                        for (int i = 0; i < tokens.Length - 1; i++)
                        {
                            DataOps.OleDbSelectProductName(tokens[i]);//use the individual id to query a name
                            lbxProductsSoldEdit.Items.Add(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//add that name to the products box
                            lbxProductsEdit.Items.Remove(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//remove that name from the other products box
                        }
                    }
                    else { }//if theres no products sold, just don't do anything
                    recalculateTotalProfit();
                }
                DataOps.OleDbSelectAllFromSoldProductWhereCustomerID(cbxSalesIDEdit.Text);
                if (cbxTransactionEdit.SelectedItem.ToString().ToLower() == oldCbxTransactionEditText.ToLower())//checks to see if the user is preparing to view the same customer name but with a different id
                {
                    lblPleaseSelectTransactionID.Visible = true;
                    cbxSoldProductIDEdit.Visible = true;
                    cbxSoldProductIDEdit.Enabled = true;
                    extraNeeded = true;
                    DataOps.OleDbSelectSoldProductIDFromSoldProductWhereCustomerID(DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][5].ToString());
                    for (int i = 0; i < DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows.Count; i++)
                        cbxSoldProductIDEdit.Items.Add(DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows[i][0].ToString());
                    cbxSoldProductIDEdit.SelectedIndex = 0;
                    oldCbxTransactionEditText = cbxTransactionEdit.SelectedItem.ToString();
                    return;
                }
                if (DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows.Count > 1)//checks if the customer had numerous transactions
                {
                    lblPleaseSelectATransactionID.Visible = true;
                    cbxSoldProductIDEdit.Visible = true;
                    cbxSoldProductIDEdit.Enabled = true;
                    extraNeededEdit = true;
                    DataOps.OleDbSelectSoldProductIDFromSoldProductWhereCustomerID(DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][5].ToString());
                    for (int i = 0; i < DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows.Count; i++)
                        cbxSoldProductIDEdit.Items.Add(DataOps.dsSoldProduct2.Tables[DataOps.dtSoldProduct].Rows[i][0].ToString());
                    cbxSoldProductIDEdit.SelectedIndex = 0;
                    oldCbxTransactionEditText = cbxTransactionEdit.SelectedItem.ToString();
                    return;
                }
                oldCbxTransactionEditText = cbxTransactionEdit.SelectedItem.ToString();
            }
            else if (rdoSortByTransactionDateEdit.Checked == true)
            {
                DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(cbxSalesIDEdit.Text);
                txtTransactionIDEdit.Text = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][0].ToString();
                dtDateSoldEdit.Text = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][1].ToString();
                txtStoreEdit.Text = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][3].ToString();

                DataOps.OleDbSelectCustomerNames();
                List<string> customerNames = new List<string> { };//make a new list of customer names
                for (int i = 0; i < DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows.Count; i++)//loop for the amount of items in that list
                    customerNames.Add(DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows[i][0].ToString());//add values to that list

                for (int i = 0; i < customerNames.Count; i++)//loop for the amount of items in the list
                {
                    string currentCustomer = customerNames[i].ToLower();//make a variable to store the current name at position i
                    if (i != customerNames.Count)//doesn't move on to the next part if i has reached the final position
                    {
                        for (int j = i + 1; j < customerNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                        {
                            string comparedCustomer = customerNames[j].ToLower();//make a variable to store the current name at position j
                            if (currentCustomer == comparedCustomer)//checks if the customer at point i is the same as at point j
                                customerNames.RemoveAt(j);//removes the customer at point j if it is the same                     
                        }
                    }
                }

                for (int i = 0; i < customerNames.Count; i++)//add names to combo box
                    cbxCustomerEdit.Items.Add(customerNames[i]);
                cbxCustomerEdit.SelectedIndex = 0;

                DataOps.OleDbSelectAllFromCustomersWhereCustomerID(DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][5].ToString());
                cbxCustomerEdit.SelectedItem = DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows[0][1].ToString();
                cbxCustomerIDEdit.SelectedItem = DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows[0][0].ToString();

                DataOps.OleDbSelectEndProductNames();
                List<string> productNames = new List<string> { };//make a new list of product names
                for (int i = 0; i < DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows.Count; i++)//loop for the amount of items in that list
                    productNames.Add(DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[i][0].ToString());//add values to that list

                for (int i = 0; i < productNames.Count; i++)//loop for the amount of items in the list
                {
                    string currentProduct = productNames[i].ToLower();//make a variable to store the current name at position i
                    if (i != productNames.Count)//doesn't move on to the next part if i has reached the final position
                    {
                        for (int j = i + 1; j < productNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                        {
                            string comparedProduct = productNames[j].ToLower();//make a variable to store the current name at position j
                            if (currentProduct == comparedProduct)//checks if the product at point i is the same as at point j
                                productNames.RemoveAt(j);//removes the product at point j if it is the same                     
                        }
                    }
                }

                for (int i = 0; i < productNames.Count; i++)//add names to combo box
                    lbxProductsEdit.Items.Add(productNames[i]);
                lbxProductsEdit.SelectedIndex = 0;

                lbxProductsSoldEdit.Items.Clear();
                string[] tokens;
                char[] delim = { ',' };
                tokens = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString().Split(delim);//tokenize the endproductid
                if (tokens.Length - 1 == 1)//if theres only one product sold
                {
                    DataOps.OleDbSelectProductName(tokens[0]);//use the individual id to query a name
                    lbxProductsSoldEdit.Items.Add(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//add that name to the products box
                    lbxProductsEdit.Items.Remove(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//remove that name from the other products box
                }
                else if (tokens.Length - 1 > 1)
                {
                    for (int i = 0; i < tokens.Length - 1; i++)
                    {
                        DataOps.OleDbSelectProductName(tokens[i]);//use the individual id to query a name
                        lbxProductsSoldEdit.Items.Add(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//add that name to the products box
                        lbxProductsEdit.Items.Remove(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//remove that name from the other products box
                    }
                }
                else { }//if theres no products sold, just don't do anything
                recalculateTotalProfit();
            }
        }

        private void recalculateTotalProfit()
        {
            //calculate total profit for transaction
            //grab ids for products
            //tokenize ids then loop for how long the token is
            //grab the sellprice and cost of token[i], add the sell prices and cost together
            //calculate total profit out of that.
            DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(txtTransactionIDEdit.Text);//this may be datesold, but it selects sold product stuff by sold productid
            string[] tokens;
            char[] delim = { ',' };
            tokens = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString().Split(delim);//tokenize product ids
            string[] tokens2;
            char[] delim2 = { ',' };
            tokens2 = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][2].ToString().Split(delim2);//tokenize amount sold 

            double totalAmountSold = 0;
            double totalCost = 0;
            double totalSellPrice = 0;
            if (tokens.Length - 1 == 1)
            {
                DataOps.OleDbSelectProductCostAndSellPrice(tokens[0]);
                totalCost = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString()) * double.Parse(tokens2[0]); 
                totalSellPrice = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString()) * double.Parse(tokens2[0]);
            }
            else if(tokens.Length - 1 > 1)
            {
                for (int i = 0; i < tokens.Length - 1; i++)
                {
                    DataOps.OleDbSelectProductCostAndSellPrice(tokens[i]);
                    totalAmountSold = double.Parse(tokens2[i]);
                    totalCost += double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString()) * totalAmountSold;
                    totalSellPrice += double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString()) * totalAmountSold;
                }
            }
            else { return; }//just do nothing at all
            double totalGrossProfit = totalSellPrice - totalCost;
            double totalGrossProfitAfterTax = totalGrossProfit - (totalGrossProfit * .0625);
            double totalGrossProfitAfterTaxAndReduction = totalGrossProfitAfterTax - (totalGrossProfitAfterTax * .6);
            txtTotalProfitEdit.Text = "$" + (Math.Truncate(100 * totalGrossProfitAfterTaxAndReduction) / 100);
        }

        private void rdoSortByCustomerEdit_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoSortByCustomerEdit.Checked == true)
            {
                cbxTransactionEdit.Items.Clear();
                cbxSalesIDEdit.Items.Clear();
                cbxCustomerEdit.Items.Clear();
                cbxCustomerIDEdit.Items.Clear();
                clearUpdateAdd();
                lblPleaseSelectATransactionID.Visible = false;
                cbxSoldProductIDEdit.Visible = false;
                cbxSoldProductIDEdit.Enabled = false;

                DataOps.OleDbSelectSoldProductByCustomer();
                List<string> customerNames = new List<string> { };//make a new list of customer names
                for (int i = 0; i < DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows.Count; i++)//loop for the amount of items in that list
                    customerNames.Add(DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows[i][0].ToString());//add values to that list

                for (int i = 0; i < customerNames.Count; i++)//loop for the amount of items in the list
                {
                    string currentCustomer = customerNames[i].ToLower();//make a variable to store the current name at position i
                    if (i != customerNames.Count)//doesn't move on to the next part if i has reached the final position
                    {
                        for (int j = i + 1; j < customerNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                        {
                            string comparedCustomer = customerNames[j].ToLower();//make a variable to store the current name at position j
                            if (currentCustomer == comparedCustomer)//checks if the customer at point i is the same as at point j
                                customerNames.RemoveAt(j);//removes the customer at point j if it is the same                     
                        }
                    }
                }

                for (int i = 0; i < customerNames.Count; i++)//add names to combo box
                    cbxTransactionEdit.Items.Add(customerNames[i]);
                cbxTransactionEdit.SelectedIndex = 0;
            }
        }

        private void rdoSortByTransactionDateEdit_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoSortByTransactionDateEdit.Checked == true)
            {
                cbxTransactionEdit.Items.Clear();
                cbxSalesIDEdit.Items.Clear();
                cbxCustomerEdit.Items.Clear();
                cbxCustomerIDEdit.Items.Clear();
                clearUpdateAdd();
                lblPleaseSelectATransactionID.Visible = false;
                cbxSoldProductIDEdit.Visible = false;
                cbxSoldProductIDEdit.Enabled = false;

                DataOps.OleDbSelectSoldProductByDateSold();
                List<string> productNames = new List<string> { };//make a new list of product names
                for (int i = 0; i < DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows.Count; i++)//loop for the amount of items in that list
                    productNames.Add(DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[i][0].ToString());//add values to that list

                for (int i = 0; i < productNames.Count; i++)//loop for the amount of items in the list
                {
                    string currentProduct = productNames[i].ToLower();//make a variable to store the current name at position i
                    if (i != productNames.Count)//doesn't move on to the next part if i has reached the final position
                    {
                        for (int j = i + 1; j < productNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                        {
                            string comparedProduct = productNames[j].ToLower();//make a variable to store the current name at position j
                            if (currentProduct == comparedProduct)//checks if the product at point i is the same as at point j
                                productNames.RemoveAt(j);//removes the product at point j if it is the same                     
                        }
                    }
                }

                for (int i = 0; i < productNames.Count; i++)//add names to combo box
                    cbxTransactionEdit.Items.Add(productNames[i].ToString().Replace("12:00:00 AM", ""));
                cbxTransactionEdit.SelectedIndex = 0;
            }
        }

        private void lbxProductsEdit_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbxProductIDEdit.Items.Clear();
            if (lbxProductsEdit.SelectedIndex != -1)//if there is a product selected, fill in the id for that selected item
            {
                DataOps.OleDbSelectProductIDs(lbxProductsEdit.SelectedItem.ToString());
                for (int i = 0; i < DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows.Count; i++)
                    lbxProductIDEdit.Items.Add(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[i][0]);
            }
        }

        private void cbxSoldProductIDEdit_SelectedIndexChanged(object sender, EventArgs e)
        {
            clearUpdateAdd();
            DataOps.OleDbSelectAllFromSoldProductWhereCustomerIDAndSoldProductID(cbxSalesIDEdit.Text, cbxSoldProductIDEdit.Text);
            if (DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows.Count == 0)
            {
                MessageBox.Show("That Customer has not purchased anything yet.");
                return;
            }
            txtTransactionIDEdit.Text = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][0].ToString();
            dtDateSoldEdit.Text = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][1].ToString();
            txtStoreEdit.Text = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][3].ToString();

            DataOps.OleDbSelectCustomerNames();
            DataOps.OleDbSelectCustomerNames();
            List<string> customerNames = new List<string> { };//make a new list of customer names
            for (int i = 0; i < DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows.Count; i++)//loop for the amount of items in that list
                customerNames.Add(DataOps.dsCustomers2.Tables[DataOps.dtCustomers].Rows[i][0].ToString());//add values to that list

            for (int i = 0; i < customerNames.Count; i++)//loop for the amount of items in the list
            {
                string currentCustomer = customerNames[i].ToLower();//make a variable to store the current name at position i
                if (i != customerNames.Count)//doesn't move on to the next part if i has reached the final position
                {
                    for (int j = i + 1; j < customerNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                    {
                        string comparedCustomer = customerNames[j].ToLower();//make a variable to store the current name at position j
                        if (currentCustomer == comparedCustomer)//checks if the customer at point i is the same as at point j
                            customerNames.RemoveAt(j);//removes the customer at point j if it is the same                     
                    }
                }
            }

            for (int i = 0; i < customerNames.Count; i++)//add names to combo box
                cbxCustomerEdit.Items.Add(customerNames[i]);
            cbxCustomerEdit.SelectedIndex = 0;

            DataOps.OleDbSelectAllFromCustomersWhereCustomerID(DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][5].ToString());
            cbxCustomerEdit.SelectedItem = DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows[0][1].ToString();
            cbxCustomerIDEdit.SelectedItem = DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows[0][0].ToString();

            DataOps.OleDbSelectEndProductNames();
            List<string> productNames = new List<string> { };//make a new list of product names
            for (int i = 0; i < DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows.Count; i++)//loop for the amount of items in that list
                productNames.Add(DataOps.dsEndProducts2.Tables[DataOps.dtEndProducts].Rows[i][0].ToString());//add values to that list

            for (int i = 0; i < productNames.Count; i++)//loop for the amount of items in the list
            {
                string currentProduct = productNames[i].ToLower();//make a variable to store the current name at position i
                if (i != productNames.Count)//doesn't move on to the next part if i has reached the final position
                {
                    for (int j = i + 1; j < productNames.Count; j++)//loop for the amount of items in the list starting at one to avoid getting rid of exact duplicate values
                    {
                        string comparedProduct = productNames[j].ToLower();//make a variable to store the current name at position j
                        if (currentProduct == comparedProduct)//checks if the product at point i is the same as at point j
                            productNames.RemoveAt(j);//removes the product at point j if it is the same                     
                    }
                }
            }

            for (int i = 0; i < productNames.Count; i++)//add names to combo box
                lbxProductsEdit.Items.Add(productNames[i]);
            lbxProductsEdit.SelectedIndex = 0;

            lbxProductsSoldEdit.Items.Clear();
            string[] tokens;
            char[] delim = { ',' };
            tokens = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString().Split(delim);//tokenize the endproductid
            if (tokens.Length - 1 == 1)//if theres only one product sold
            {
                DataOps.OleDbSelectProductName(tokens[0]);//use the individual id to query a name
                lbxProductsSoldEdit.Items.Add(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//add that name to the products box
                lbxProductsEdit.Items.Remove(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//remove that name from the other products box
            }
            else if (tokens.Length - 1 > 1)
            {
                for (int i = 0; i < tokens.Length - 1; i++)
                {
                    DataOps.OleDbSelectProductName(tokens[i]);//use the individual id to query a name
                    lbxProductsSoldEdit.Items.Add(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//add that name to the products box
                    lbxProductsEdit.Items.Remove(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0]);//remove that name from the other products box
                }
            }
            else { }//if theres no products sold, just don't do anything
            recalculateTotalProfit();
        }

        private void cbxCustomerEdit_SelectedIndexChanged(object sender, EventArgs e)
        {
            cbxCustomerIDEdit.Items.Clear();
            DataOps.OleDbSelectCustomerIDs(cbxCustomerEdit.Text);
            for (int i = 0; i < DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows.Count; i++)
                cbxCustomerIDEdit.Items.Add(DataOps.dsCustomers.Tables[DataOps.dtCustomers].Rows[i][0].ToString());
        }

        private void btnAddProduct_Click(object sender, EventArgs e)
        {            
            if (lbxProductIDEdit.SelectedIndex != -1)
            {
                //head on over to the amoundsoldcomfirmation button event
                editAmountSold = false;
                pnlAmountSold.Visible = true;
                pnlAmountSold.Enabled = true;
            }
            else
                MessageBox.Show("Please select a product (and corresponding product id) to sell.");
        }

        private void btnSubtractProduct_Click(object sender, EventArgs e)
        {
            if(lbxProductsSoldEdit.SelectedIndex != -1)
            {
                DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(txtTransactionIDEdit.Text);//grab all info about the currently selected transaction
                string[] tokens;
                char[] delim = { ',' };
                tokens = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][2].ToString().Split(delim);//tokenize the amount sold in sold product
                tokens[lbxProductsSoldEdit.SelectedIndex] = "";//that spot in the tokenized string is set to nothing because that item is being removed
                string newAmountSold = "";
                for (int i = 0; i < tokens.Length - 1; i++)//reconstruct the comma separated amount sold
                {
                    if (i != lbxProductsSoldEdit.SelectedIndex)//skips over the index we just set to nothing
                        newAmountSold += tokens[i] + ",";
                }

                //this little bit does the same thing as the top there, just with endproductid instead of amount sold
                string[] tokens2;
                char[] delim2 = { ',' };
                tokens2 = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString().Split(delim2);//tokenize the endproductid
                tokens2[lbxProductsSoldEdit.SelectedIndex] = "";
                string newEndProductID = "";
                for (int i = 0; i < tokens2.Length - 1; i++)
                {
                    if(i != lbxProductsSoldEdit.SelectedIndex)
                        newEndProductID += tokens2[i] + ",";
                }

                //update the database real quick so that things relying on this data arn't throwing errors all over the place
                DataOps.OleDbUpdateSoldProductAmountSold(newAmountSold, txtTransactionIDEdit.Text);//update amount sold
                DataOps.OleDbUpdateSoldProductEndProductID(newEndProductID, txtTransactionIDEdit.Text);//update endproductid               
                DataOps.OleDbUpdateCustomerTotalItemsPurchasedSubtract(txtAmountSoldEdit2.Text, DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][5].ToString());//update customers
                DataOps.OleDbUpdateEndProductOnHandAdd(txtAmountSoldEdit2.Text, txtProductsSoldIDEdit.Text);//update end product on hand
                DataOps.OleDbUpdateEndProductRunningTotalSubtract(txtProfitEdit.Text.Substring(1), txtProductsSoldIDEdit.Text);//update running total

                lbxProductsEdit.Items.Add(lbxProductsSoldEdit.SelectedItem.ToString());//add the removed item back into the products list box
                lbxProductsSoldEdit.Items.RemoveAt(lbxProductsSoldEdit.SelectedIndex);//remove the selected item and clear up stuff
                txtAmountSoldEdit.Value = 0;
                txtAmountSoldEdit2.Clear();
                txtMarkupPercentageEdit.Clear();
                txtSellPriceEdit.Clear();
                txtProfitEdit.Clear();
                txtTotalProfitEdit.Clear();
            }
            else
                MessageBox.Show("Please select a product to remove.");
        }

        private void lbxProductsSoldEdit_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtProductsSoldIDEdit.Clear();
            if (lbxProductsSoldEdit.SelectedIndex != -1)
            {
                DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(txtTransactionIDEdit.Text);
                string[] tokens;
                char[] delim = { ',' };
                tokens = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString().Split(delim);
                DataOps.OleDbSelectProduct(tokens[lbxProductsSoldEdit.SelectedIndex], lbxProductsSoldEdit.Text);//grabs info based on whichever id after tokenizing
                txtProductsSoldIDEdit.Text = DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString();

                string[] tokens2;
                char[] delim2 = { ',' };
                tokens2 = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][2].ToString().Split(delim2);
                txtAmountSoldEdit.Value = decimal.Parse(tokens2[lbxProductsSoldEdit.SelectedIndex]);
                txtAmountSoldEdit2.Text = tokens2[lbxProductsSoldEdit.SelectedIndex];

                DataOps.OleDbSelectProductMarkupAndCostToMakeAndSellPrice(txtProductsSoldIDEdit.Text);
                txtMarkupPercentageEdit.Text = DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString() + "%";
                txtSellPriceEdit.Text = "$" + DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][2].ToString();

                double costToMake = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString());
                string sellPrice = (((double.Parse(txtMarkupPercentageEdit.Text.TrimEnd('%')) / 100) * (costToMake)) + costToMake).ToString();
                double grossProfit = double.Parse(sellPrice) - costToMake;
                double grossProfitAfterTax = grossProfit - (grossProfit * .0625);
                double grossprofitAfterTaxAndReduction = grossProfitAfterTax - (grossProfitAfterTax * .6);
                txtProfitEdit.Text = "$" + ((Math.Truncate(100 * grossprofitAfterTaxAndReduction) / 100) * double.Parse(txtAmountSoldEdit2.Text));

                recalculateTotalProfit();
            }
        }
        private bool editAmountSold = true;//true for this means its going to edit the product sold. false means its going to edit the adding of a product sold
        private void btnEditAmountSold_Click(object sender, EventArgs e)
        {
            editAmountSold = true;
            if (txtAmountSoldEdit2.Text != "")
            {
                pnlAmountSold.Visible = true;
                pnlAmountSold.Enabled = true;
            }
            else
                MessageBox.Show("Please select a sold product to edit.");
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            pnlAmountSold.Visible = false;
            pnlAmountSold.Enabled = false;
            txtAmountSoldEdit.Value = 0;
        }

        private void btnAmountSoldComfirmation_Click(object sender, EventArgs e)
        {
            if (txtAmountSoldEdit.Value <= 0)
                MessageBox.Show("You must sell at least one of this product.");
            else
            {                                  
                if (editAmountSold == true)//edit product sold
                {                  
                    if (txtAmountSoldEdit.Value - decimal.Parse(txtAmountSoldEdit2.Text) < 0)//checks if the new amount sold - the old amount sold is negative
                    {                        
                        DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(txtTransactionIDEdit.Text);//grab all info about the currently selected transaction
                        string[] tokens;
                        char[] delim = { ',' };
                        tokens = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][2].ToString().Split(delim);//tokenize the amount sold in sold product
                        tokens[lbxProductsSoldEdit.SelectedIndex] = txtAmountSoldEdit.Value.ToString();//the amount sold at the index of the sold product selected is set to be the new amount sold.
                        string newAmountSold = "";
                        for (int i = 0; i < tokens.Length - 1; i++)//reconstruct the comma separated amount sold
                            newAmountSold += tokens[i] + ",";

                        //subtract items purchased from customer
                        //subtract from endproducts on hand
                        //subtract from endproducts running total
                        DataOps.OleDbUpdateSoldProductAmountSold(newAmountSold, txtTransactionIDEdit.Text);//update sold product
                        DataOps.OleDbUpdateEndProductOnHandAdd(((txtAmountSoldEdit.Value - decimal.Parse(txtAmountSoldEdit2.Text)) * -1).ToString(), txtProductsSoldIDEdit.Text);//update end product on hand
                        DataOps.OleDbUpdateCustomerTotalItemsPurchasedAdd((txtAmountSoldEdit.Value - decimal.Parse(txtAmountSoldEdit2.Text)).ToString(), DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][5].ToString());//update customers
                        DataOps.OleDbSelectProductMarkupAndCostToMakeAndSellPrice(txtProductsSoldIDEdit.Text);
                        double costToMake = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString());
                        string sellPrice = (((double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString()) / 100) * (costToMake)) + costToMake).ToString();
                        double grossProfit = double.Parse(sellPrice) - costToMake;
                        double grossProfitAfterTax = grossProfit - (grossProfit * .0625);
                        double grossprofitAfterTaxAndReduction = grossProfitAfterTax - (grossProfitAfterTax * .6);
                        string profit = ((Math.Truncate(100 * grossprofitAfterTaxAndReduction) / 100) * double.Parse(((txtAmountSoldEdit.Value - decimal.Parse(txtAmountSoldEdit2.Text)) * -1).ToString())).ToString();//calculate the amount of money the difference between new amount sold and old amount sold is
                        DataOps.OleDbUpdateEndProductRunningTotalSubtract(profit, txtProductsSoldIDEdit.Text);//update running total by subtracting the dollar amount from the amount sold taken off
                        MessageBox.Show("Amount sold successfully updated for sold product.");
                        txtAmountSoldEdit2.Text = txtAmountSoldEdit.Value.ToString();//put the new value of amount sold into the other amoutn sold box to make sure the calculations using that box are right
                        pnlAmountSold.Visible = false;
                        pnlAmountSold.Enabled = false;
                    }
                    else
                    {
                        DataOps.OleDbSelectOnHandFromEndProductsWhereEndProductID(txtProductsSoldIDEdit.Text);//grabs the product on hand of the currently selected product
                        if ((decimal.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString()) - (txtAmountSoldEdit.Value - decimal.Parse(txtAmountSoldEdit2.Text))) >= 0)//checks if there are enough products on hand to go through with the transaction
                        {
                            DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(txtTransactionIDEdit.Text);//grab all info about the currently selected transaction
                            string[] tokens;
                            char[] delim = { ',' };
                            tokens = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][2].ToString().Split(delim);//tokenize the amount sold in sold product
                            tokens[lbxProductsSoldEdit.SelectedIndex] = txtAmountSoldEdit.Value.ToString();//the amount sold at the index of the sold product selected is set to be the new amount sold.                            
                            string newAmountSold = "";
                            for (int i = 0; i < tokens.Length - 1; i++)//reconstruct the comma separated amount sold
                                newAmountSold += tokens[i] + ",";


                            DataOps.OleDbUpdateSoldProductAmountSold(newAmountSold, txtTransactionIDEdit.Text);//update sold product
                            DataOps.OleDbUpdateEndProductOnHandSubtract((txtAmountSoldEdit.Value - decimal.Parse(txtAmountSoldEdit2.Text)).ToString(), txtProductsSoldIDEdit.Text);//update end product on hand
                            DataOps.OleDbSelectTotalItemsPurchasedFromCustomersWhereCustomerID(DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][5].ToString());//grab the total items purchased by the customer in this transaction
                            DataOps.OleDbUpdateCustomerTotalItemsPurchasedAdd((txtAmountSoldEdit.Value - decimal.Parse(txtAmountSoldEdit2.Text)).ToString(), DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][5].ToString());//update customers
                            //update running total
                            DataOps.OleDbSelectProductMarkupAndCostToMakeAndSellPrice(txtProductsSoldIDEdit.Text);
                            double costToMake = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString());
                            string sellPrice = (((double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString()) / 100) * (costToMake)) + costToMake).ToString();
                            double grossProfit = double.Parse(sellPrice) - costToMake;
                            double grossProfitAfterTax = grossProfit - (grossProfit * .0625);
                            double grossprofitAfterTaxAndReduction = grossProfitAfterTax - (grossProfitAfterTax * .6);
                            string profit = ((Math.Truncate(100 * grossprofitAfterTaxAndReduction) / 100) * double.Parse((txtAmountSoldEdit.Value - decimal.Parse(txtAmountSoldEdit2.Text)).ToString())).ToString();
                            DataOps.OleDbUpdateEndProductRunningTotalAdd(profit, txtProductsSoldIDEdit.Text);

                            MessageBox.Show("Amount sold successfully updated for sold product.");
                            txtAmountSoldEdit2.Text = txtAmountSoldEdit.Value.ToString();//put the new value of amount sold into the other amoutn sold box to make sure the calculations using that box are right
                            pnlAmountSold.Visible = false;
                            pnlAmountSold.Enabled = false;
                        }
                        else
                        {
                            MessageBox.Show("There is not enough of those products on hand to continue with desired transaction.");
                            txtAmountSoldEdit.Focus();
                        }
                    }
                }
                else if (editAmountSold == false)//edit when adding a new product sold
                {
                    DataOps.OleDbSelectOnHandFromEndProductsWhereEndProductID(lbxProductIDEdit.Text);//grabs the product on hand of the currently selected product
                    if ((decimal.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString()) - txtAmountSoldEdit.Value) >= 0)//checks if there are enough products on hand to go through with the transaction
                    {                     
                        DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(txtTransactionIDEdit.Text);//grab all info about the currently selected transaction
                        string newAmountSold = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][2].ToString() + txtAmountSoldEdit.Value.ToString() + ",";//amount sold plus the newly added amount sold
                        string newEndProductID = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString() + lbxProductIDEdit.Text + ",";//endproduct id plus the newly added endproduct id

                        DataOps.OleDbUpdateSoldProductAmountSold(newAmountSold, txtTransactionIDEdit.Text);//update amount sold
                        DataOps.OleDbUpdateCustomerTotalItemsPurchasedAdd(txtAmountSoldEdit.Value.ToString(), DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][5].ToString());//update customers
                        DataOps.OleDbUpdateSoldProductEndProductID(newEndProductID, txtTransactionIDEdit.Text);//update endproductid
                        DataOps.OleDbUpdateEndProductOnHandSubtract(txtAmountSoldEdit.Value.ToString(), lbxProductIDEdit.Text);//update end product on hand
                        //update running total
                        DataOps.OleDbSelectProductMarkupAndCostToMakeAndSellPrice(lbxProductIDEdit.Text);
                        double costToMake = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString());
                        string sellPrice = (((double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString()) / 100) * (costToMake)) + costToMake).ToString();
                        double grossProfit = double.Parse(sellPrice) - costToMake;
                        double grossProfitAfterTax = grossProfit - (grossProfit * .0625);
                        double grossprofitAfterTaxAndReduction = grossProfitAfterTax - (grossProfitAfterTax * .6);
                        string profit = ((Math.Truncate(100 * grossprofitAfterTaxAndReduction) / 100) * double.Parse(txtAmountSoldEdit.Value.ToString())).ToString();
                        DataOps.OleDbUpdateEndProductRunningTotalAdd(profit, lbxProductIDEdit.Text);

                        pnlAmountSold.Visible = false;
                        pnlAmountSold.Enabled = false;
                        lbxProductsSoldEdit.Items.Add(lbxProductsEdit.SelectedItem.ToString());//add selected product to products sold listbox
                        lbxProductsEdit.Items.RemoveAt(lbxProductsEdit.SelectedIndex);//remove the thing the user just added
                    }
                    else
                    {
                        MessageBox.Show("There is not enough of those products on hand to continue with desired transaction.");
                        txtAmountSoldEdit.Focus();
                    }
                }
                
                //calculate profit for selected item
                //grab markup, costtomake, and sellprice
                //calculate the profit out of that
                if (lbxProductsSoldEdit.SelectedIndex != -1)
                {
                    recalculateTotalProfit();//recalulate the total profit
                    DataOps.OleDbSelectProductMarkupAndCostToMakeAndSellPrice(txtProductsSoldIDEdit.Text);
                    double costToMake = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString());
                    string sellPrice = (((double.Parse(txtMarkupPercentageEdit.Text.TrimEnd('%')) / 100) * (costToMake)) + costToMake).ToString();
                    double grossProfit = double.Parse(sellPrice) - costToMake;
                    double grossProfitAfterTax = grossProfit - (grossProfit * .0625);
                    double grossprofitAfterTaxAndReduction = grossProfitAfterTax - (grossProfitAfterTax * .6);
                    txtProfitEdit.Text = "$" + ((Math.Truncate(100 * grossprofitAfterTaxAndReduction) / 100) * double.Parse(txtAmountSoldEdit2.Text));
                }
            }
        }

        private void btnUpdateMarkup_Click(object sender, EventArgs e)
        {
            if (txtProductsSoldIDEdit.Text != "")
            {
                DataOps.OleDbSelectProductMarkupAndCostToMakeAndSellPrice(txtProductsSoldIDEdit.Text);
                double costToMake = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString());
                string sellPrice = (((double.Parse(txtMarkupPercentageEdit.Text.TrimEnd('%')) / 100) * (costToMake)) + costToMake).ToString();
                txtSellPriceEdit.Text = "$" + sellPrice;
                double grossProfit = double.Parse(sellPrice) - costToMake;
                double grossProfitAfterTax = grossProfit - (grossProfit * .0625);
                double grossprofitAfterTaxAndReduction = grossProfitAfterTax - (grossProfitAfterTax * .6);
                txtProfitEdit.Text = "$" + (Math.Truncate(100 * grossprofitAfterTaxAndReduction) / 100) * double.Parse(txtAmountSoldEdit2.Text);

                //validate this guy
                DataOps.OleDbUpdateEndProductMarkup(txtMarkupPercentageEdit.Text.TrimEnd('%'), sellPrice, txtProductsSoldIDEdit.Text);

                //redo the total profit to get an updated one using the recently updated data
                DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(txtTransactionIDEdit.Text);//this may be datesold, but it selects sold product stuff by sold productid
                string[] tokens;
                char[] delim = { ',' };
                tokens = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString().Split(delim);
                double totalCost = 0;
                double totalSellPrice = 0;
                if (tokens.Length == 1)
                {
                    DataOps.OleDbSelectProductCostAndSellPrice(tokens[0]);
                    totalCost = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString());
                    totalSellPrice = double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString());
                }
                else
                {
                    for (int i = 0; i < tokens.Length - 1; i++)
                    {
                        DataOps.OleDbSelectProductCostAndSellPrice(tokens[i]);
                        totalCost += double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][0].ToString());
                        totalSellPrice += double.Parse(DataOps.dsEndProducts.Tables[DataOps.dtEndProducts].Rows[0][1].ToString());
                    }
                }
                double totalGrossProfit = totalSellPrice - totalCost;
                double totalGrossProfitAfterTax = totalGrossProfit - (totalGrossProfit * .0625);
                double totalGrossProfitAfterTaxAndReduction = totalGrossProfitAfterTax - (totalGrossProfitAfterTax * .6);
                txtTotalProfitEdit.Text = "$" + Math.Truncate(100 * totalGrossProfitAfterTaxAndReduction) / 100;
                MessageBox.Show("Markup percentage successfully upadted.");
            }
            else
                MessageBox.Show("Please select a sold product to edit.");
        }

        private void txtMarkupPercentageEdit_Leave(object sender, EventArgs e)
        {
            if (txtMarkupPercentageEdit.Text != "")
            {
                if (txtMarkupPercentageEdit.Text.Remove(0, txtMarkupPercentageEdit.Text.Length - 1) != "%")
                {
                    txtMarkupPercentageEdit.Text = txtMarkupPercentageEdit.Text + "%";
                }
            }
            if (txtMarkupPercentageEdit.Text == "")
                txtMarkupPercentageEdit.Text = "0%";           
        }

        private void btnUpdateAddSales_Click(object sender, EventArgs e)
        {
            if (btnUpdateAddSales.Text == "Add")
            {
                if (cbxCustomerIDEdit.SelectedIndex != -1)//validate to see if a customer is selected
                {
                    if (txtStoreEdit.Text != "")//validate to see if a store location is there
                    {
                        //make sure to build a string for amount sold relative to endproductid
                        string AmountSold = "";
                        string ProductID = "";

                        DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(txtTransactionIDEdit.Text);
                        if (DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows.Count == 0)//checks if there is anything in the sold products section
                        {
                            MessageBox.Show("You must sell something for this transaction to be saved.");
                            return;
                        }
                        ProductID = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString();//shove productids into string
                        AmountSold = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][2].ToString();//shove amount sold into string

                        DataOps.OleDbUpdateSoldProduct(txtTransactionIDEdit.Text, dtDateSoldEdit.Value.ToString("MM/dd/yyyy"), AmountSold, txtStoreEdit.Text, ProductID, cbxCustomerIDEdit.Text, true);
                        MessageBox.Show("New transaction sucessfully added.");
                        cancelTransactionBool = false;

                        //clear out the view transaction section to avoid conflicts
                        cbxTransactionView.Items.Clear();
                        cbxSalesIDView.Items.Clear();
                        cbxProductsView.Items.Clear();
                        cbxSoldProductID.Items.Clear();
                        lblPleaseSelectTransactionID.Visible = false;
                        cbxSoldProductID.Visible = false;
                        cbxSoldProductID.Enabled = false;
                        clearViewSales();
                    }
                    else
                    {
                        MessageBox.Show("Please enter a store.");
                        txtStoreEdit.Focus();

                    }
                }
                else
                {
                    MessageBox.Show("Please select a customer to sell to.");
                    cbxCustomerEdit.Focus();
                }
            }
            else if(btnUpdateAddSales.Text == "Save")
            {
                if (cbxCustomerIDEdit.SelectedIndex != -1)//validate to see if a customer is selected
                {
                    if (txtStoreEdit.Text != "")//validate to see if a store location is there
                    {
                        //make sure to build a string for amount sold relative to endproductid
                        string AmountSold = "";
                        string ProductID = "";

                        DataOps.OleDbSelectAllFromSoldProductWhereSoldProductID(txtTransactionIDEdit.Text);
                        ProductID = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][4].ToString();//shove productids into string
                        AmountSold = DataOps.dsSoldProduct.Tables[DataOps.dtSoldProduct].Rows[0][2].ToString();//shove amount sold into string

                        DataOps.OleDbUpdateSoldProduct(txtTransactionIDEdit.Text, dtDateSoldEdit.Value.ToString("MM/dd/yyyy"), AmountSold, txtStoreEdit.Text, ProductID, cbxCustomerIDEdit.Text, true);
                        MessageBox.Show("Transaction infomation sucessfully updated.");

                        //clear out the view transaction section to avoid conflicts
                        cbxTransactionView.Items.Clear();
                        cbxSalesIDView.Items.Clear();
                        cbxProductsView.Items.Clear();
                        cbxSoldProductID.Items.Clear();
                        lblPleaseSelectTransactionID.Visible = false;
                        cbxSoldProductID.Visible = false;
                        cbxSoldProductID.Enabled = false;
                        clearViewSales();
                    }
                    else
                    {
                        MessageBox.Show("Please enter a store.");
                        txtStoreEdit.Focus();
                    }
                }
                else
                {
                    MessageBox.Show("Please select a customer to sell to.");
                    cbxCustomerEdit.Focus();
                }
            }
            //recalculateTotalProfit();//this might need to be here. idk tho. I'm not sure why it was here to begin with.
        }

        private void cbxCustomerIDEdit_SelectedIndexChanged(object sender, EventArgs e)
        {
            //do a quick update to set the current transaction's cusotmerid to this guy
            DataOps.OleDbUpdateCustomerIDWhereSoldProductID(cbxCustomerIDEdit.Text, txtTransactionIDEdit.Text);
        }

        private void clearUpdateAdd()
        {
            txtTransactionIDEdit.Clear();
            txtStoreEdit.Clear();
            dtDateSoldEdit.Value = DateTime.Now;
            lbxProductsEdit.Items.Clear();
            lbxProductIDEdit.Items.Clear();
            lbxProductsSoldEdit.Items.Clear();
            txtProductsSoldIDEdit.Clear();
            txtAmountSoldEdit.Value = 0;
            txtAmountSoldEdit2.Clear();
            txtMarkupPercentageEdit.Clear();
            txtSellPriceEdit.Clear();
            txtProfitEdit.Clear();
            txtTotalProfitEdit.Clear();
        }

        #endregion

        #endregion
    }
}
