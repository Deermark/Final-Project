﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EllisonM_FinalProject
{
    public partial class frmReport : Form
    {
        public frmReport()
        {
            InitializeComponent();
        }

        private void frmReport_Load(object sender, EventArgs e)
        {
            //check to see which report the user wants to see and then sets that report to the viewer
            try
            {
                if (frmMain.report == "sales")
                {
                    SalesReport sr = new SalesReport();
                    sr.SetDatabaseLogon("", "");
                    crvReport.ReportSource = sr;
                }
                else if(frmMain.report == "inventory")
                {
                    InventoryReport ir = new InventoryReport();
                    ir.SetDatabaseLogon("", "");
                    crvReport.ReportSource = ir;
                }
                else if(frmMain.report == "customer")
                {
                    CustomerReport cr = new CustomerReport();
                    cr.SetDatabaseLogon("", "");
                    crvReport.ReportSource = cr;
                }
            }
                catch (Exception)
            {
                MessageBox.Show("Please update crystal reports to the correct version.");
            }
        }
    }
}
