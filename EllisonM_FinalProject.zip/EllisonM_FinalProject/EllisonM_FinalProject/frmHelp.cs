﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EllisonM_FinalProject
{
    public partial class frmHelp : Form
    {
        public frmHelp()
        {
            InitializeComponent();
        }

        private void frmHelp_Load(object sender, EventArgs e)
        {
            //set the preferences, then load up the about page
            if (frmMain.dontMessage == true)
                rdoYes.Checked = true;
            else
                rdoNo.Checked = true;
            lblTitle.Text = "About";
            pnlPreferences.Visible = false;
            pnlPreferences.Enabled = false;
            lblAbout.Visible = true;
            txtCustomer.Visible = false;
            txtInventory.Visible = false;
            txtReport.Visible = false;
            txtSales.Visible = false;
        }

        private void btnInventory_Click(object sender, EventArgs e)
        {
            //load up the inventory help page
            lblTitle.Text = "Inventory Help";
            pnlPreferences.Visible = false;
            pnlPreferences.Enabled = false;
            lblAbout.Visible = false;
            txtCustomer.Visible = false;
            txtInventory.Visible = true;
            txtReport.Visible = false;
            txtSales.Visible = false;
        }

        private void btnCustomer_Click(object sender, EventArgs e)
        {
            //load up the customer help page
            lblTitle.Text = "Customer Help";
            pnlPreferences.Visible = false;
            pnlPreferences.Enabled = false;
            lblAbout.Visible = false;
            txtCustomer.Visible = true;
            txtInventory.Visible = false;
            txtReport.Visible = false;
            txtSales.Visible = false;
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            //load up the report help page
            lblTitle.Text = "Report Help";
            pnlPreferences.Visible = false;
            pnlPreferences.Enabled = false;
            lblAbout.Visible = false;
            txtCustomer.Visible = false;
            txtInventory.Visible = false;
            txtReport.Visible = true;
            txtSales.Visible = false;
        }

        private void btnSales_Click(object sender, EventArgs e)
        {
            //load up the sales help page
            lblTitle.Text = "Sales Help";
            pnlPreferences.Visible = false;
            pnlPreferences.Enabled = false;
            lblAbout.Visible = false;
            txtCustomer.Visible = false;
            txtInventory.Visible = false;
            txtReport.Visible = false;
            txtSales.Visible = true;
        }

        private void btnPreferences_Click(object sender, EventArgs e)
        {
            //load up the preferences
            lblTitle.Text = "Preferences";
            pnlPreferences.Visible = true;
            pnlPreferences.Enabled = true;
            lblAbout.Visible = false;
            txtCustomer.Visible = false;
            txtInventory.Visible = false;
            txtReport.Visible = false;
            txtSales.Visible = false;
        }

        private void btnAbout_Click(object sender, EventArgs e)
        {
            //load up the about page
            lblTitle.Text = "About";
            pnlPreferences.Visible = false;
            pnlPreferences.Enabled = false;
            lblAbout.Visible = true;
            txtCustomer.Visible = false;
            txtInventory.Visible = false;
            txtReport.Visible = false;
            txtSales.Visible = false;
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            //delete the preferences file, make a new one, and shove the value of the radio button in there whatever it may be. then close the form
            File.Delete(@".../.../Data/preferences.txt");
            if (!File.Exists(@".../.../Data/preferences.txt"))
            {
                using (StreamWriter writer = new StreamWriter(@".../.../Data/preferences.txt", true))
                {
                    if (rdoYes.Checked == true)
                    {
                        writer.WriteLine("1");
                        frmMain.dontMessage = true;
                    }
                    else
                    {
                        writer.WriteLine("0");
                        frmMain.dontMessage = false;
                    }
                }
            }
            this.Close();
        }
    }
}
